# Ignatius Rocketfrock Developer Manual

This file holds implementation-facing guidance that would otherwise crowd the Level Editor. The editor UI should favor compact controls, live feedback, and short status messages. Longer behavioral explanations belong here.

## Level Editor loading and navigation

At startup the editor scans `resources/levels/level_001.json`, `resources/levels/level_002.json`, and subsequent numbered files through `level_020`, stopping at the first missing level. Environment atlases are discovered from numbered `resources/atlases/at_atlas_###` pairs, while character and independent atlases are loaded through their own manifests.

The right mouse button pans the canvas regardless of the active tool. **Fit** frames authored placements and entities. Shift-drag replaces the current selection with fully enclosed objects. Ctrl-click and Ctrl+Shift-drag toggle objects. The primary selected object is editable; secondary selections move and delete with it.

## Live object inspector

The Selected object panel has no Apply button. Position, dimensions, and rotation update while edited. Selects, checkboxes, IDs, and nonvisual values commit on their normal change event. Level placements and entities no longer carry free-form `notes` metadata. Timed power-up pickups expose an optional **Custom duration** checkbox; unchecked pickups omit `durationSeconds` and inherit the built-in effect duration, while checking it authors a per-instance override. Enemy scale remains a live uniform multiplier for the Character Editor-authored hitbox, artwork scale, artwork offsets, and projectile radius. Character-enemy W/H fields display the resulting hitbox and remain read-only.

For ordinary character enemies, AI strategy normally comes from the enemy catalog. Every selected non-boss catalog enemy exposes **AI strategy override** with `<Default>`, Hunter, Patrol, Sentry, Passive, Bomber, and Periodic. `<Default>` omits `strategyOverride` and uses the catalog strategy; an explicit override changes AI strategy only and deliberately does not change locomotion, attacks, projectiles, dimensions, or other catalog-authored properties. Unusual combinations are therefore allowed for intentional authoring experiments. Patrol/Sentry continue to use the placement's `patrolDistance`. Bosses use the separate boss strategy control. Legacy non-boss `strategy` properties are removed during Level Editor load/export and are not compatibility aliases.

Human enemies 030 through 037 also expose an **Appearance** selector in the Selected object panel. `head_00` through `head_15` are placement-level appearance IDs, not enemy types: selecting one loads the corresponding fitted rig for that archetype and therefore swaps the head plus the matching left/right upper/lower arm artwork while retaining the same body, weapon, gameplay catalog entry, and animation set. The Level Editor preview and both game runtimes honor the authored `appearance` field. Omitting it uses the archetype's original base rig. Human Boxer 038 is intentionally fixed to its one base rig with `head_16`; `head_16` is not an interchangeable appearance for the other humans. Automatic/random appearance assignment is not part of this authoring contract.

Generated locked records reject inspector changes until unlocked. Changing a wizard door or character enemy may perform the same floor snap that the previous Apply action performed when the field is committed.

## Palette thumbnails

The Entity and Asset palettes use matching compact two-column scrolling grids plus a shared full-page modal chooser opened from the Place entity / Place asset toolbar buttons. The modal uses the same card renderer, thumbnail sizing, filters, selection state, and selection actions while exposing many more cards at once. Cards retain fixed useful preview height regardless of result count. Direct atlas assets are cropped to visible alpha before fitting. Composed character previews are first rendered to a temporary surface, cropped from the final combined alpha, then centered and scaled to fill the card. This avoids transparent part padding and rig-space extents making enemies appear small or off-center.

## Automatic enemy spawning

Level-wide automatic spawning rolls once per second. A successful roll creates an already-alert enemy beyond the forward screen edge. The pool uses numeric ranges and `!` exclusions shared with the automatic generator.

A placeable enemy spawner is different: it is invisible during play and advances its timer only while its authored rectangle intersects the camera. A successful roll teleports an already-alert enemy to the authored point. Ground enemies require safe support; blocked, occupied, or unsupported attempts are skipped.

## Hunter navigation graphs

The editor builds one navigation profile for each distinct ground-Hunter body size and mobility configuration. This includes ground enemies that begin the level as Hunter and ground enemies that can become Hunter later through a cutscene `AI <enemy_id> hunter` command. Profiles include directed jumps, drops, step transitions, and chasm crossings. Static traversal-policy checks are applied while baking, so the graph shown by the editor should not advertise an edge that the game would reject under unchanged geometry. The runtime applies the same policy again as a defensive backstop for stale or externally-authored graph data. Dynamic blocker IDs can still disable or penalize otherwise-valid edges at runtime. Every Hunter profile that can be used by a packaged level must have an exact bake.

After changing hunter mobility data, support extraction, static traversal policy, or simulation-verification semantics, fully re-bake the packaged levels with `node reference/devel/rebake_navigation_simulation.mjs --write`. The resumable simulation rebaker writes a level only after every step/jump/drop candidate has a final simulation verdict and the canonical navigation graph can reuse the completed proofs. Use `--level level_004` to scope the operation to one level. `rebake_navigation_graphs.mjs` remains useful for fast heuristic graph inspection and structural stale checks, but a heuristic-only `--write` is not sufficient for a release after navigation inputs or verifier semantics have changed. Machine-generated `level_temp.json` is excluded from bulk simulation rebakes unless explicitly named.

## Automatic Level Generator

The Generator panel exposes four independent choices: **Theme**, **Colour modifier**, **Recipe**, and **Enemy pool**. A theme is appearance data only. It chooses tagged terrain, moving-platform, foreground, and background asset pools, plus presentation policy such as whether the cave perimeter should be populated. A colour modifier is a separate layer-wide environment colour map, so Frost can reskin the Cave theme without every cave asset being tagged twice or every new map atlas being added to a hidden allowlist. The current authored themes are Cave, Forest, and Castle.

Generator enemy-pool entries may carry bucket weights, for example `10-19:0.4,20-29:0.3,30-39:0.3`. Weights are relative and are normalized by their sum; omitted weights mean `1.0`. Include ranges must not overlap. Encounter clusters are selected as a unit, then the generator tracks the actual number of monsters placed from each bucket and steers later encounter choices toward the requested whole-level mix. The placeable Enemy spawner uses the same weighted bucket notation; the level-wide Autospawner currently consumes only the resolved ID set.

A **Generator recipe** is the curated level-builder choice. It locks route implementation, cavern implementation, traversal settings, validation profile, and length into one tested combination. The editor therefore does not expose raw Route, Cavern, or Length permutation controls. Domed Compact, Domed Standard, and Domed Long use the established horizontal run-and-gun route with the ordinary Domed cavern. The Cave-only **Domed Grounded** recipe is based on Domed Long but places deep Atlas 035-039 ground runs before tracing the cavern, advances adjacent floor texture bands by at most one atlas step, and anchors most of the lower perimeter to those floors. Revision 722 restores its pre-macrocell distributed upper-platform population and wide-upper cavern shaping after the explicit 716-721 corridor/cavern macrocell experiment proved too sparse in play. Semantic decoration metadata from that experiment remains active: Grounded uses tagged background rocks, ceiling/floor decorations, modular side walls, and occasional rooted mushroom platforms without coupling those asset roles to a macrocell topology. Automatic side-wall placement currently admits only the six tagged upper/middle/lower pieces from Atlas 002; older wall sets remain manually placeable. Alcove/background-scene tags are retained in the asset metadata, but revision 724 no longer places alcoves automatically because the current procedural composition did not use them convincingly. Theme-restricted recipes are hidden when an incompatible biome is selected. New algorithms should be introduced as new recipes only when the existing recipe structure cannot express them cleanly, and every exposed combination should be seed-swept against each compatible theme before appearing in the editor.

Asset membership is authored through symbolic generation tags. `resources/editor/asset-generation-tags.json` is the shared valid-tag catalog; atlas objects store readable `generationTags` arrays, and the Asset Editor presents grouped checkboxes from that catalog. Theme pool queries use `all`, `any`, and `none` clauses. The Generator panel's **Generate foreground** and **Generate background** commands use the currently selected theme and therefore admit only assets from that theme's foreground/background queries. Semantic decoration roles such as standalone or modular cave side walls and `placement.caveBackgroundLarge` also live in these tags; authored left/right orientation is metadata and mirrorable wall art may be used on the opposite side by flipping X. Large cavern backgrounds stay near authored/default object scale while the generated Background layer may provide layer-wide enlargement up to the current 4x policy limit. Traversal/platform generator roles and measured collision constraints remain separate from these semantic decoration tags.

Horizontal is the current run-and-gun route inside these recipes. It advances steadily toward the exit, favors solid overlapping ground pieces with level walking surfaces, and uses only occasional height changes. A distributed two-step upper lane covers at least 36 percent of the playable span. Theme-specific blockable ground silhouettes are allowed to differ in native width and transparent edge padding, so the final overlap segment is corrected conservatively while preserving at least 72 world units at every seam.

Rewarded levels target roughly one real power-up per 3,000 route pixels at default density. The generated pool is 60 percent authored wrench, 30 percent Overdrive, and 10 percent Shield. Dedicated second-tier power-up perches receive Overdrive before ordinary reward slots are filled, so the speed reward is visibly off the main path. Reward-only rerolls retain fixed safe seats and anchored encounters while varying the pickup mix.

The Level Editor now keeps the Generator panel focused on the current authoring workflow. **Generate level** runs the complete recipe. **Generate foreground** and **Generate background** are independent decoration passes that derive their coverage from the current cave perimeter instead of requiring route-generator metadata. Route and validation overlays remain available in **View**. The older stage-regeneration, ownership-conversion, generated-content clearing, and generator-specific undo/redo controls are no longer exposed in the panel. The underlying staged generator contracts remain deterministic for tests and tooling: encounter rerolls preserve route, platforms, endpoints, and rewards, while Reward rerolls preserve route and terrain and retain anchored encounters.

## Cave window and foreground

The cyan loop is the cave opening. Feather controls the transparent-to-black width using a linear opacity ramp from transparent at the opening to opaque at the dashed magenta full-black boundary. Gradient waviness perturbs the shapes of intermediate opacity contours without changing that linear fade law or moving collision, navigation, decoration normals, or the lethal boundary.

Foreground is inert presentation. It renders after actors with cave parallax, uses depth treatment, fades outward into black, and never has atlas collision. **Generate foreground** walks the current cave spline and classifies each span from its inward normal. Ceiling spans use the Route-driven Grounded ceiling vocabulary, floor spans use upright stalagmites, and side spans use the tagged Atlas 002 upper/middle/lower modular wall vocabulary. Mirrorable wall pieces may be flipped to the opposite cave side, rotate with the local full-black tangent, and overlap their neighbours slightly. Their two outward long-edge corners must both be on or outside full black, with the smallest radial shift that satisfies the rule. Ceiling pieces are likewise shifted outward only as far as necessary for both rendered upper corners to be on or outside the full-black boundary, with at least one corner touching it where local geometry permits. Narrow ceiling stalactites stay vertical with their tips pointing straight down, and the boundary rules are re-applied after Foreground-size scaling. If an existing non-background asset bounding box crosses a ceiling or side perimeter span, that span is left untouched so hand-authored decoration wins. On the lower perimeter the same crossing changes the treatment to sparse stalagmites; bare lower spans receive the dense treatment. Sparse lower decoration keeps roughly one quarter of the normal candidate density with seeded per-candidate selection, so the long-run amount stays stable without producing a mechanical every-fourth-piece rhythm; adjacent pairs/triples and wider gaps are allowed. **Generate background** fills the cave opening with the same tagged rock-patch vocabulary used by Route-driven Grounded, but likewise needs only the perimeter geometry. Existing manually placed Background atlas assets reserve their rendered bounding boxes, so regeneration fills uncovered background without covering hand-authored Background artwork. Generator **Background size** and **Foreground size** controls range from 0.2 to 4.0; the default Route-driven Grounded recipe currently starts them at 2.0 and 1.0 respectively. They enlarge or shrink decoration after normal-size placement decisions, so values above 1 intentionally create more overlap. Ceiling pieces are the deliberate exception to strict center preservation: after sizing they may shift radially just enough to restore the full-black upper-corner rule. Background coverage extends through the full-black boundary with a small safety margin and accounts for the relative cave/Background parallax so screen-space drift does not expose unfilled edges. The Level Editor applies the same world-bounds-anchored camera offset to the cave opening, its gradient guides, and every `caveForeground` placement. Pan and zoom the editor to the camera region being authored before judging whether a door, platform, or actor remains inside the visible opening.

## Level colour map

Colour mapping never modifies source PNG files. Recolored atlas copies are cached only when settings change. Environment atlas artwork is affected; characters, collision geometry, alpha, and the cave background are not.

## Moving platforms

Moving platforms have two mutually exclusive motion types. **Translate** is the established endpoint-to-endpoint platform motion. Its **Easing** can be Linear, Ease in, Ease out, or Ease in/out; `speed` continues to define average trip speed, so changing easing changes acceleration character without changing the time required to reach the endpoint. Shuttle is the safe translation default and pauses at both endpoints. Vanishing patterns always restore the platform after their hidden reset time. For Translate motion, the circular END handle edits the route directly on the canvas. **Roll radius** is an optional visual rolling mode for round objects such as boulders and barrels: `0` disables it, while a positive radius rotates the artwork by translated arc length (`angle = distance / radius`). Horizontal travel rolls clockwise to the right and counter-clockwise to the left, and reversing a shuttle naturally unwinds the rotation. The atlas collision shape continues to translate without rotating, so Roll radius should be used for circular or otherwise rotation-insensitive collision geometry; this deliberately avoids introducing fragile arbitrary rotating-collider sweeps into ordinary translated platforms.

**Swing** rotates the platform as a pendulum around an authored local-space pivot. **Amplitude** is the maximum angular displacement on either side of the placement's ordinary rotation, **Initial angle** chooses the starting displacement, and **Swing period** is the duration of one complete cycle. Swing periods are clamped to a minimum of **2.0 s**, and the local pivot vector is clamped to a maximum length of **800 px**. Pivot X/Y may therefore lie well outside the artwork, which is useful for a hanging blade or chandelier, without permitting pathological pendulum speeds/radii. A positive or negative initial angle starts by moving toward the centre/bottom angle; an initial angle of exactly zero starts counter-clockwise. Automatic, rider, and signal activation plus initial/trigger delays remain available. Swing motion is intrinsically smooth and pendulum-like rather than using the translation easing selector. Atlas-authored collision geometry moves with the platform, so ordinary walkable/blockable geometry remains physical and orange damaging or red killable geometry can make the swinging object hazardous without a separate danger flag. Closed orange and red loops are filled damaging/killable polygons and are preferred for substantial trap bodies; green walkable support remains line-only. Between simulation poses the runtime uses short collision steps and treats each actor response approximately as translational displacement, then applies the authored angular pose to the platform. This deliberately favors stable game collision over exact continuous rigid-body physics.

Enable **Persistent through respawn** when a platform must retain its current position/angle, phase, collision state, and remaining phase timer when Ignatius dies or is otherwise reset; this does not alter its normal motion cycle. Rider activation can trigger again whenever a translating platform returns to `waitForTrigger`; signal activation likewise responds to each newer channel revision. Levers can therefore retrigger eligible translation platforms after being left and approached again, while keyholes and `proximitySignalTrigger` are one-shot emitters.

## Signals, gates, and boss defeat

Levers and keyholes activate automatically when the physical gap between Ignatius and the entity is no more than one wizard width; they do not use the Down/S/Enter interaction input. A lever toggles its named channel only on the outside-to-inside proximity edge, so Ignatius must step away and return before it can toggle again. A keyhole consumes its configured key on that edge, emits its named signal once, then fades away over 0.75 seconds and is removed. `proximitySignalTrigger` remains a separate invisible one-shot emitter: the first time Ignatius's center enters its authored `triggerDistance`, it activates the configured channel automatically, marks itself `triggered`, and never emits again during that level instance. In the Level Editor it appears as a small center-anchored marker with a dashed radius guide when selected. Signal gates begin closed and remain blocking while their closed artwork fades in place over 0.75 seconds. At the end of that fade the runtime gate entity, visual, receiver solid, and all atlas-authored collision segments/polygons owned by its visual are removed together, collision queries are invalidated, and actors standing on removed geometry are detached from that support. Later channel changes do not recreate the gate. A named signal is a broadcast channel, so one emission may activate every gate, moving platform, and other listener assigned to that channel. Boss enemies may emit a named channel when defeated, and scripted cutscenes may emit one explicitly with `SIGNAL <signal_name>`. Each `SIGNAL` command emits a fresh active channel revision through the same runtime signal system, so revision-triggered listeners such as moving platforms may be activated again by a later cutscene emission. Independently, an exit door refuses to open while any living boss remains in the level.

## Magic Ring concealment

The `magicRingPickup` grants the timed `magicRing` effect for 25 seconds and refreshes that duration when collected again. `powerUpHudLabel()` deliberately presents this effect as **Stealth** on the active-effect HUD while retaining the `magicRing` gameplay identity and Magic Ring pickup/editor naming. Ordinary enemy perception cannot acquire Ignatius while the effect is active. Presentation assembles Ignatius at normal opacity into a player-only offscreen composite and then draws that finished image once at 25% opacity, so hidden body parts do not show through overlapping hat/head/robe/limb sprites. The browser, SDL_Renderer, and raw SDL_GPU paths retain and reuse their composite surfaces/targets; capacity grows only when the current measured character draw bounds plus padding exceed the existing allocation, rather than reserving a fixed large target or reallocating every frame. Source-art transparent pixels remain transparent. Mounted rocket flame, smoke, and deluxe exhaust stay outside the composite and retain normal opacity. When Stealth is inactive the ordinary direct character-rendering path is used. Taking any real damage, committing a lunge attack, or committing a body slam immediately cancels concealment. Successfully firing a rocket also cancels it unless persistent progression has `stealthRocketUnlocked`; running, jumping, rocket-assisted hovering, lunge charging, and failed rocket attempts intentionally preserve concealment. A character enemy hit by Ignatius during concealment enters or refreshes a 10-second panic state without being given Ignatius's hidden position: hunters alternate short movement bursts with attacks in arbitrary directions, while other non-passive character strategies use the movement and attack forms their rigs already support. Passive actors remain passive. Ten seconds without another concealed hit ends panic and returns the enemy to its normal unaware activity. Homing projectiles are intentionally exempt from concealment and retain Ignatius as their target.

## Mailboxes, treasure, and doors

Each mailbox owns its letter, thought, trigger distance, and timing. Long text scrolls automatically and Jump advances or closes it. Mailbox and location-thought triggers claim and consume their one-shot event immediately, but if Ignatius is airborne they cancel Flight/held boost and defer the visible story until ordinary passive story physics has landed him. The trigger is not re-tested at landing. If Ignatius dies before landing, the still-hidden event is released and its authored trigger state is restored rather than surviving into respawn. Grounded activation still presents immediately. Treasure chests open once when Ignatius approaches, award their score, briefly display loot, then remain open and empty.

Scripted cutscenes accept `GOTO`, `ANIM`, `SAY`, `THINK`, `AI`, `PLAY`, `SIGNAL`, and `DELAY`. `PLAY <file.wav>` immediately plays that WAV from `resources/sfx/` and advances to the next command; paths are not accepted, so the command cannot escape the SFX folder. `THINK <character> "text"` has the same timing, skip input, and actor anchoring as `SAY`, but uses the shared large thought bubble instead of the speech bubble. `AI <enemy_id> <patrol|hunter|passive|sentry|bomber|periodic>` persistently changes that runtime enemy's AI strategy for the rest of the level session without changing its catalog locomotion or attack setup. `SIGNAL <signal_name>` completes immediately and emits one active revision on the ordinary named signal channel, using the cutscene trigger ID as the signal source. A dead referenced enemy no longer cancels an entire cutscene: actor-specific `GOTO`, `ANIM`, `SAY`, `THINK`, and `AI` commands for that dead enemy are skipped when reached, while other commands continue. A missing referenced enemy remains an authoring error and prevents the cutscene from starting. The Level Editor validates cutscene syntax, actor IDs, AI strategy names, and ground/flying GOTO misuse as authoring diagnostics.

Entry doors replace the legacy wizard-start marker. Exit doors are mirrored by default. An empty exit destination resolves to the next numbered level; if loading fails, the current level is restored. Set an exit entity's destination to the reserved value `credits` to end gameplay and start the shared credits roll instead of loading another level. A cutscene may start immediately from a trigger at the Wizard spawn, and exits remain suppressed while scripted cutscene control is active, so a final cutscene can walk the Wizard onto the exit and release control there. Edit `resources/ui/credits.md` for the roll: `# Heading` is the only heading syntax, every other non-empty line is a centered row, and blank lines add spacing. Completion or a fresh user interruption returns to the title screen; `credits` is never stored as a resume level.


## Character combat sounds (revisions 204-205)

Puppet Forge exposes Attack WAV, Hurt WAV, and Death WAV selectors in a separate collapsible **Character sounds** panel after **Projectile behavior** and before **Animation**. The selected values are written to the character definition as `sounds.attack`, `sounds.hurt`, and `sounds.death`. Choose **None** to remove a slot. URL projects list WAVs registered in the neighbouring `sound-effects.json`; local project loading also discovers every selected `.wav` file and writes a path relative to the character JSON.

The runtime uses the character ID attached to enemy attack, projectile, damage, and defeat events to look up these fields. A missing slot is intentionally silent. The global sound-effects catalog may still define the referenced file so it can reuse tuned volume and voice-count settings, while an unlisted WAV receives a normal dynamic pool.

The wizard character now names its ground animation `walk`, not `run`, and its map includes `hurt` and `death` slots. New character projects should use the same shared animation vocabulary.


## Puppet Forge enemy defaults (revision 353)

For a catalog-backed enemy, Puppet Forge places type-wide tuning in four adjacent panels: **Metadata**, **Movement**, **Attack behavior**, and **Projectile behavior**. Ordinary level placements inherit these catalog values; use Level Editor instance overrides only for intentional one-offs such as bosses. Attack behavior exposes Damage, Cooldown, Vertical reach, Awareness range, Awareness half-angle, Awareness hold, and type-specific engagement geometry. Ordinary ranged enemies expose **Maximum firing distance** (`rangedAttackMaxDistance`), **Preferred ranged distance** (`rangedPreferredDistance`), and **Minimum firing distance** (`rangedAttackMinDistance`). Minimum and maximum are hard horizontal firing boundaries for both ground and flying Hunters; preferred distance is only a positioning target used while preparing/repositioning. The projectile still has to be physically capable of reaching the shot, and fresh awareness plus vertical/terrain checks remain mandatory. Melee enemies expose `meleeHitRange`, `lungeStartMinDistance`, `lungeStartMaxDistance`, `lungeSpeed`, and `lungeEndSeparation`. Active melee definitions require a positive `meleeHitRange`, measured horizontally from the enemy grounded-base X; the attack handoff owns impact timing and strike Y. Projectile behavior owns kind, launch type, flight parameters, spread, rotation, effects, and AoE presentation.

The old **All defaults JSON** field is intentionally absent. **Enemy Catalog JSON** is the single complete raw JSON surface for `ct_enemies_001.json`; the structured panels edit the selected enemy entry directly. In Character, Level, and Asset tools, a right-side panel with no saved local preference starts collapsed. Opening or closing it records that panel's state for future sessions.

## Puppet Forge project discovery

The Known project dropdown is catalog-driven. At startup Puppet Forge loads `resources/characters/ct_enemies_001.json` and creates one selector entry for every enemy definition that provides `characterId` or `characterUrl`. A normal `characterId` such as `ct_char_enemy_040` resolves to `resources/characters/ct_char_enemy_040.json`; `characterUrl` may override that convention. Adding a new enemy therefore requires only the catalog entry and its referenced character, rig, atlas, image, and animation files. The wizard remains the only built-in non-catalog project.

A character definition may additionally provide an `appearanceRigs` object mapping compact appearance IDs to rig JSON files. Puppet Forge then shows an **Appearance rig** selector without creating extra enemy catalog entries. Selecting an appearance loads that actual rig document while keeping the character's animation map and atlas; saving writes the currently selected rig filename. For the human fitting matrix, alternate heads are independently fitted per body, but each archetype's original head maps directly to the ordinary base rig instead of maintaining a duplicate file that could drift out of sync. `ct_human_parts_030.json` records the shared human head-to-arm skin packages used to seed those rigs.

Human animations remain one shared animation set per archetype. Alternate fitted rigs may preview those animations, but Puppet Forge must not bake or save shared animation changes while a non-base appearance rig is selected. Switch to **Base rig (archetype original)**, or select the original appearance ID that maps to that same base rig, before saving animation edits. This prevents a head-specific parent constraint from rebaking the shared clip.

## Enemy combat distance authoring

See `../ENEMY_COMBAT_AUTHORING.md` for the canonical ranged, melee, and lunge distance definitions, ASCII diagrams, positioning rules, and authoring invariants. Both the HTML/JS reference simulation and SDL/C++ simulation must follow that document.

## Character enemies

The placement point is the enemy foot position. Awareness uses distance and facing cone rather than line-of-sight collision, although terrain may still block movement and attacks. For ground enemies, `patrolDistance` defines an inner home patrol zone of `spawnX +/- patrolDistance/2`. Patrol enemies pace inside that zone while idle and may pursue only as far as the outer `spawnX +/- patrolDistance` leash; Sentries remain at their spawn while idle, use the same outer pursuit leash, and return to spawn after disengaging. Their ranged projectiles may travel beyond the leash, but committed melee lunges may not. A Patrol or Sentry that reaches its leash without a legal attack uses the same unreachable glare as a Hunter. Hunters patrol the inner home zone but may leave it without a patrol-distance leash while pursuing, choose reachable attack positions, cross gaps with one jump, glare while the target is unreachable, and attempt to return home. A hunter unable to climb home adopts its current support as a temporary patrol and periodically retries. A `patrolDistance` of `0` is a literal zero-width range rather than an implicit default span.

`enemy_901` (**Invisible Cutscene Speaker**) is an ordinary passive Training Dummy-derived enemy intended only as a hidden speech-bubble anchor. Place it like any other catalog enemy and reference that placed enemy ID from cutscene dialogue. Its generic `visualized` catalog default makes the runtime omit its artwork/shadow/health presentation; there is no speaker-specific AI or cutscene behavior. Move or otherwise author it far enough away outside the intended scene when it should not participate in gameplay.

## Reactive objects

Reactive objects live in authoritative simulation state. Rockets strike them before terrain behind them. Their collision is removed when they enter a nonblocking state such as destroyed.

## Palette placement workflow

Selecting an Asset or Entity palette card activates its placement tool. The toolbar Place asset / Place entity buttons instead open the expanded chooser; selecting there routes through the same selection action, closes the chooser, and activates placement. While the pointer is over the canvas, the editor draws a translucent snapped preview using the same size, visual, anchor, and applicable ground-snap rules as the final record. Clicking places one object and returns to Select. The preview is transient UI state and must never be serialized or consume an ordinary object ID.


## Level Editor rendering performance

The normal editor now uses the production Canvas2D game renderer for the complete base scene. Authored level data is converted through `applyEditorLevelToWorld`; `RocketfrockRenderer.setViewOverride()` supplies the editor's top-left camera and zoom. The separate transparent `#stage-overlay` owns only authoring vectors such as grid lines, collision/manifest guides, labels, cave controls, route diagnostics, selection, and placement previews.

Redraw requests remain coalesced through `requestAnimationFrame`. Pan and zoom are camera-only operations: they reuse the current runtime world, spatial buckets, asset-local overlap masks, foreground treatment cache, cave mask cache, and loaded atlases. Do not mark runtime world data dirty merely because the camera moved. Level loads, placement/entity edits, cave edits, colour-map changes, and relevant visibility controls mark it dirty; the next frame performs one conversion and then returns to cheap camera-only rendering.

During a placement or entity move, the base runtime snapshot omits the moving records once. Their live artwork and guides are drawn on the overlay until the drag commits, so ordinary pointer movement does not reconvert the complete level. Camera panning does redraw both canvases directly and keeps artwork and guides in one coordinate system. There is no CSS-translated snapshot, independently moving layer, whole-level bitmap, editor WebGL context, or editor tile cache.

The Level Editor deliberately ignores the game's `?webgl=0` / `?webgl=1` selection and always uses Canvas2D for its base scene. Add `?profile=1` or `?perf=1` to expose animation-frame cadence, queue delay, authored-world synchronization cost, production renderer world/actor/foreground/mask timings, guide-overlay cost, and visual culling counts. The latest values are also available as `globalThis.__ignatiusEditorPerformance`.


## Test gates and release testing

The testbench is divided into named development gates, and every primary test has explicit ownership in `tests/test-gate-manifest.mjs`. Each shard runs in a fresh Node process. This keeps memory bounded and makes the intended scope visible.

Use `npm run test:editor` for Level Editor and Puppet Forge work, `npm run test:game` for simulation and runtime work, `npm run test:shared` for shared data, browser adapters, manifests, and presentation helpers, and `npm run test:generator` for procedural generation. `npm run test:smoke` is a small overlapping cross-system check. A focused development pass should normally run its affected gate plus `shared` and `smoke`; add any neighbouring gate whose contract changed.

`npm test` is the authoritative fresh release gate. It runs twelve sequential fresh-process shards: two shared, two editor, four game, and four generator. The runner continues after a failed shard and prints a final table with passed, failed, timed-out, and skipped groups. Per-shard timeout defaults to five minutes and can be changed with `TEST_SHARD_TIMEOUT_MS`.

After each completed shard, the runner writes `.build/test-gate-report.json`. `.build/` is excluded from releases. `npm run test:release:resume` may skip shards already passed only when the SHA-256 fingerprint of all test-relevant source is identical. Ordinary `npm test` ignores old progress and starts clean. Use `npm run test:list` to inspect gate composition.

Generator boundaries remain foundation, decorated macro, content, and route-seed sweep. They stay sequential because concurrent geometry processes compete for memory. Testbench startup validates that every test has exactly one primary owner, so adding a test also requires an intentional manifest assignment.

`npm run audit:renderer` checks the direct Canvas ownership boundary recorded in `RENDERER_BOUNDARY_AUDIT.md`. `npm run inspect:editor-stress` verifies the frozen dense fixture metrics recorded in `EDITOR_STRESS_BASELINE.md`.

## Fixed-step browser input buffering

The browser loop deliberately separates polling from edge consumption. Call `input.sample({ consumeGameplayEdges: false })` once per animation frame, pass that frame to the first available fixed simulation step, and then call `input.consumeGameplayEdges(stepInput)`. Do not clear press/release fields merely because a rendered frame occurred. A 120 Hz display commonly produces render frames with no 60 Hz simulation step, and consuming there would lose short presses.

Keyboard and pointer transitions are event-latched. Gamepad transitions are latched when the Gamepad API is polled. A quick complete tap may therefore produce both `jumpPressed` and `jumpReleased` in one simulation frame. The jump simulation processes release first so an airborne release-and-repress can arm and start the rocket boost deterministically. `createSubstepInputFrame` remains responsible for stripping edges from the second and later catch-up steps while retaining held controls.

Use plain `input.sample()` only in isolated tests or utilities that intend to consume the returned edges immediately. Menu, focus-loss, level-restart, and title-start paths should continue to call `input.clear()` or `suppressJumpUntilRelease()` as appropriate so buffered gameplay gestures cannot leak across UI boundaries.


## Revision 307 yellow wrench profile note

The canonical yellow wrench remains `POWER_UP_EFFECT_IDS.WRENCH_TRIPLE` for save compatibility, but its visible label is Fivefold. Its current profile is data-driven in `src/shared/power-up-data.js`: `projectileCount: 5`, `damageMultiplier: 1 / 5`, and `initialAnglesDegrees: [-7.5, -3.75, 0, 3.75, 7.5]`. Keep the centre entry at index 2 when tests or tooling inspect the nearest-forward aim line.

Player-rocket range is distance-driven. The current installed balance authors 400 world pixels for the ordinary rocket and 1200 world pixels as the base wrench path budget. The persistent `standardRocketRangeUnlocked` talent is off by default and grants only the unwrenched Standard rocket +25% reach, taking it to 500 px; it never modifies wrench rockets. Yellow Fivefold and Cyan Dart apply `travelDistanceMultiplier: 1.5`, so those two retain 1800 px. `simulation.js` derives each projectile lifetime from the resulting travel budget divided by projectile speed: Standard is 0.8 s at 500 px/s by default or 1.0 s with the range talent; Yellow/Cyan are 1.8 s at 1000 px/s; Green is 1.2 s at 1000 px/s; Blue/Magenta are 2.4 s at 500 px/s; and Red is 4.8 s at 250 px/s. The installed base direct damage is 20: Yellow and Blue divide that across their volleys, while Red multiplies it by 4 to 80. Standard fuel cost is 30; Yellow/Cyan/Green/Magenta/Blue use the 0.5 launch-cost multiplier for 15 fuel, and Red uses the 2.0 multiplier for 60 fuel. `rocketDurationPercent` and `rocketDamagePercent` are percentage development-tuning multipliers around these authored values.

## Revision 308 uncapped player rocket launch cadence

Player rocket firing is edge-triggered but has no simulation cooldown. `src/core/simulation.js` should attempt a launch for every delivered `weaponPressed` edge and reject it only when fuel is insufficient or another explicit gameplay rule blocks the action. Do not restore `rocketLaunchCooldown`, `weapons.launchCooldownTimer`, `launchCooldownMultiplier`, or cooldown-based `ROCKET_LAUNCH_BLOCKED` events. Older serialized states may still contain a `launchCooldownTimer` property; it is ignored. Holding a launch key does not invent repeated presses, so automatic fire remains a separate future control decision.


## Revision 310 wrench launch-path tuning

Yellow Fivefold keeps five evenly spaced non-homing rockets in the canonical `[-7.5, -3.75, 0, 3.75, 7.5]` fan around the nearest-forward aim line. Cyan Dart launches horizontally and then turns weakly toward the easiest forward target, preferring the smallest angular error over raw distance; its steering is fixed at 0.035° per world pixel actually travelled, independent of camera geometry and the rocket's current angle. Blue Homing Triple keeps its authored `[-12, 0, 12]` fan and standard homing behavior.

Yellow Fivefold and blue Homing Triple both keep exact authored launch angles with `initialAngleJitterDegrees: 0`; repeated volleys do not perturb the launch wedge. Blue instead receives deterministic in-flight homing meander through `HOMING_TRIPLE_MEANDER_INTERVAL_SECONDS` (0.16 s) and `HOMING_TRIPLE_MEANDER_TURN_DEGREES` (7 degrees). The initial meander timers and later left/right disturbance choices are seeded portable simulation data, so identical seeded replays remain identical. Keep this variation in portable simulation data; do not use `Math.random()` or renderer-owned variation.

The lightning pickup is **Overdrive**, with canonical internal IDs `overdrive` and `overdrivePickup`. It halves projectile-rocket launch fuel cost and reduces each newly imposed fuel-recharge delay by `OVERDRIVE_FUEL_RECHARGE_DELAY_REDUCTION_SECONDS`, currently 1 second, clamped at zero. Apply the reduction when `markFuelUse()` receives the authored delay: ordinary rocket use therefore goes from 1 second to 0, while lunge and committed body slam go from 3 seconds to 2. This does not retroactively shorten a delay already in progress, does not bypass `fuelRechargeRequiresGround`, and does not provide passive fuel recovery.


## Revision 311 WebGL2 rendering guidance

The game canvas is WebGL2-first. `createRenderer` in `src/presentation/canvas-renderer.js` attempts `createWebGL2RendererBackend` and uses the visible canvas as the WebGL target. A separate hidden Canvas 2D surface remains available for procedural drawing and for the complete fallback renderer. Do not request a 2D context from the visible canvas before WebGL2 selection, because a browser canvas cannot switch context families afterward.

Use `WebGL2RendererBackend.queueSprite` or `queueSurface` for stable image-backed visuals. Preserve scene order: the batch only merges adjacent commands that use the same texture, and texture changes flush automatically. Static sources should use cached uploads; the staging surface must be marked dynamic so each changed pass uses `texSubImage2D`. The same staging canvas is uploaded twice per frame, once for actors/effects and once for masks/overlays, so each upload must force a fresh texture update even within one WebGL frame.

Canvas/image sources are uploaded premultiplied and rendered with `ONE, ONE_MINUS_SRC_ALPHA`. Do not change one side of that contract independently. Clear the GPU texture cache after replacing colour-mapped atlas canvases or foreground/overlap caches. Keep gameplay and deterministic simulation completely unaware of the renderer backend. WebGPU should only be reconsidered when a measured workload cannot be served by this WebGL2 batcher and browser/runtime support is acceptable.

## Revision 312 particle-pass migration guidance

When adding or adjusting rocket smoke, projectile explosion, or Ignatius death particles, prefer the dedicated WebGL2 effect helpers in `src/presentation/canvas-renderer.js` (`drawWorldEffectsWebGL`, `drawProjectileExplosionEffectsWebGL`, and `drawPlayerDeathCoverWebGL`) rather than pushing those families back onto the staging canvas. These helpers rely on small cached sprite canvases and backend blend-mode selection, so keep their visuals image-backed and batching-friendly.

Only move an effect family into the direct GPU pass when its ordering relative to staging uploads is explicit. Lower scenery/actor staging uploads happen first, then the direct GPU particle pass, then upper staged actors/UI content. If an effect still needs the full Canvas drawing API or does not justify a dedicated sprite treatment, leave it on the staging canvas and preserve fallback parity.

## Revision 313 enemy projectile migration guidance

With WebGL2 active, launched enemy fireballs, musket balls, and rocks should now be handled by `drawEnemyProjectilesWebGL` in `src/presentation/canvas-renderer.js`. Keep those projectile visuals sprite-oriented so they can stay in the GPU batcher. If a new enemy projectile family is lightweight and image-backed, prefer extending this pass instead of routing it back through the staging canvas.

Preserve scene order carefully. The direct enemy-projectile pass sits after the lower staged world/effect upload and before the staged pass containing player rockets, Ignatius, and score popups. If a projectile depends on complex Canvas drawing semantics or must interleave differently, document that explicitly before changing its pass assignment.

## Revision 314 player rocket migration guidance

With WebGL2 active, launched player rockets should now be rendered by `drawPlayerRocketsWebGL` and `drawProjectileRocketWebGL` in `src/presentation/canvas-renderer.js`. Keep future rocket-visual adjustments sprite-friendly so they can stay in this GPU batch. The helper `queueWebGLAssetSprite` now supports pivot-style local offsets for images whose simulation origin is not the centre of the source bitmap.

The staging Canvas path still owns Ignatius, text, and several other dynamic overlays, so any new projectile-related embellishment should be placed carefully: direct rocket trails, direct rocket bodies, and direct explosion effects happen before the staged player/UI pass. Preserve the pure Canvas fallback behavior when extending these helpers.

## Revision 315 actor rendering guidance

With WebGL2 active, target markers, pickups, enemies, and the player rig should use their direct GPU helpers in `src/presentation/canvas-renderer.js`. Character animation and pose calculation remain shared with the Canvas path; do not fork gameplay or animation state for the GPU renderer. Add image-backed actor details through `queueCharacterProjectPoseWebGL` or adjacent sprite passes whenever their ordering is clear.

The upper staging pass is now primarily for procedural remnants such as the mounted fuel bulb, debug guides, mailbox/story text, and cave masking. Score popups should use `getWebGLTextSpriteCanvas` plus `drawScorePopupsWebGL` rather than returning to the full-screen staging layer. Avoid moving sprite-like actors back into that staging pass. Any new effect that requires Canvas should be isolated so it does not force already-migrated actors to be redrawn there.

## Revision 316 WebGL parity guidance

When changing GPU character ordering, compare it directly with `renderCanvas2D`. Death-cover sparks are intentionally drawn after Ignatius and before score popups. Moving them back into the earlier world-effect pass makes the effect appear behind the player and breaks the original visual contract.

Character damage flashes use the secondary `overlayTintAlpha` / `overlayTintCanvasKey` channel of `queueCharacterProjectPoseWebGL`. Keep that channel separate from the primary shield/low-health tint so simultaneous effects can compose. All character projects must prepare `hitFlashCanvas`; only the player project additionally requires `shieldCanvas` and `lowHealthCanvas`.
 In the Canvas fallback, route both enemy and player injury flashes through the same prepared `hitFlashCanvas` overlay path in `drawCharacterProjectPose`; do not reintroduce live `ctx.filter` flashes on the gameplay canvas.

## Revision 317 fallback and context-loss guidance

Do not probe WebGL2 by requesting it directly from the visible game canvas and then attempting a 2D fallback on that same element. Canvas context families are sticky. Use `probeWebGL2RendererSupport`, which creates and disposes a complete scratch backend, before the visible canvas is committed to WebGL2. If the probe fails, the visible canvas must remain untouched and use the ordinary Canvas 2D renderer.

Once the visible canvas owns WebGL2, a context-loss interval is not a Canvas fallback opportunity because the renderer's 2D canvas is only the hidden staging surface. Keep presentation idle until `webglcontextrestored` rebuilds the GPU resources.

## Revision 356 Level Editor renderer guidance

Treat the production Canvas2D renderer as the only base-scene implementation in the Level Editor. Editor work may add overlay guides or improve dirty-state precision, but it must not fork atlas composition, cave foreground, parallax, actor rendering, or layer ordering into another renderer. Keep the portable conversion seam (`applyEditorLevelToWorld`) and presentation camera seam (`setViewOverride`) narrow and explicit.

When adding an authoring mutation, ensure it marks `editorRuntimeWorldDirty`. When adding camera-only interaction, do not mark that flag. If a live manipulation can be represented transiently on the overlay, omit the manipulated records from the base snapshot once and defer reconversion until commit. Preserve the standalone Canvas baseline as a diagnostic control, not as a separate source of rendering truth.


## Revision 319 Overdrive naming guidance

Use `overdrive` for the portable effect ID, `overdrivePickup` for authored and generated level entities, and `POWER_UP_EFFECT_IDS.OVERDRIVE` in code. Do not reintroduce `speedShot`, `speedShotPickup`, or a translation layer for them. All supported bundled levels were migrated together in revision 319.

The older `rocketOverdrive` experiment remains a retired and rejected identity. The Revision 319 historical balance used a twenty-second Overdrive refresh; the current installed balance uses 25 seconds for Overdrive, every wrench effect, and Magic Ring, while Shield lasts 10 seconds. Ordinary timed pickups omit `durationSeconds` and inherit those built-ins unless Custom duration is deliberately enabled. Overdrive still halves player-rocket fuel cost and now shortens each newly imposed fuel-recharge delay by one second instead of supplying passive recovery.

## Revision 320 dynamic WebGL safety rule

Do not reactivate direct WebGL rendering for Ignatius, enemies, or projectiles solely on the strength of headless/source-contract tests. Revision 319 passed the automated suite but failed the first real playtest with all gameplay-critical sprites invisible.

The supported production path now draws the entire dynamic actor stack to the transparent staging canvas and lets WebGL2 composite that layer. Any future direct-sprite reintroduction must be incremental, guarded by a runtime switch, and checked in at least Chromium and Firefox with visible-player, visible-enemy, visible-projectile, hit-flash, death, and context-restoration scenarios.


## Revision 323 WebGL2 resident-texture testing

Canvas 2D remains the normal game renderer. Add `?webgl=1` to `game.html` only when testing the opt-in GPU path. Startup probes WebGL2 on a disposable canvas before the visible canvas is committed, so an unavailable or failed GPU backend still starts through Canvas 2D.

The debug panel identifies the experimental path as `webgl2-resident`. Its GPU line reports draw calls, quads, new uploads, texture updates, full-screen Canvas-layer uploads, texture count, and estimated resident MiB. In ordinary gameplay after startup, `layers:0` is the important revision-323 expectation. A nonzero layer count is legitimate while a story/debug overlay, puppet guide, fallback geometry, or unsupported residual visual is active. Cave-mask camera changes may increment texture updates without incrementing Canvas-layer uploads.

For visual validation, use a real browser configuration with WebGL2 enabled. Some headless Chromium builds disable WebGL entirely and silently exercise the Canvas fallback instead. Confirm both the `webgl2-resident` backend label and visible atlas-backed actors before treating a benchmark as a GPU result.

## Revision 324 WebGL effect and cave-mask validation

Open `game.html?webgl=1` and first confirm that the debug panel says `render:webgl2-resident`; a browser that silently falls back to Canvas is not a valid GPU test. Fire a player rocket along a curved route and verify that the smoky, sparkling path and nozzle flame remain visible, with no large fuzzy orange circle snapping between the newest trail samples near the rocket. Inspect a goblin fireball in both renderer modes: its authored teardrop body should retain the same narrow rear silhouette in WebGL and Canvas, without a circular orange bulb underneath it. Detonate both a player rocket and an enemy fireball, then destroy a reactive crate or barrier. The explosion cores, rings or sparks, impact puffs, goblin-fireball trail, and destruction smoke should all be visible.

On a warmed ordinary frame, the GPU diagnostics should normally read `uploads:0 updates:0 layers:0`. Camera movement should no longer increment `updates`, because the cave opening and feather are resident geometry and the exterior is generated with the stencil buffer. A nonzero `layers` count remains legitimate for mailbox/story presentation, debug or puppet guides, collision-only fallback scenery, or an unsupported residual visual.

WebGL2 is requested with a stencil buffer. If the implementation reports no usable stencil support, the renderer deliberately falls back to the older cached Canvas cave-mask texture while retaining the rest of the GPU path. Canvas 2D behavior is unchanged and remains the default without the URL parameter.


## Shared game tuning

Both runtimes load `resources/config/tuning.json` as the installed gameplay baseline. The file contains only constants that are consumed with the same meaning by HTML/JS and SDL/C++; compiled values remain emergency fallbacks and regression tests require them to match the shipped JSON. Edit this file for project-wide experiments.

The compact **Development features → Game tuning** menu exposes run speed, lunge speed, jump height, gravity, percentage-based rocket damage and duration, and **Double jump physics**. Player lunge range is derived from effective lunge speed times `playerLungeDurationSeconds`; there is no separately authored maximum-distance tuning field. `playerLungeSpeed` remains the base tuning value, and persistent `lungeSpeedUnlocked` applies its 1.25 multiplier afterward, so Development Tuning and the talent compose rather than overwrite one another. User changes are saved automatically as sparse `tuningOverrides`: browser localStorage for HTML/JS and the SDL profile `settings.json` for the native game. Reset replaces the entire sparse `tuningOverrides` object with an empty object and immediately reapplies the installed file; this also clears stale or currently invisible override keys rather than only resetting controls shown in the menu. Recordings store the complete resolved tuning so playback does not depend on later file or profile changes.

`doubleJumpPhysics` accepts `fixedImpulse` or `consistentApex`. Fixed impulse preserves the legacy rocket kick. Consistent apex adds one ordinary jump-height of vertical energy while Ignatius is rising; at rest or while falling it cancels vertical speed and starts a new ordinary-height jump.

The file also retains separate melee and ranged HP, run-speed, and attack-rate multipliers, plus ranged projectile speed. Ranged classification uses runtime `attackMode == "projectile"`. These broad multipliers remain useful for project-wide balancing, but they are no longer exposed as individual menu sliders. Per-enemy authored values in character and level data remain authoritative.


## Enemy family numbering

The current enemy namespace is grouped by creature family. Skeletons use `001-009`, goblins `010-019`, bats `020-029`, humans `030-039`, raptors `040-049`, snakes `050-059`, porkers `060-069`, crockers `070-079`, and ogres `080-089`. The latest modular additions are Hobgoblin `enemy_018`, Porker `enemy_060`, Crocker `enemy_070`, and Ogre `enemy_080`.

The three original goblin variants share `ct_atlas_enemy_010.png`. Hobgoblin, Porker, Crocker, and Ogre each own a dedicated atlas and rig, plus isolated copies of the Enemy 010 family animation clips so later tuning cannot disturb another species. Hobgoblin follows the Musket Goblin attack project, while the other three follow the Fireball Goblin caster project. Numeric enemy-pool fields refer to these suffixes. Gaps are valid because catalogs enumerate actual entries. Do not add aliases for retired identifiers; update bundled levels and tools together when a future family migration is intentional.


## Ranged attack validation

Ordinary ranged enemies may start an attack only when horizontal separation is within `rangedAttackMinDistance..rangedAttackMaxDistance`, and the authored band must have positive width (`rangedAttackMaxDistance > rangedAttackMinDistance`, with maximum at least 1 px). `rangedPreferredDistance` is not another firing condition: an off-cooldown enemy may shoot anywhere inside the legal band when fresh awareness, vertical reach, projectile feasibility, and terrain checks all pass. During cooldown, navigation simply stages toward the preferred distance without repeatedly probing projectile paths. Once ready, if the preferred point is not a valid shot position, ground and flying ranged Hunters search the legal band for a viable point biased toward preferred; equal preference-error candidates deterministically choose the smaller separation in both JS and SDL. A remembered last-seen position can sustain pursuit but never authorizes firing by itself. Ordinary horizontal running/coasting is not an additional readiness condition: if a grounded ranged or direct-melee enemy already has a legal off-cooldown attack opportunity, attack start pre-empts tactical repositioning immediately. Residual horizontal momentum then brakes through the attack state's passive ground physics rather than forcing the enemy to stop before wind-up. Airborne or otherwise committed traversal remains controlled by its traversal state.

When testing ranged enemies, place solid cover between the enemy and Ignatius and verify that no wind-up begins. Remove the cover and verify that the enemy may attack immediately from any point inside its hard min/max firing band, provided fresh awareness, vertical reach, and projectile feasibility all pass. Move behind cover, outside the firing band, or out of the awareness cone during the wind-up and verify that no projectile is released. Bombing bats should only drop when their predicted falling-rock lane overlaps Ignatius and no platform or blocking geometry interrupts the descent.


### Enemy projectile volleys (revision 332)

Projectile enemies may author `projectileVolleyCount` (1-15, default 1) and `projectileVolleyHalfAngle` in degrees (0-180, default 0). The simulation distributes projectiles evenly from negative to positive half-angle around the launch-time aim vector. Straight-volley attack permission succeeds when at least one member's swept circular trajectory intersects the player before terrain or a reactive projectile blocker. Each released projectile remains an independent ordinary projectile and carries `volleyId`, `volleyIndex`, `volleyCount`, and `volleyAngleOffsetDegrees` for diagnostics and presentation.


### Camera-relative cave preview (revision 333)

The cave window is not fixed to ordinary world geometry when either Foreground parallax axis differs from `1`. Runtime anchors the effect at the technical world-bounds centre and shifts the opening and cave-foreground artwork independently from `layerVisuals.foreground.parallaxX` and `parallaxY` according to the current camera centre. The Level Editor calls the same `computeCaveWindowParallaxOffset` helper, so panning to a room previews the mask position that gameplay will use there. Cave-point and foreground-asset hit testing, placement, dragging, labels, guides, and marquee selection operate on the displayed position while preserving authored world coordinates in level JSON.

## Retired enemy-hit laboratory (revision 380)

The standalone enemy-hit timing laboratory and its dedicated test have been retired. Enemy-hit presentation remains covered by the ordinary Canvas/WebGL renderer and simulation regressions.


### Ordinary-jump height trimming

Keep `ordinaryJumpHeight` as the authored full apex. Down is modeled as a full airborne gravity modifier: whenever it is held, use `2 * gravity` instead of `gravity`, during both ascent and descent. This halves the ordinary jump height when held from takeoff, curbs boost-kick travel, and creates a fast fall. Preserve the independent one-way-platform rule so grounded or descending Down input also grants passage through green walkable lines.

Enemy body contact damage is intentionally independent from ordinary attack invulnerability. Route it through `damagePlayer` with `invulnerabilityTimerKey: "contactInvulnerabilityTimer"`; do not set or consult the ordinary timer for contact hits. This preserves same-frame melee attacks while preventing sustained overlap from applying damage every simulation tick.

Revision 347 re-voices the alternate synthesized tunes rather than applying one blanket lead transpose. Each melody is placed in Level_001's low register according to its original tessitura, and every true bassoon foundation is kept strictly below the lead to prevent accidental voice crossing. Decorative bell accents remain independent of the bass hierarchy.

## Revision 352 cave-warning performance note

Cave geometry warnings depend on authored cave and terrain geometry, not on the camera. The editor therefore caches the sampled cave perimeter and each terrain placement's separation result. Do not invalidate or bypass this cache merely because the viewport pans, zooms, switches renderer, or changes grid/guide visibility. New cave diagnostics should follow the same rule: separate camera-dependent drawing from camera-independent validation.

## Revision 356 Level Editor panning note

Panning changes the editor camera and requests an ordinary production Canvas2D renderer frame. The guide overlay is redrawn in the same animation frame at the same camera, so artwork, boxes, labels, cave controls, and the side panel remain aligned. There is no post-drag catch-up frame and no finite snapshot that can reveal blank edge strips.

## Revision 357 Level Editor browser-timing note

Do not let diagnostics participate in editor viewport sizing. `#workbench`, `#canvas-wrap`, and `#hud-strip` must remain shrinkable inside the fixed main grid. The full profiler string may be clipped or exposed as a tooltip, but it must not widen the canvas row. Leave the visible canvas size to CSS and update only the backing-store width and height in `resizeCanvas()`. Setting an inline CSS width from `getBoundingClientRect()` recreates the resize feedback loop.

During a direct-manipulation gesture, pointer events should only update the latest camera or transient object state. The active requestAnimationFrame chain owns presentation and continues until the drag ends. Do not return to one render request per pointer event, which can phase-lock input and painting to alternate frames. Once idle, stop the chain so ordinary editor use remains event-driven. Wheel input uses the cached editor canvas rectangle and a short continuation window for the same reason.

For a repeatable functional check, serve the project and run `python devel/benchmark_level_editor_playwright.py`. The optional script requires Python Playwright and Chromium. It remains useful for layout, alignment, event wiring, and gross timing regressions, but revision 358 established that a headless or virtual-display compositor can report a healthy editor while physical Chrome and Opera on the target machine stall near one frame per second. Do not use its FPS ratio as final acceptance for Canvas/compositor work.


## Canvas game-renderer baseline

`level-renderer-baseline.html` is retained for posterity and can be opened directly when editor panning measurements become difficult to interpret. The Level Editor no longer links to this diagnostic page; save a browser copy first when the baseline should load current authored data.

This page is intentionally not an editor. It continuously renders the converted level with the production Canvas2D game renderer, including its ordinary spatial culling, environment sprites, runtime entities, actor-front artwork, cave foreground, parallax, and cave mask. It has no editor grid, guides, tile caches, WebGL backend, overlay canvas, or compositor pan preview. Drag anywhere on the canvas to pan, use the wheel to zoom around the pointer, and use **Reset stats** before comparing a representative drag.

Compare its requestAnimationFrame `cadence` and `worst` values with the renderer's synchronous `submit` and layer timings. A smooth baseline with a slow Level Editor points to editor interaction or overlay work. A similarly slow baseline points lower, toward browser rasterization, compositing, driver behavior, or production Canvas rendering at that view and zoom.


## Revision 358 Level Editor 2 structural ladder (retired)

The former `level-editor-2.html` and `src/tools/level-editor-2.js` scaffold was a temporary compositor diagnostic. It has been removed from the active project and must not be treated as a required page, package input, or Canvas owner. Historical revision notes describe its seven-stage experiment, but current editor work uses `level-editor.html` plus the retained posterity-only Canvas baseline.

## Revision 359 lazy Level Editor palettes

The entity and asset palettes deliberately keep their card text and buttons in the DOM, but their Canvas previews are lazy. Off-screen cards have a 1×1 backing store. When a card approaches the browser viewport, IntersectionObserver invokes the ordinary thumbnail renderer, which sizes the backing store from the card's CSS dimensions and device pixel ratio. When the card leaves, its backing store returns to 1×1.

This is not merely a startup optimization. Physical Chromium-family browsers may retain every populated Canvas as an accelerated surface even when it sits far down a nested scrolling sidebar. Level 002 exposes 197 palette choices, which previously meant more than fifteen million retained thumbnail pixels. Keep palette previews virtualized unless a future replacement uses one shared atlas-backed surface or ordinary image elements with demonstrably lower compositor cost.

With `?profile=1`, the Level Editor readout ends with `palette active/total canvases N.NN MP`. During ordinary map editing, the active count should remain small even though the total card count is large. Scrolling a palette into view may raise it temporarily; moving away should reduce it again.

## Revision 360 Export panel and large-level JSON

Do not add a live full-level textarea back to the Level Editor. Level 002 serializes to roughly 2.5 MB and 60,000 indented lines. Physical Chrome and Opera dropped from about 40-45 FPS to about 1.4 FPS when only the old Export panel was expanded, despite renderer submission remaining below 5 ms.

The Export panel now shows only a compact summary. Use `serializeLevelJson()` inside explicit button actions. Copy, download, browser-copy save, playtest, and Canvas-baseline launch generate the string on demand. **Open JSON in new tab** creates a temporary text Blob in another page. Routine `updateJson()` calls synchronize level metadata and refresh the summary but must not call `JSON.stringify()`.

`devel/benchmark_level_editor_playwright.py` expands the Export panel before measuring and reports `exportSurface.textareaCount` and `textareaCharacters`. Both must remain zero.

## Revision 361 Level actions and editor camera alignment

The Level Editor no longer has an Export panel. Use the controls in **Level**: **Save Level (json)** saves the authored level, while **Save temp copy** and **Load temp copy** use the generated `resources/levels/level_temp.json`. Complete level JSON must not be stored in `localStorage`; large authored levels can exceed browser storage quotas. Do not reintroduce Copy JSON, Open JSON in new tab, a JSON summary panel, or any persistent serialized text surface.


**Play** first writes the current editor snapshot to `resources/levels/level_temp.json` through the shared project host, then opens `game.html?level=level_temp&playtest_browser_copy=1` in Chrome or asks IgnatiusDevTool to launch the native game with the same generated level. A successful editor playtest is a direct-play launch: the game must initialize the authored level, finish renderer preparation, and leave the title screen immediately. Do not require a second click on Start, and do not move this decision into portable simulation state. Ordinary `game.html` launches still begin at the title screen.

For static editor and diagnostic cameras, call `renderer.setViewOverride({ x, y, cssZoom })`. Do not multiply editor zoom by `devicePixelRatio` outside the renderer. The renderer resolves CSS zoom after resize from the exact backing/client ratio, and the editor overlay resolves its own backing transform the same way. Ordinary playing-area guides use the unmodified editor camera. Apply `computeCaveWindowParallaxOffset` only to cave-window geometry and `caveForeground` records. Apply `computeWorldParallaxOffset` with `level.layerVisuals.background.parallaxX` and `parallaxY` only to level-owned Background placements; entity-local `decorBack` parts remain attached to their actor.

## Revision 362 Level data controls and renderer-cache terminology

The Level panel has two groups. **Existing Level:** is only for choosing and loading a shipped level. **Level data:** owns New, Import, Export, Load temp copy, and Save temp copy. The temp-copy buttons use the same generated `level_temp.json` file as playtesting. Import uses a hidden file input triggered by the visible button; clear its value before opening the picker so importing the same filename twice still fires `change`.

Do not describe the current Level Editor as tiled. The retired editor tile cache, zoom tiers, WebGL editor backend, and translated pan snapshots are absent from the active path. The production Canvas renderer still keeps normal resource and derived-effect caches, including loaded atlas images, recoloured atlas surfaces, treated cave-foreground frames, cave masks, and spatial-query data. Those caches are expected and should not be removed merely to make the renderer “uncached”; they are not screen-space tiles and panning still redraws the visible viewport directly.

## Revision 363 editor context transforms

The Level Editor's two visible canvases deliberately use different context matrices. The production scene canvas must remain at identity because `canvas-renderer.js` calculates and draws in backing pixels. The guide overlay draws in CSS-pixel editor coordinates, so it uses `overlay.width / viewport.width` and `overlay.height / viewport.height` as its context scale. Do not copy the overlay transform onto the scene context.

This distinction matters on fractional display scaling. At DPR 1.1, pre-scaling the scene context and then supplying renderer backing coordinates enlarges the scene by another ten percent while guides remain correct. The apparent error grows toward the lower-right corner. Use `devel/benchmark_level_editor_playwright.py --device-scale-factor 1.1` when changing canvas sizing or renderer embedding; `stageContextTransform` must remain identity after a rendered frame.


## Revision 364 Android presentation stability

The production game does not request low-latency desynchronized canvas presentation. Keep `desynchronized: false` for both the visible Canvas2D context and the WebGL2 backend. This is deliberate: Android Chromium-family browsers may otherwise expose incomplete Canvas pixels or a discarded WebGL buffer as white or black flashes.

The stage fills `#game-shell` with percentage dimensions. The renderer ignores transient client measurements below two pixels and keeps the previous valid backing size. When investigating future mobile resize problems, do not “fix” this by resetting the canvas on every reported viewport transition; assigning `canvas.width` or `canvas.height` clears the backing store immediately.



## Revision 547 Puppet Forge direct-transform editing

Selecting a scalar X, Y, Rotation, Scale, or Alpha row/key in the full dopesheet intentionally exposes that single track in the numeric Keyframe controls. It must not disable canvas manipulation. While **Adjust** is active, hovering the selected part still exposes its move/rotation cursor; pressing the selected part or one of its yellow corner handles automatically switches the Property selector back to **X, Y and Angle (drag)** and begins the gesture immediately. The user must not have to reselect Adjust or manually repair the Property selector after visiting a dopesheet track.

For looping clips, an authored key exactly at `duration` is invalid as a distinct phase because cyclic runtime sampling maps that instant to time zero. Puppet Forge keyframe writes therefore canonicalize an exact loop endpoint to time zero. One-shot clips keep their real terminal endpoint. This prevents the selected part from appearing frozen while edits are accidentally written into a terminal key that cyclic preview/runtime playback will never display.

## Parent pivot constraints in Puppet Forge

In **Base rig / setup values**, enable **Pin this part's pivot to a parent part** to keep the selected part's existing pivot fixed to a point on another rig part. Choose the parent and edit the normalized parent-point X/Y values, or drag inside the selected constrained part in the preview. The cyan marker shows the resulting joint. Dragging a yellow corner still edits the child's rotation.

A constrained part's X/Y animation tracks are read-only because Puppet Forge calculates them from the parent. Refreshing or downloading animation JSON bakes the calculated positions into ordinary X/Y keys for the game when the base/original rig is active. Alternate appearance rigs are preview-only for shared animations and never trigger this bake. Rotation and scale remain independent. Disable the constraint to return to ordinary X/Y editing; the latest baked positions remain available as normal keys.

Puppet Forge may therefore add X/Y keys that you did not place manually. They are adaptive samples used to keep the child socket attached while its parent rotates or scales. In looping animations, exported generated tracks end before the clip duration and interpolate back to the time-zero pose; a key exactly at the duration is redundant and must not be emitted. Non-looping animations may end with a generated key at the exact duration.

Each child may have only one parent constraint. Puppet Forge prevents self-links and circular chains such as torso to arm to torso.

## Revision 629 shared effect parts and animation-local exclusions

Shared visual rig parts come from `resources/characters/ct_effects_001.json`. Puppet Forge loads their atlas/image resources before applying an Add effect part edit, and structural rig additions are synchronized into every mapped animation rather than only clips that happen to be open. Effect-library parent defaults such as Rocket Flame's rocket/nozzle attachment remain library data rather than enemy-specific editor rules.

The **Remove from this animation** button excludes the selected rig part only from the current clip. This writes the part name to that animation's `hiddenParts` array. The rig part remains in the character and all other animations are untouched. Existing keys in the excluded clip are deliberately preserved, so **Restore to this animation** removes the exclusion and immediately restores the authored motion. Both JavaScript and native animation sampling force excluded parts to alpha zero.


## Revision 454 OGG music workflow

`resources/music/music.json` is the active music catalog. Add numbered files such as `music_006.ogg` beside it in `resources/music/`, then add a matching metadata record with an ID, file name, and title. Levels store only `music.version: 3` and `music.trackId`; the Level Editor populates its selector from this catalog. Runtime playback belongs to `src/browser/music-director.js`, which wraps a looping HTML audio element and obeys pause/focus muting and the persistent music-volume slider. Do not restore the embedded jukebox engines, score-source catalog, or synthesized tune data.

## Revision 373 retired music integration

This historical note described the retired synthesized/jukebox catalog. The active workflow is the revision 454 OGG catalog above.

The selector engines and hidden iframe host have been removed.

When changing playback state, preserve the distinction between track changes and pause/focus muting. Track changes select a new OGG source and reset playback; pause/focus muting pauses the audio element without modifying persisted settings. Never copy browser audio state into simulation data.


## Revision 374 music gesture handling

`game-bootstrap.js` intentionally listens for broad `keydown` and `pointerdown` gestures because browser autoplay policy can reject an earlier non-gesture start. Those listeners may call `musicDirector.unlock()` many times during normal play. Never make `unlock()` directly synonymous with “restart playback.”

The director must first compare the active engine/tune/octave configuration with its playback state. If that configuration is already playing, return success without calling the host. If a start for the same configuration is still pending, return the same promise so key repeat and nearly simultaneous pointer/keyboard input cannot schedule duplicate starts. Clear active playback state when pausing, muting, setting music volume to zero, changing tune, or disposing. This keeps intentional resume behavior distinct from ordinary movement and jump gestures.


### Background and Foreground layers (revisions 375-376)

The Level Editor presents four authoring names: **Background**, **Terrain**, **Decoration**, and **Foreground**. The serialized IDs are `decorBack`, `terrain`, `decorFront`, and `caveForeground`. Do not describe `caveForeground` as the perimeter layer in user-facing controls. The perimeter is one generator that happens to create Foreground records; manually placed Foreground artwork uses the same layer without generator provenance.

The Asset palette has one **Layer for new assets** state with **Foreground**, **Terrain**, and **Background**, exposed in both compact and expanded views, plus one shared **Place asset** tool. Selecting an asset card in either view enters that same placement mode; the toolbar button opens the expanded chooser rather than maintaining a second selected-asset state. Do not restore separate Background and Foreground placement tools: preview and placement must read the dropdown and route through the matching authored-coordinate transform.

Choose **Background** for distant cosmetic scenery. Background records never receive atlas collision and cannot be moving platforms. They render in a dedicated pass before all ordinary world artwork regardless of stack order. `level.layerVisuals.background.parallaxX` and `parallaxY` control horizontal and vertical drift independently for the entire layer. Both default to the exact reciprocal of the Foreground default: `1 / 1.08`, approximately `0.925926`. Set an axis to `1.0` when it should have no relative drift. The allowed editor range for each Background axis is `0.01` through `1.0`.

The Background panel also owns a separate optional **Backdrop** convenience control. This is not a Background-layer placement and is not the repeating Background asset. It serializes at top level as `level.backdrop = { atlasId, assetId }`. The renderer first clears to the normal deep-blue level colour, then draws the Backdrop once, centred on the viewport and scaled by `max(viewportWidth / imageWidth, viewportHeight / imageHeight)` so it completely covers the viewport without letterboxing. Excess image area is cropped symmetrically. Camera position, editor zoom, Background parallax, Background brightness/colour treatment, and Background scale do not affect it. The existing repeating Background asset and ordinary Background scenery render afterward, so transparency in either can reveal the Backdrop beneath. Clearing the Backdrop restores the deep-blue fallback.

Choose **Foreground** for inert artwork in front of actors. `level.layerVisuals.foreground.parallaxX` and `parallaxY` both default to `1.08`; `1.0` disables relative movement on that axis. Foreground treatment, the cave opening, feather contours, and generated perimeter art share both offsets. Runtime reads the grouped layer values directly every frame and passes the same normalized factors to Foreground culling, drawing, cave interaction, and the Canvas/WebGL cave mask. Each Foreground axis accepts `0.01` through `1.25`. Do not copy either value into `caveWindow`. Choose **Terrain** for ordinary placed artwork whose atlas collision may remain active.

Every atlas placement also supports an optional `onTop: true` presentation flag. The Level Editor exposes it as **On top** beside the compact **Collision** checkbox. Absent or false is the default. Background placements still remain behind Terrain, but `onTop` puts them after ordinary Background artwork. Terrain and Decoration placements with `onTop` render after actors and projectiles. Foreground placements with `onTop` render after ordinary Foreground artwork, while the cave-window black mask remains the final world-space pass. `onTop` is presentation-only: it must not alter atlas collision, moving-platform ownership, obstruction polygons, navigation support, or editor collision guides. Levels using `onTop` bypass browser static-layer baking until the extra partitions gain their own bake surfaces; live Canvas2D and WebGL rendering remain authoritative.

Both layers use world-bounds-centred offsets from `src/presentation/world-parallax.js`. Editor pointer operations add the active offset before storing authored coordinates, while drawing subtracts it. Never save camera-relative coordinates into the level. When adding new editor operations for these layers, pass records through `displayedLayerPlacement` or the equivalent shared transform so selection and rendering remain aligned.


## MP4 motion reference in Puppet Forge (revision 377)

Open **Motion reference video** in Rig and animation mode and choose a local MP4. H.264 video in an MP4 container has the broadest browser support. The video is muted and loaded through a temporary object URL; no reference media is copied into the project.

The animation playhead drives the visible video moment. Scrubbing, stepping, pausing, preview speed, and animation looping keep the MP4 aligned. **Video time offset** adds to animation time, so a positive value looks later in the clip. Use X/Y to align the person, Width/Height for independent scale, Opacity to ghost the plate, and `1.0` animation preview speed when checking source timing most literally. **Reset alignment** preserves the source aspect ratio, centres the video on local X, and bottom-aligns it to local `y = 0`. The plate follows preview zoom, pan, and facing.

The MP4 and its controls are intentionally temporary. They do not mark any project document dirty and are never included in character, rig, atlas, animation, enemy-catalog, or level JSON. Reloading or closing the tab discards them. Puppet Forge does not support image bundles as motion references.

## Mountain King orchestration correction (revision 378)

The embedded orchestrated engine marks Mountain King's quiet bassoon octave double with `followsPrimaryMelody: true`. The long-form arranger must preserve every note in marked voices just as it preserves voice zero. Do not replace this with an alternating `accentedCopy(..., 2)` or allow sparse accompaniment plans to thin it; either change recreates the audible impression that melody notes are missing or being reassigned between instruments.

## Foreground and Background visual groups (revision 379)

Open **Layers** to configure the two inert cosmetic layers. Foreground and Background each expose **Parallax X**, **Parallax Y**, **Brightness**, and **Scale**. Parallax `1.0` follows the world on that axis, while the minimum `0.01` produces almost stationary movement. Brightness and scale `1.0` preserve source colour and authored size, but the Foreground defaults intentionally show its complete cave treatment directly: brightness `0.36` and scale `2.0`. Foreground parallax starts at `1.08` on both axes; Background starts at `1 / 1.08` on both axes, with neutral brightness and scale. These values affect every placement in the layer, including cave-perimeter assets because those are Foreground records.

The **Perimeter** panel is intentionally limited to cave geometry, feather and gradient behavior, spline point editing, and generated-foreground visibility. Foreground/background generation belongs in **Generator**. Do not restore duplicate Foreground scale, brightness, or parallax controls there. `level.layerVisuals` version 3 is the sole level representation of both cosmetic layers, with `parallaxX` and `parallaxY` required for each group. The retired single `parallax` fields, top-level mirrors, and cave-decoration brightness/scale fields are unsupported. All project levels were converted by copying their former scalar to both axes.

Background and Foreground remain inert presentation. They never have atlas collision or moving-platform behavior. Layer scale must be applied around the authored placement centre, and editor culling and pointer geometry must use the same scaled display bounds as rendering.

## Mountain King upper voice treatment (revision 379)

The full bassoon octave double introduced by the revision 378 continuity correction remains marked `followsPrimaryMelody`. Do not thin or alternate it. Its voice-local timbre override lowers the cutoff, slows the envelope, reduces breath noise, extends release, and lowers gain while retaining the bassoon instrument and all note events. Tune-specific timbre overrides belong inside the embedded browser engine and must not enter portable level or shared music schemas.


## Visible Foreground treatment (revision 381)

Foreground artwork is stored at base size. Runtime and editor rendering apply only `level.layerVisuals.foreground.scale`, and foreground sprite treatment receives the layer brightness plus the perimeter decoration saturation. The shipped levels expose their complete treatment directly: level 001 uses brightness `0.4` and scale `2.0`; level 002 uses brightness `0.46` and scale `2.0`. Per-placement brightness, scale, outward-vector, and fade-interval fields are unsupported. The cave-window mask owns the only spatial fade, so moving an asset away from the perimeter immediately reveals its clean colour-treated frame.

The Layers panel contains no persistent defaults paragraph; explanatory copy belongs in native mouse-over tooltips on the controls.

## Level Editor sidebar order (revision 382)

The right sidebar is arranged as **Level**, **Metadata**, **Layers**, **Perimeter**, **Colormap**, **Generator**, **Autospawner**, **Navigation graphs**, **Entity palette**, **Asset palette**, **Placed objects**, **Selected object**, and **View**. This puts file-level actions and compact level identity first, world-construction tools next, object catalogs and inspection after them, and viewport preferences last.

Do not move the eight cosmetic-layer fields back into Metadata. **Layers** is the sole user-facing home for Foreground and Background Parallax X, Parallax Y, Brightness, and Scale. **Perimeter** is reserved for the cave-window spline, mask, feather, and gradient. Decoration generation belongs in **Generator**.

## Stable layer controls and scaled outlines (revision 383)

The independent **Generate foreground** and **Generate background** commands replace only records owned by their respective decoration generators; manual records remain untouched. They must not modify any value in **Layers**. When reading the layer controls, commit a canonical `level.layerVisuals` version 3 object with independent `parallaxX` and `parallaxY` fields. There is no retired-schema migration path; old levels must be patched to current data before they enter the project.

Foreground and Background artwork is stored at base size, then transformed for display. Selection outlines and asset-guide boxes must use the transformed record returned by `displayedLayerPlacement` for centre, width, height, rotation, and parallax position. Using the transformed centre with the unscaled authored dimensions produces the small displaced boxes fixed in this revision.



## Current-level-only schema policy (revision 384)

The repository contains every supported level. Runtime, Level Editor, generator normalization, and tests therefore target only the current bundled schema. When a level format changes, update all shipped levels and fixtures in the same revision. Do not add aliases, mirror fields, import migrations, retired entity translations, or silent old-record stripping. A stale external level may fail validation or lose unsupported records; preserving it is not a project requirement.

Normal current-schema validation, numeric clamping, and defaults used while creating a new level remain appropriate. The prohibition is against alternate historical field names and conversion branches. Tests should verify the canonical schema and guard that retired paths stay absent, not exercise conversions from unsupported old levels.


## Automatic generator upper branches and reward mix (revision 416)

Generator schema version 34 retains the optional secondary supports introduced by version 32 with `secondaryTier` and `powerUpPerch`. Horizontal routes use a two-step ceiling lane with at least 36 percent span coverage. Standard routes create more first-tier branches and extend selected branches into a second tier. Encounter generation may seat monsters on combat perches at either tier.

The reward catalog is version 3. Power-up weights are `wrenchPickup: 6`, `overdrivePickup: 3`, and `shieldPickup: 1`. A generated Overdrive with context `detourUpperPerch` must reference an optional second-tier `powerUpPerch`. Fixed seating remains important because encounter reservations are built from reward envelopes before the encounter stage; reward rerolls may change types but must not move those seats.

Level 001 has three baked hunter profiles: goblin, tall human, and Skeleton Caster. Keep the caster profile separate because its 72 by 164 body and movement values do not match either other family. The placed Skeleton Guard should mirror the catalog melee damage of 50.

## Empty Level Editor documents (revisions 417 and 717)

The **New level** command creates a bounded but otherwise empty authored level. The production runtime converter accepts that document so the editor can render the blank world immediately. Do not add hidden placeholder assets or entities to make the preview work. A payload with neither authored content nor finite positive world bounds is still invalid. The editor continues to discover atlas and numbered-level files through ordinary URL probes, so expected 404 responses at the end of those scans are not conversion failures.

New manually authored levels start with the same broad layer-transform convention as the opening of `level_006`: Foreground parallax X/Y `1.08` with scale `2`, and Background parallax X/Y `0.95` with scale `5`. These are **New level** authoring defaults only. Do not change the shared normalization fallbacks to enforce them, because missing fields in an existing level must continue to use the generic compatibility defaults rather than silently adopting the `level_006` presentation. Generator recipes control their own layer settings separately.

## Generated population density (revision 418)

At a theme's default **Enemy density**, generated levels target one monster per 500 horizontal route units. This is based on left-to-right span rather than winding path length. Long platforms can hold several independently spaced encounters, matching ordinary authored levels; the generator still protects incoming landings, endpoint calm zones, rewards, moving-platform shafts, and unrelated platform artwork. The Enemy density control scales the target and zero disables all generated encounters.

Generated power-ups now target one pickup per 3,000 mandatory-route pixels, one third of the revision 417 count. Their type mix remains 60 percent authored wrench, 30 percent Overdrive, and 10 percent Shield, with Overdrive still preferentially assigned to dedicated upper detours. Generator schema version 33 stores the new behavior.


## Generated monster density (revision 419)

At a theme's default **Enemy density**, generated levels now target one monster per 300 horizontal route units. The target remains based on mandatory-route left-to-right span, and the existing Enemy density control still scales it from zero up to the capped double-density rate. Long-support multi-seat placement and all existing calm-zone, reward, collision, cavern-fit, landing, and moving-shaft protections remain active. Generator schema version 34 identifies this denser population contract.

## Revision 435 420-base level-generator backport
- Rebased the project on the original revision 420 codebase while backporting the revision 432 automatic level-generator implementation.
- Retained the Rising Cave rename, Serpentine Cave route, same-flow diagonal Serpentine rise support, and generated horizontal floor-layer logic from the generator line.
- Deliberately excluded cave-window, full-black perimeter, editor rendering, and arc-rounded perimeter experiments after revision 420.

## Revision 420 endpoint population contract

Generator schema version 35 records exact `endpoints.entrance.x/y` and `endpoints.exit.x/y` coordinates. Encounter and reward exclusion must use those portal coordinates, not the centre of the supporting platform.

Endpoint protection is intentionally local. Earth encounters preserve 520 world units around each portal and Ice encounters preserve 540. Do not expand this distance to the largest enemy awareness range; doing so wastes one or more complete screens. Encounter candidate ordering uses a distributed route order and explicit endpoint-local fallback seats so bat groups or a blocked preferred seat cannot exhaust the monster target before the final screen is considered.

Physical rewards may use the complete route progress range. When treasure generation is enabled, the far side of each door platform receives one chest if it clears the theme's endpoint exclusion distance. Earth uses 300 units and Ice uses 320. Upper reward perches may consume only a bounded share of the chest target; all remaining chest targets are spread over the full normalized route range. Reward-only rerolls must preserve the endpoint and encounter streams exactly.

## Runtime transform triplets and interpolation (revisions 504-505)

Simulation-driven actors, projectiles, the camera, the hat, and moving world visuals no longer expose their root position through direct `.x` and `.y` properties. Use `subject.currentTransform` in simulation/gameplay code and `subject.shownTransform` in presentation code. Both records contain `x`, `y`, `angle`, `scaleX`, `scaleY`, and `alpha`; `previousTransform` stores the state immediately before the latest fixed step.

Use the helpers in `src/shared/presentation-transform-data.js` to create, copy, snapshot, interpolate, show, or snap a transform. Never assign one transform object to another variable as a state copy and never replace the persistent records during a frame. `copyTransform(target, source)` and `interpolateTransform(target, previous, current, blend)` mutate six numeric fields in place and avoid garbage collection pressure.

Character-enemy animation time follows the same boundary through `enemy.animationClock.previous/current/shown`. Simulation updates `current`, while the renderer samples `shown`. Articulated limb transforms remain generated presentation data; do not create previous/current/shown copies for every limb unless a limb becomes an independent physics object. When an enemy changes animation slot, reset and snap its animation clock together so the new clip is not sampled at an interpolated time inherited from the old clip.

Revision 505 passes `accumulator / FIXED_DT`, clamped to 0-1, into `preparePresentationFrame(state, blend)`. Position, scale, opacity, and simulation-driven animation time use linear interpolation. Angles use the shortest wrapped path. A scale sign change snaps to the current value rather than collapsing through zero. Paused and single-step presentation uses a full blend so the newest stepped state is visible immediately.

When diagnosing gameplay, inspect current. When diagnosing a drawn position, inspect shown. Level loads, resets, respawns, development pose changes, animation-slot resets, teleports, and camera cuts must call the relevant snap helper so previous, current, and shown agree. Interpolation is presentation-only and must never write shown values back into collision, AI, targeting, or serialization.

## Tiled-bake micro-stutter diagnostics (revision 506)

Start and stop the lower-right profiler button as before. While the profiler is active, tiled baking adds flat `staticTile...` fields to each sample's `renderer` record. Normal play does not collect these subphase timings.

The principal timing fields are `staticTileWorkerCollectMs`, `staticTileCompletedAdoptionMs`, `staticTileAtlasAllocationMs`, `staticTileTextureUploadMs`, `staticTilePlanningMs`, `staticTileEvictionMs`, `staticTileJobSchedulingMs`, `staticTileDiagnosticsMs`, `staticTileCacheEnsureMs`, and `staticTileDrawMs`. Worker collection occurs asynchronously and is charged to the next tiled frame. Texture-upload time measures JavaScript submission around `updateTextureRegion`; it does not prove when the GPU finishes the work.

Upload-bearing samples include `staticTileUploadBurstId`, logical tile coordinates, atlas page/slot coordinates, upload dimensions and bytes, camera coordinates, camera tile coordinates, and tile-to-camera deltas. Consecutive uploads no more than four tiled frames apart share one diagnostic burst ID. The report summary's `staticTile` section totals uploads, bytes, evictions, jobs, and burst count and retains the maximum subphase times.

Use matched routes and settings for comparison. A useful pair is WebGL2 with Baking Off as the control and WebGL2 with Baking Tiles as the experiment. Do not infer GPU completion latency solely from a small `staticTileTextureUploadMs`; the profiler intentionally avoids `gl.finish`, readback, fences, and timer queries because those probes can manufacture or reshape the hitch being investigated.

## Frame-delivery captures (revision 508)

Start **Profiler: off** from the lower-right development tool strip. The profiler records every frame and includes `callbackEntryGapMs`, `callbackLatenessMs`, `renderMode`, and `presentation` on each sample. `rafGapMs` remains the interval between browser-supplied rAF timestamps. `callbackEntryGapMs` is the measured interval between actual JavaScript callback entries and is the better field for detecting a callback that arrived late despite regular rAF timestamps.

After a visible hitch, click **Profiler: on** again as soon as practical. That stops the recording and copies the newest bounded capture to the clipboard. The ring retains the latest 900 frames, about fifteen seconds at 60 Hz, so a hitch remains available when the profiler is stopped within that window. Run one renderer/baking mode per capture.

`presentation.player` and `presentation.camera` contain current and shown coordinates and their deltas. `presentation.playerScreen` subtracts shown camera motion from shown player motion. A whole-world hitch should be visible in camera/world delivery even when the player remains stable on screen; an actor-only discontinuity should appear in player or player-screen deltas. `presentation.snap.events` identifies snap helpers called since the previous sample and includes the latest reason, subject, and kind.

`renderMode.backend` and `renderMode.bakingMode` are repeated per sample rather than inferred from the final report metadata. This matters when a recording accidentally spans a settings change. The profiler still cannot prove whether the desktop compositor displayed or repeated a submitted frame, but callback-entry and shown-motion data can separate application pacing from that remaining blind spot. Revision 508 removes the redundant **Mark stutter** control and its separate clipboard state; the profiler toggle is the sole in-game capture workflow.

## Gameplay recording and playback parity workflow

Revision 511 adds browser-side gameplay recordings for comparing the JavaScript game with the SDL/C++ port. Launching `game.html?level=2` starts `level_002` immediately and skips the title screen. Launching `game.html?level=2&record=1` starts that level and records gameplay from the initial state. The lower-right development strip also includes `Recording: Off/On`; switching it off saves the current recording as JSON through the File System Access API when available, otherwise through a normal download.

A recording can be replayed from the UI with `Playback JSON…`, or by placing it in a hosted `recordings/` folder and launching `game.html?playback=record001.json`. The playback path restores the recording's initial game state and feeds the recorded frame timing and input snapshots into the ordinary fixed-step loop. For screenshot parity checks, add `playback_pause=120.2`; playback pauses after the first recorded frame at or beyond that timestamp and resumes on any key press.

The JSON schema is `ignatius.gameplayRecording` version 1. Each frame records the rAF requested timestamp, callback-arrival timing, real delta used by the accumulator, fixed-step count, input frame, player position, camera visible rectangle in level coordinates, and visible enemy/projectile summaries. This is a browser-adapter diagnostic format and does not add file or DOM dependencies to portable simulation.


SDL build revision 142 groups the most useful diagnostics under **Settings → Development features...** in both implementations. Asset guides show the canonical walkable lines in green and blocking geometry in yellow. Enemy guide shows each visible enemy's hitbox, awareness cone, and current AI state. The native Debug panel is intentionally compact: renderer/FIFO mode, timing and fixed-step information, player/enemy summaries, and recording/playback/logging state. It has no scrolling event log and performs its overlay work only while visible.

**Debug logging** is a persisted preference. If no saved value exists, it defaults to the product `DEVELOPMENT` switch. SDL creates a fresh `logs/ignatius_debug_rev<revision>_<timestamp>.ndjson` for every application launch while the preference is enabled, appends one structured runtime snapshot per second, flushes periodically, and closes cleanly on disable or exit. The browser follows the same one-second cadence with a fresh in-memory log per page launch and downloads the current NDJSON when the preference is switched off because an ordinary page cannot silently maintain an arbitrary writable file handle. A transient file/open failure does not rewrite the saved preference. Use this low-rate log for timing and state history; use gameplay recording when deterministic input/frame reproduction is required.

### Windows incremental builds

`BUILD_REVISION.txt` at the repository root is the single authored revision source. Change only that file when advancing the build number; CMake derives the native compile-time revision from it, and the build scripts refresh `reference/BUILD_REVISION.txt` as a generated numeric mirror for ordinary static browser servers before packaging the same root value with runtime content. Do not hand-edit revision literals in C++, JavaScript, HTML, or the generated `reference/BUILD_REVISION.txt` mirror.

Run `build.bat` for the normal Windows build. It preserves `build\` and delegates dependency decisions to CMake and Visual Studio/MSBuild, so unchanged C++ translation units are not rebuilt. It also uses `robocopy` to synchronize only changed runtime assets, shader content, reference modules, and development HTML. A packaged ZIP can occasionally carry source timestamps older than existing object files; after the first incremental pass, `build.bat` verifies the executable against `BUILD_REVISION.txt`. Only when that verification fails does it refresh project-source timestamps and retry. If that retry still fails, it performs one clean rebuild. To force a fresh configure and compile manually, delete `build\` before running the script. No custom hash database is involved.


## Revision 532 rocket-fuel Flight governor

The canonical rocket-fuel effect is `POWER_UP_EFFECT_IDS.FLIGHT` with serialized ID `flight`. Authored `fuel` and `fuelPickup` entities normalize to this timed effect rather than immediately adding a fixed fuel amount. The built-in duration is 30 seconds, stacking refreshes the timer, and its Power HUD priority is 190: below every wrench at 200, above Shield at 150 and Overdrive at 100. The HUD icon remains `rocket_fuel_canister`. Flight does not modify standard no-wrench rocket damage or its secondary splash; Flight only changes movement/projectile speed and the other documented Flight mechanics.

While Flight is active, `applyFlightGovernor()` replaces ordinary gravity, jumping, and attached-boost drain. No vertical input targets zero vertical velocity; Up/jump/boost targets `-flightVerticalSpeed`; Down/drop targets `+flightVerticalSpeed`. `flightVerticalAcceleration` approaches those targets so takeoff, stopping, and direction changes have running-like inertia. Horizontal control uses ground acceleration in the air. While airborne, neutral horizontal input uses `flightIdleHorizontalSpeedFactor` to approach that fraction of the 1.5x horizontal Flight speed cap in the current facing direction; the default is `0.6666667` (two thirds). Grounded Flight does not use this idle cruise: neutral horizontal input follows ordinary ground friction so Ignatius can remain stopped, while active Left/Right control remains available. Grounded Flight is also an idle-exhaust presentation state. `emitAttachedBoostSmokeBurst()` keeps the normal attached smoke/spark recipe but multiplies new puff lifetime by `GROUNDED_FLIGHT_SMOKE_LIFETIME_SCALE` (`0.40`), while `mountedRocketExhaustActive()` suppresses both the atlas flame and High/GPU deluxe flame until the player is airborne again. Lunge and ordinary attached boost exhaust are unaffected. Setting the factor to `0` restores airborne neutral-input ground-friction braking to rest. Holding Down continuously refreshes one-way-platform drop-through grace so a direction reversal cannot outlast the drop window. Scripted cutscenes cancel Flight as soon as their trigger claims control; if the Wizard is airborne, authored commands wait while ordinary passive gravity/collision completes the landing, then horizontal/vertical velocity is cleared and command execution begins.

Flight itself never calls `markRocketUse()` and never spends hover fuel. `updateFuelRecharge()` gives Flight continuous passive recovery using `attachedBoostDrainRate * FLIGHT_PASSIVE_FUEL_RECOVERY_DRAIN_FACTOR` and the full fuel maximum as the cap. Do not add this rate to normal grounded recharge; select the larger rate. Overdrive is deliberately excluded from this passive-recovery path and instead shortens newly imposed recharge delays in `markFuelUse()`. Flight keeps the default rocket launch profile, so shooting still spends the full launch cost. Keep the JS and C++ helper names, tuning fields, update order, smoke presentation state, and expiry reset aligned.

## Cursed temporary power-up

The canonical curse effect is `POWER_UP_EFFECT_IDS.CURSED` with serialized ID `cursed`. The authored `cursedPickup` entity is a 50x50 skull from `it_atlas_001`, rendered statically at 25% opacity with `pickupPresentation: false`. Its respawn delay is 1 second rather than the normal 60-second power-up delay, and collection deliberately suppresses the ordinary pickup chime. The effect lasts 10 seconds, uses refresh stacking, clears on death, and selects the wizard `cursed` appearance rig with the dedicated `idle_cursed` and `walk_cursed` clips. While airborne, presentation freezes `walk_cursed` at 0.000 seconds; normal Ignatius retains the ordinary 0.180-second jump-pose sample.

Activating Cursed cancels Flight and every other active temporary power-up, stops attached boost, lunge, and committed body slam, clears air-boost availability, and leaves Ignatius with ordinary horizontal movement plus one normal jump. Rocket firing, attached boost/hover, Flight movement, lunge, and body slam remain blocked for the duration. Non-Cursed temporary pickups touched during the curse are collected but ignored rather than becoming active. Re-collecting Cursed refreshes its timer. The existing cancellation path intentionally leaves lunge/body-slam recharge latches rearmed; do not preserve the pre-curse latch state unless that gameplay rule is explicitly changed. The fixed Rocket Fuel HUD deliberately remains visible while Cursed and continues to show the retained fuel amount.

Use the shared `smokeParticle` / `emitSmokeParticlesAtRect` effect for visual transformation clouds. Emit smoke on the inactive-to-Cursed transition and on natural status expiry, but not when an already-active curse is refreshed and not when death/reset merely clears the effect. Status expiry owns its smoke immediately when the timer reaches zero; later processing in the same simulation step may therefore also begin death or collect a newly respawned skull. That ordering is intentional. Keep these status, smoke, pickup-sound, and presentation rules aligned in JavaScript and C++.

## Authoring and tuning water regions (revision 206)

In Atlas Forge, choose **water** from the collision-guide kind selector and draw a closed loop exactly as for a blockable polygon. The editor fills a valid region in translucent blue. Keep the loop closed and non-self-intersecting. Water is invisible during normal play; enable Asset guides to inspect it in the browser or SDL runtime.

Water is a volume, not a surface collider. A wizard whose body overlaps the polygon can swim left, right, up, and down at reduced speed. With no input, gravity and buoyancy leave a slow downward drift. There is currently no breath meter. The water surface itself never deals fall damage. Braking is accumulated while travelling through the volume, so a deeper pool arrests a faster fall and a shallow pool may leave enough downward speed for an underlying blockable floor to cause normal landing damage.

The shared tuning fields are `waterHorizontalSpeedScale`, `waterHorizontalAccelerationScale`, `waterGravityBuoyancyRatio`, `waterSwimAcceleration`, `waterLinearDrag`, `waterQuadraticDrag`, `waterHorizontalLinearDrag`, and `waterHorizontalQuadraticDrag`. Keep JavaScript `DEFAULT_TUNING` and C++ `FGameTuning` values aligned. Test changes with both the deep-pool and shallow-pool parity benches rather than judging only low-speed swimming.

Backpack boost, Flight movement, and player rocket firing are intentionally blocked while submerged. The blocked actions do not consume fuel. Existing enemies regard water as forbidden navigation/collision space; add an explicit aquatic movement capability before introducing swimming enemies such as piranhas.

## Campaign level numbering and test fixtures (revisions 207 and 223)

The ordinary `level_###` namespace contains mutable authored content. `level_001` through `level_020` belong to the campaign, and files that still resemble the original one-floor cave scaffold may be freely expanded as their real terrain, enemies, and story content are authored. Tools and tests must not assume that any numbered campaign level remains a scaffold or retains a particular placement/entity count. Any test, headless smoke run, benchmark, or release verification that loads a level must use a reserved `level_tNN` fixture; an apparently empty campaign level is never a test fixture. Ordinary `level_###` identifiers may be used only by tests of identifier parsing or serialization that do not load the corresponding file.

The 800-series contains playable experiments and preserved authoring work. These files are also mutable content, not regression fixtures. Their current exits may remain sequential within the experimental range, but unit tests must not depend on their exact contents.

Use only `level_t01` through `level_t99` for file-backed tests. The `level_tNN` namespace is intentionally unreachable from normal campaign progression, may be copied from an authored level when a stable snapshot is needed, and may then evolve solely to support deterministic regression coverage.


## Enemy and boss drop tables (revision 210)

Ordinary enemy rewards are authored in the character project's `drops` array. A boss entity owns a complete replacement `drops` array in the level JSON. Do not merge the boss table with the underlying character table: a Fireball Goblin promoted to boss uses only the boss entity table and therefore does not also drop the ordinary goblin coin.

A `drops` array is one ordered weighted table and may emit at most one pickup per death. Each entry uses `{ "itemId": "coin", "chance": 0.5 }`, where `chance` is an absolute probability slice. The first matching slice selected by the deterministic roll wins. If all chances total less than 1.0, the unused remainder means nothing drops. The current boss table contains four permanent upgrades at `chance: 0.25`, so exactly one is guaranteed and all four are equally likely.

Reusable item definitions remain in `resources/items/it_loot_001.json`. Permanent upgrade collection emits `SCREEN_MESSAGE_REQUESTED`, which presentation adapters show as a short centered notice. The current messages are `Max health upgraded!`, `Max fuel upgraded!`, `Regeneration upgraded!`, and `Speed has been upgraded!`. Health, Fuel, Regeneration, and Speed all use the same diminishing permanent curve: the first level gives 10% of base, and every later level closes 10% of the remaining gap toward a 2x base-stat ceiling. Fuel applies that scale to both maximum capacity and the ordinary grounded recharge cap. Regeneration applies it to both health and fuel regeneration.

## Proximity-triggered world text (revision 220)

The interactive entity catalog exposes `proximityText` as **TEXT**. It is a one-shot, world-space notification whose authored `x`/`y` coordinate is the visual center of the text. The portable simulation owns the trigger and fade state; renderers only consume the resulting opacity.

The schema fields are `text`, `fontSize`, `fontFamily`, `color`, `outlineWidth`, `outlineColor`, `triggerOffsetX`, `triggerOffsetY`, `triggerDistance`, `fadeInDuration`, `displayDuration`, and `fadeOutDuration`. Defaults are exactly `Lorem ipsum`, 100 world units, bundled `inter`, Ignatius purple `#723891` (RGB 114, 56, 145), a 3-pixel very dark purple `#0f0113` outline, a trigger at the text center, a 300-unit trigger radius, one second fade-in, five seconds fully visible, and one second fade-out. The Level Editor exposes only `Inter` and handwriting-style `Caveat`; old generic family values normalize to the closest current choice. Text is always bold.

The expected original font files are `resources/fonts/Inter[opsz,wght].ttf` and `resources/fonts/Caveat[wght].ttf`. Both browser and SDL presentation prefer those bundled files. The complete SIL Open Font License 1.1 texts and copyright notices live under `resources/fonts/licenses/`; `resources/fonts/README.md` records the official sources and exact filenames. The reorganized baseline includes both original font binaries. Development-only system fallbacks remain available for deliberately incomplete local trees, while an unreadable file at an expected path is treated as a resource error.

The trigger point is independent of the artwork position. In the Level Editor, select a TEXT entity and drag its circular trigger handle or edit the X/Y trigger offsets numerically. The dashed trigger guide is editor-only. Runtime distance is measured from the wizard center to the authored trigger point. Once triggered, the notification completes its full timing sequence even if the wizard walks away, marks the entity `complete`, and does not retrigger during that level instance. Native text textures are prewarmed when the level is loaded so first display does not perform synchronous font rasterization on the frame path.


## Deferred level colour treatment (revision 221)

The Level Editor **Colormap** panel is layer-specific for the three environment layers: **Background**, **Terrain**, and **Foreground**. Each layer has independent selective hue rotation, GIMP Color Exchange, and Color Balance settings. Manual hue-rotation edits apply to the full selected map layer rather than preserving hidden generator atlas allowlists. Colour replacement is disabled by default on every layer; Background and Foreground still store useful disabled balance presets so enabling them gives an immediate cave-art starting point. Both source/target pairs use native colour inputs, so the host colour picker and sampler are available without permanent help text in the panel. GIMP exchange thresholds default to `1.0` for red, green, and blue in both Level Editor and Character Editor controls.

Changing any Colormap value keeps the preview canvas for the currently selected palette asset, and also redraws every selected atlas placement on the currently selected environment layer with the pending treatment. This map preview is transient overlay artwork: it does not alter level JSON, the runtime world, or atlas-wide caches, and it works for multi-selection while the native colour picker remains open. Unselected layers and the atlas palette continue showing the last applied settings until **Apply** is pressed. **Reset** loads the selected layer's default values into the pending controls and both previews; press **Apply** to commit that reset.

The level schema stores the treatments under `layerVisuals.background`, `layerVisuals.terrain`, and `layerVisuals.foreground` as `colorMap`, `colorExchange`, and `colorBalance`. `colorExchange` uses `enabled`, `fromColor`, `toColor`, `redThreshold`, `greenThreshold`, and `blueThreshold`. `colorBalance` uses `enabled`, per-channel gains `red`, `green`, `blue`, and `saturation`. Application order is GIMP exchange first, then selective hue rotation, then Color Balance. This order is shared by the browser runtime, native SDL atlas loader, foreground brightness/saturation derivatives, background derivatives, and editor preview.

Apply invalidates every loaded atlas treatment cache, eagerly rebuilds atlases referenced by the level plus the active atlas, and leaves the remaining palette atlases lazy. Opening or drawing one of those atlases rebuilds it once with the committed cache key. Do not restore control-change handlers that call the atlas-wide refresh path.

## Projectile-art trail palettes (revision 222)

Ordinary enemy fireball trails derive four representative colours from the projectile frame during character-project loading. The palette is cached on the final projectile asset, after any projectile-part GIMP Color Exchange, and particle rendering only interpolates those cached colours. Keep palette extraction out of simulation and out of gameplay draw/update loops.

When adding a projectile variant, author the projectile frame or recolour its projectile rig part; no separate trail colour field is required. Skeleton Caster undeath orbs intentionally bypass this mechanism and retain their procedural green bubble trail.


## Revision 225 resource organization

Runtime files are organized under `resources/atlases`, `characters`, `editor`, `fonts`, `generator`, `items`, `levels`, `music`, `sfx`, and `ui`. Use category-relative paths in authored JSON and editor code. Run `npm run audit:resources` before committing resource changes; it is also invoked automatically by every browser test gate. Editable XCF source material belongs under `reference/authoring`, not in runtime resources.

## Fullscreen reference presentation (revision 230)

Fullscreen uses a 1920x1080 virtual reference rather than the physical display dimensions as the camera viewport. The shared helper is `src/shared/fullscreen-presentation-data.js` in the reference port and `src/shared/fullscreen-presentation-data.{h,cpp}` in the native port. Use one uniform crop-to-fill scale, `max(outputWidth / 1920, outputHeight / 1080)`. Do not add black bars and do not widen the camera merely because the display has more pixels.

The physical backing surface must remain at the actual output resolution. At 3840x2160 the logical view is still 1920x1080, but textures are rasterized across the complete 4K target. On non-16:9 outputs the visible logical width or height is smaller because the reference frame is center-cropped. Windowed mode intentionally keeps the physical window dimensions as its variable logical viewport. Mouse, touch, and pen input must be transformed back into logical render coordinates before menu or gameplay hit testing.


## Resource inventory (revision 240)

Authoring discovery is controlled by `resources/resources.json`. Add a new environment atlas ID to `assetAtlasIds` and a new authored level ID to `levelIds`; order in the arrays is the order shown by the tools. Atlas IDs may extend beyond `at_atlas_099`. Each listed atlas must have matching JSON and PNG files under `resources/atlases`, and each listed level must have a JSON file under `resources/levels`.

The Asset Tool and Level Editor retry declared files before reporting an error, so a temporary retrieval failure is no longer mistaken for the end of a numbered sequence. Run `npm run audit:resources` after manual additions. The audit rejects missing declarations, stale declarations, duplicates, malformed IDs, and incomplete atlas pairs. `level_temp.json` is generated only for DevTool playtesting and must not be listed.

When saving a genuinely new level or atlas from IgnatiusDevTool, saving into the authoring resource tree automatically appends its ID after the host verifies the file exists. A new atlas is added only when both its JSON and PNG are present. Manual editing of `resources.json` remains the normal and supported path for files added outside the tool.

## Revision 264 Level Editor camera guide ownership

The Level Editor's `drawGameplayCameraFrame` owns the green 1920×1080 viewfinder, rendered at 50% opacity, plus three small screen-space markers. The camera-centre marker is drawn as two one-pixel rectangles, 5×1 and 1×5, overlapping at one centre pixel for exactly nine visible pixels. Two additional five-pixel × markers indicate where a stationary wizard would rest when facing right or left, using the same `updateCameraHint` offsets of 150 world units horizontally and 170 vertically. All three markers are deliberately independent of zoom and have no text annotations. `drawGameplayCameraRulers` adds an optional cyan ruler immediately left and below that frame. It is enabled by default, remains non-serialized view state, and labels a single tick for each key movement measure: `WH`, `JH`, `DH`, `HH` vertically and `WW`, `JW`, `DW`, `HW` horizontally. The ruler distances are derived from the real default movement tuning by stepping a miniature simulation with `stepSimulation`, so the editor overlay stays aligned with gameplay physics. Do not restore the retired red parallax-alignment control or its camera-centre/parallax-zero labels. The gameplay camera frame, gameplay camera rulers, and gameplay perimeter boundary checkboxes are checked by default and remain non-serialized view controls.

## Browser minimap live transforms (revision 266)

`drawMinimap` must use `shownTransformOf(gameState.player)` for Ignatius and `renderer.getLastComputedView()` for the camera rectangle. The latter is the renderer-owned top-left world view after fullscreen crop-to-fill, zoom, and interpolation have been resolved. Keep `getViewportMetrics()` only as a startup fallback. Do not read retired top-level `player.x/y` or `camera.x/y` fields; transform-triplet initialization deliberately removes them. The native SDL minimap's equivalent source of truth is `NativeRenderView` plus `gameState.player.x/y`.



### Level Editor palette thumbnail cache

The Level Editor does not decode every full-resolution asset atlas just to populate its Asset and Entity palettes. `resources/palette/thumbnails.png` is a single compact thumbnail sheet and `resources/palette/thumbnails.json` maps each configured 64×64 or 128×128 cell to its authoritative asset atlas, item definition, or enemy character project. The sheet is trimmed to the occupied near-square grid and may not exceed 8192×8192.

Revision 272 places the browser-side builder beside the editors at `palette-builder.html`. Start the usual local server, open `devel.html`, choose **Palette Thumbnail Builder**, and click **Build thumbnails**. The development portal routes authoring through `IgnatiusDevTool.html`, whose single project-folder selector owns the resources root for all four tools. The page reuses the JavaScript character runtime, so enemy thumbnails inherit the real layered composition, idle pose sampling, and colour exchange rules instead of showing loose body-part bundles.

When opened through Ignatius Dev Tool, the builder writes `thumbnails.png` and `thumbnails.json` directly to `resources/palette`. Native builds decode project images through the same direct selected-root image route used by the editors, while the host computes source SHA-256 values from disk so large atlases are not materialized as JavaScript Blobs merely for hashing. The PNG and JSON are submitted as one root-checked output batch, and `thumbnails.json` records `imageSha256` so verification detects a stale, mismatched, or partially replaced sheet. Download links remain available for deliberate exports. The Palette Builder no longer owns a second resources-folder selector.

The root `devel.html` page is the development portal. It links to the game, shared Ignatius Dev Tool authoring shell, manuals, and renderer/review utilities so development tools do not require separate bookmarks.

The page also includes **Verify existing cache**, which checks the recorded source inventory and reports whether the committed cache is stale. Both 64px and 128px caches are supported; verification uses the `cellSize` recorded by the cache, and the Node rebuild command preserves the checked-in cache size unless `--cell-size` is supplied explicitly. The browser builder defaults new builds to 128px and keeps 64px available directly in the size selector. Full asset atlas images are loaded lazily when selected or referenced by the open level. Enemy character projects are likewise loaded only for selected or placed enemies, while their palette cards use the generated cache. Power-up and symbol-trigger thumbnails use their authored item-atlas artwork, while otherwise invisible editor entities use deterministic vector-style symbols so the cache does not depend on platform font rendering. If the cache is missing, the editor falls back to the legacy full-atlas palette path.

## Revision 303: using IgnatiusDevTool.html

Open `IgnatiusDevTool.html` through the normal local development server in Chrome, or launch `IgnatiusDevTool.exe`. The page presents the Level Editor, Asset Editor, Character Editor, and Palette Builder as tabs while keeping each tool in its existing same-origin page.

In Chrome, press **Select resources folder…** once and choose the project’s `reference/resources` directory. The shell rejects a project root, `reference`, or an unrelated directory that does not contain the expected resource inventory and subdirectories. Chrome stores the directory handle and will normally restore it on a later visit; it may ask for permission again after a browser restart or permission reset.

Project saves are routed automatically:

- Level JSON goes to `resources/levels/`.
- Atlas JSON and PNG go to `resources/atlases/`.
- Character, rig, animation, and related character JSON go to `resources/characters/`.
- Palette thumbnails and metadata go to `resources/palette/`.

A newly saved level is added to `resources.json` after the file has been written. A newly saved atlas is added only when both matching JSON and PNG files exist. Explicit export/download fallbacks remain available where a tool still needs an arbitrary copy outside the project.

Inside `IgnatiusDevTool.exe`, the native host begins with the command-line override or its packaged `content/resources` tree, but the same top-level **Select resources folder…** button remains available. Choosing another valid resources directory updates the native host, reloads all four embedded tools, and makes that folder the sole source and destination for subsequent reads, saves, and Level Editor playtests. Native saves are never mirrored into packaged resources. Text reads use the native project bridge. Generic Blob/media reads and direct project-image decoding use the dedicated `ignatius-project-resources.example` origin, which the host streams only from the selected resources root. Direct `Image` decoding uses anonymous CORS so editor canvas pixel reads remain available without materializing large atlas Blobs first. The packaged `appassets.example/resources/*` namespace is not used for selected-project images, so an interception miss cannot silently substitute packaged pixels for overridden JSON. Chrome continues to read selected-folder images as File System Access Blobs/object URLs. Individual sub-tools no longer own or create project-folder selection state; authoring is supported through the shared Dev Tool shell.


## Revision 304: overriding the native resources root

Both native executables accept `--resources-root <folder>` (or `--resources-root=<folder>`). The folder must be the actual Ignatius `resources` directory, containing `resources.json` and the normal `levels`, `atlases`, and `characters` subdirectories. Relative paths are resolved from the process working directory.

```text
IgnatiusSDL.exe --resources-root "D:\Projects\Ignatius\reference\resources"
IgnatiusDevTool.exe --resources-root "D:\Projects\Ignatius\reference\resources"
```

The Dev Tool uses the override as its sole authoring destination and passes the same absolute folder to every native Level Editor playtest. The shared HTML Level Editor writes the current snapshot to `<resources-root>/levels/level_temp.json` through `IgnatiusProjectHost` before asking the native shell to launch; the shell does not maintain a second JavaScript extraction path. The game then loads that file and every referenced atlas, character, audio, tuning, and other asset from the same root. There is no packaged fallback. A missing or unwritable playtest file therefore produces a visible failure instead of silently mixing resource trees. `level_temp` remains omitted from `resources.json` and is overwritten by the next playtest.


## Revision 309: temporary Character Tool part visibility

The Character Tool toolbar's **Visible / Hidden** action is an editor-only inspection aid. A click hides or shows the selected rig part in the preview without adding, editing, or deleting alpha keyframes and without marking any project document dirty. Hidden parts are omitted from canvas selection and transform handles but remain available in the rig-part selector so they can be shown again. Double-click **Visible / Hidden** to clear the temporary mask and restore every part. Loading or replacing a character or rig also clears the mask.


## Revision 310: packaged resources are the native default

When launched without `--resources-root`, both native executables use the resources copied beside them:

```text
<Release folder>/content/resources
```

`IgnatiusDevTool.exe` also loads the shared HTML tool bundle from `<Release folder>/content`. It does not automatically walk up into a source checkout and select `reference/resources`. To edit source resources directly, use **Select resources folder…** or launch with `--resources-root "..\..\reference\resources"`. The selected folder then becomes the strict read/write/playtest boundary for that session.

This makes a copied or shipped Release folder self-contained. If its `content` or `content/resources` directory is incomplete, startup fails visibly instead of borrowing content from another tree.


## Revision 321 player-rocket distance tuning

Player rocket distance controls are authored in `resources/config/tuning.json`. `rocketProjectileUnwrenchedMaxTravelDistance` is the default Standard rocket path budget (400 px), `rocketProjectileMaxTravelDistance` is the base wrench path budget (1200 px), `rocketTargetSearchDistance` is the fixed radial acquisition limit (1500 px), and `rocketLifetimeExplosionOffscreenMargin` controls how far beyond the visible world rectangle a no-hit lifetime expiry may still create an explosion (100 px). If persistent progression owns `standardRocketRangeUnlocked`, only the unwrenched Standard path budget is multiplied by 1.25 to 500 px before duration tuning. Yellow Fivefold and Cyan Dart intentionally carry `travelDistanceMultiplier: 1.5`, giving them 1800 px at 100% duration tuning while the other wrench profiles remain at 1200 px. Lifetime remains derived at launch as travel distance divided by the fully speed-scaled projectile velocity. `rocketDurationPercent` scales the resulting travel/lifetime budget and `rocketDamagePercent` scales the authored base direct damage. Do not restore viewport-width target range or a single hard-coded range shared by all wrench profiles.

## Revision 354 Power HUD timer selection

When several power-ups are active at once, the Power bar now displays whichever timed effect will expire first. The shared helper is `shortestRemainingActivePowerUpEffect` in JavaScript and C++; do not reproduce the ordering in browser or SDL presentation code. Permanent/no-expiry effects are treated as having infinite remaining time and therefore appear only when there is no active timed effect. Ties use the most recently activated effect and then stable effect ID.

The numeric `hud.priority` values on built-in effect definitions are now legacy metadata. They are intentionally preserved in the schema and authored definitions, but they do not decide which active effect appears in the Power bar. Effect stacking, wrench exclusivity, refresh behavior, expiry, and gameplay multipliers are unchanged.

## Revision 414 native memory-stress loop

The SDL executable has a rendered memory-stress mode intended for long resource-lifetime runs on Windows:

```text
IgnatiusSDL.exe --memory-stress --memory-stress-cycles=500 --memory-stress-csv=logs\memory-stress.csv
```

The mode always starts on reserved fixture `level_t20` and loops through `level_t21` and back. `level_t20` is cave-window content and `level_t21` is forest content; they deliberately use different environment-atlas sets, enemy character projects, and music so ordinary level transitions repeatedly destroy, retain, and allocate real runtime resources. The driver holds right and pulses weapon fire. Ordinary combat damage is suppressed only for this diagnostic mode so the run cannot end because an enemy kills Ignatius. Traversal is not bypassed: if a fixture fails to reach its normal exit portal within the watchdog, the process exits with code 6.

`--memory-stress-cycles=N` means N complete `level_t20 -> level_t21 -> level_t20` loops. `--memory-stress-transitions=N` may be used when an exact transition count is preferable. `--memory-stress-max-ticks=N` changes the per-level watchdog; the default is 3600 simulation ticks. If no CSV path is supplied, the executable writes `logs/ignatius_memory_stress_rev<revision>.csv` beside the executable's local output tree.

The CSV records a row at startup and after every completed transition. On Windows, `private_bytes` is the process's private committed memory and `private_bytes_available` confirms that the operating-system query succeeded. `working_set_bytes` and `peak_working_set_bytes` are also recorded, together with environment-atlas, character-project, sound, treatment-texture, raw-world-cache, visual, enemy, projectile, and smoke-puff counts. Compare repeated checkpoints for the **same level** after the first few warm-up loops. A stable plateau is expected; a persistent same-level upward trend is the signal to investigate. Linux fills the working-set columns from `/proc/self/status` and leaves `private_bytes` at zero; that path exists to smoke-test the harness rather than define Windows leak acceptance.

For memory-corruption investigations, run this same rendered loop under a Windows memory-error detector such as MSVC AddressSanitizer or Page Heap. Playback remains useful for deterministic combat-heavy reproduction, but it intentionally suppresses level transitions and therefore does not replace this fixture loop for resource-allocation/free churn.

## Revision 415 generalized stress backends

Revision 415 keeps the Revision 414 `level_t20 <-> level_t21` driver and exposes it as the `level-cycle` scenario through three explicit native backends:

```text
IgnatiusSDL.exe --stress-sim=level-cycle --stress-cycles=500
IgnatiusSDL.exe --stress-renderer=level-cycle --stress-cycles=500 --windowed
IgnatiusSDL.exe --stress-gpu=level-cycle --stress-cycles=500 --windowed
```

`--stress-sim` performs no SDL video/audio/presentation initialization and runs the C++ simulation/resource-state loop as fast as possible. `--stress-renderer` requires the legacy SDL_Renderer path. `--stress-gpu` is intentionally strict: it requires SDL_GPU, raw-GPU world rendering, raw-GPU presentation, and the offscreen frame FIFO used by the production-oriented GPU stress path. It does not silently fall back to SDL_Renderer or direct-present mode.

The generalized option aliases are `--stress-cycles`, `--stress-transitions`, `--stress-max-ticks`, and `--stress-csv`. The older `--memory-stress*` names remain supported for compatibility. The CSV includes backend/scenario identity, total ticks and elapsed time in addition to the Revision 414 process-memory/resource counters.

The evolving rationale, current measurements, planned scenarios, and Windows validation checklist live in repository-root `STRESS_TEST_PLAN.md`. Do not treat that document as a frozen specification; update it when measurements or discovered bugs change which stress work has the best diagnostic value.

## Revision 432 committed melee lunges

The old short attack-time tracking nudge is retired. A grounded melee enemy becomes lunge-eligible only when its authored `lungeStartMaxDistance`, `lungeSpeed`, and `lungeEndSeparation` are all positive and the range band is valid. Inside positive `meleeHitRange` it swings normally without lunging. Active melee enemies are expected to author that positive close-attack reach explicitly; there is no fallback to projectile-only `rangedAttackMaxDistance`. When outside direct melee reach, attack-position planning considers both direct-melee positions and the valid `lungeStartMinDistance..lungeStartMaxDistance` band and chooses the cheapest reachable attack-ready position. A lunge may commit from the lunge band only if the complete grounded path to the target position is traversable. The burst destination is Ignatius's position at lunge launch minus the explicit `lungeEndSeparation` in the attack direction, with both melee reach and target separation scaled by enemy instance scale. Live wind-up tracking is clamped at launch so physical travel cannot exceed `lungeStartMaxDistance - scaled lungeEndSeparation` from the enemy's launch point. No target distance is inferred when the authored value is zero. The destination does not home after launch. Full-path validity is checked before commitment and at launch; once moving, the burst advances through small collision/support-aware substeps so newly appearing distant blockers do not freeze it early, while walls and gaps still stop it without tunnelling. The enemy remains at the resulting position after the swing. When a hunter is navigating into attack position, the planner aims inside hard melee/lunge/ranged boundaries where the band width permits it, and the locomotion controller limits arrival tolerance to the remaining safety margin so settling cannot leave the actor outside the legal attack band. Do not “fix” boundary stalls by forcing exact-coordinate arrival: the braking controller can overshoot a mathematical point and alternate direction every frame. If the player moves enough that the old attack position is no longer valid when reached, the route is replanned.

Long lunges preserve authored `lungeSpeed` without slowing the attack animation. The attack animation plays at authored speed through its wind-up until the first melee handoff/impact pose. That impact pose is then held while the enemy physically lunges; the handoff is delayed until the burst completes, after which the remaining follow-through resumes at authored speed. Physical lunge speed is world-space px/s and is intentionally independent of the global melee attack-rate scale. If an in-flight lunge physically reaches a newly introduced wall, ledge, or unsupported boundary, that stop position immediately ends the lunge and resolves the delayed handoff there; removing the obstruction later cannot restart the burst.

Physical lunge velocity belongs exclusively to the committed lunge. Interrupting a launched lunge through damage or another state transition consumes that burst velocity instead of releasing it into hurt/passive ground motion. If Ignatius becomes untargetable only after launch, the already-locked lunge continues to its endpoint because it no longer needs live target data. Losing dynamic support during the burst cancels the lunge without converting its high ground speed into airborne horizontal momentum.

`meleeHitRange` is a forward horizontal reach measured from the character enemy grounded-base X. At the critical frame, the authored melee handoff supplies strike timing and strike Y; a hit occurs when the grounded-base reach segment at that Y intersects Ignatius's hurt box and terrain does not block the attack. This remains gameplay geometry rather than pixel-alpha weapon collision. A zero reach does not fall back to any legacy radius and therefore provides no ordinary melee reach.

Lunge eligibility is catalog data, not a fixed enemy-family rule. Zero `lungeStartMaxDistance` disables lunging, and a positive maximum below `lungeStartMinDistance` is treated as an invalid disabled band rather than being silently collapsed. Current enabled variants use 2000 px/s burst speed, with authored maximum ranges currently including 450 px for Human Raiders and 600 px for the Skeleton Guard and Human Pirates. Those values remain balance data and may change independently. Tests use synthetic lunge fixtures so catalog balance choices do not fail mechanics regressions.


## Revision 515 persistent player ability unlocks

The permanent `playerProgression` payload owns independent boolean ability/talent flags: `lungeUnlocked`, `fallImpactExplosionUnlocked`, `fallDamageReductionUnlocked`, `stealthRocketUnlocked`, `standardRocketRangeUnlocked`, and `lungeSpeedUnlocked`. They are serialized through the same campaign/save-game path as the permanent health, fuel, regeneration, speed, and collected-upgrade progression, so autosaves, manual saves, level transitions, browser/native gameplay-state serialization, and playback restore retain the flags.

Development-phase save compatibility is intentionally not retained for omitted ability/talent fields. Fresh progression matches a true new campaign: `lungeUnlocked = true` and `fallImpactExplosionUnlocked = true`, while `fallDamageReductionUnlocked = false`, `stealthRocketUnlocked = false`, `standardRocketRangeUnlocked = false`, and `lungeSpeedUnlocked = false`. That same default is used by direct `?level=...` browser starts, Level Editor playtests, native `--level` starts, Dev Tool playtests, and headless/simulation state construction, so development playtesting does not silently grant optional talents. Explicit serialized flags continue to be preserved independently.

`lungeUnlocked` gates the charge itself: when false, lunge input has no gameplay effect and must not start the 0.25-second crouch, smoke, reduced hitbox, fuel use, or recharge latch. `fallImpactExplosionUnlocked` independently gates the intentional Down-held body-slam/Bigbomb AOE. `fallDamageReductionUnlocked` independently gates the 50-percent fall-damage multiplier. `stealthRocketUnlocked` independently allows rockets to be fired without cancelling Magic Ring concealment. `standardRocketRangeUnlocked` independently multiplies only the unwrenched Standard rocket's 400 px base reach by 1.25 to 500 px. `lungeSpeedUnlocked` independently multiplies effective player-lunge speed by 1.25 while leaving `playerLungeDurationSeconds` unchanged; with the installed 1200 px/s and 0.5-second defaults this gives 1500 px/s and a derived 750 px nominal range instead of 600 px. A save may therefore contain any combination of these persistent abilities/talents.


## Revision 516 committed player body slam

The fall-impact attack is intentional rather than a side effect of every damaging fall. A body slam may commit only while `fallImpactExplosionUnlocked` is true, its fuel recharge latch is ready, Ignatius is airborne outside water/Flight/lunge states, Down is currently held, and his current downward velocity is already greater than `fallDamageSafeImpactSpeed`. This is a current-state predicate, not a threshold-crossing event: pressing Down after the damaging-speed threshold was crossed commits immediately. A brief Down press used only to drop through a green walkable line does not commit unless Down remains held until the fall is dangerous.

Commitment is a point of no return until landing. It clears ordinary-jump/air-kick eligibility and suppresses later jump/boost/hover recovery, but doubled gravity remains an input effect rather than part of the committed state: holding Down continues to double gravity, while releasing Down returns to ordinary gravity without cancelling the slam. The implementation intentionally does not delay or retrospectively undo damage from the tick immediately before commitment; a contact/projectile/hazard hit that lands just before the fall is fast enough to commit remains valid. Keep the explanatory code comment in both simulations so future reviews do not mistake this known one-tick boundary for a regression. Water, death, reset, and development teleport clear transient slam state.

A committed slam has shield-like ordinary-damage immunity from commitment through landing, represented by the same pulsing blue tint used by Shield/lunge immunity. Fall damage continues to call the damage path with bypass-invulnerability enabled and therefore still applies. On landing, the dedicated `bodySlamImmunityTimer` is set from `playerContactDamageInvulnerabilitySeconds` (currently 0.45 s), and the ordinary contact-invulnerability timer is raised to the same duration. This blocks contact, melee, projectiles/explosions, and damaging-area channels during the grace window without turning the actual Shield pickup on.

Only a committed slam can call the existing Bigbomb-style fall-impact AOE. Its presentation and radius still reuse the red Bigbomb profile, but damage is deliberately independent through `playerFallImpactExplosionDamage`, currently 60 rather than the Bigbomb rocket's 80. Accidental damaging falls still receive the independent `fallDamageReductionUnlocked` multiplier but never explode. Commitment itself requires the body-slam fuel recharge latch to be ready, so holding Down while the latch is unavailable remains an ordinary accelerated fall; if the fuel tank later reaches full while the wizard is still airborne, falling fast enough, and holding Down, the current-state predicate may commit on that later tick. A committed body slam costs `playerBodySlamFuelCost`, currently 5, applies `playerBodySlamRechargeDelayAfterUse`, currently 3.0 seconds, and re-arms only when the fuel tank becomes full again. The `fallDamageReductionUnlocked` talent no longer changes body-slam recharge behavior. `playerLungeRechargeDelayAfterUse` is also 3.0 seconds: after a lunge, the lunge latch re-arms only when the fuel tank becomes full again. Revision 517 sets `playerLungeDamage` to 45 and separates slam damage from Bigbomb through `playerFallImpactExplosionDamage = 60`.


## Revision 566 persistent diagnostic capture preferences

Debug logging and gameplay recording are now saved user preferences in both ports rather than being forced directly by `DEVELOPMENT` on every run. `DEVELOPMENT` is used only as the first-run fallback when a preference has never been saved: both preferences default on while the product-development switch is true and off when it is false. Explicit saved true/false values always win thereafter.

Debug logging owns one launch-scoped stream. Native starts a fresh timestamped NDJSON file at application startup when enabled; browser starts a fresh in-memory NDJSON log for the page launch and exports it when logging is disabled. Gameplay recording owns one level-scoped capture. Entering, restarting, loading, or transitioning to a gameplay level finalizes any active level recording and starts a fresh one when the preference is enabled. Returning to the title finalizes the active recording. Playback suppresses live capture without changing the saved preference; live recording resumes after playback when appropriate. Temporary logging/recording I/O failures do not silently disable the saved preference.

## Revision 604 one-way drop press edges and green body-slam landings

The player's green-line drop-through is no longer a general held-Down airborne state. A fresh Down press while grounded on a `walkable` support records that support in `dropThroughSupportId` and grants the normal short grace only against that support. Continuing to hold Down preserves doubled gravity but subsequent green lines are solid, so landing on another green line requires a release-and-repress before it can be dropped through. Pressing Down while already airborne does not arm the next green support. Flight and water deliberately retain continuous held-Down pass-through. This change lets committed body slams collide with and explode on green walkable lines using the normal landing path. Keep JS/C++ state, moving-platform catch behavior, and regression fixtures in parity.
