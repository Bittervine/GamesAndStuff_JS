# Ignatius SDL Port Agent Notes

This repository contains two implementations of Ignatius Rocketfrock:

- `reference/`: the HTML/JavaScript reference implementation and browser authoring tools.
- `src/`: the SDL3/C++ port and native tools.

The two gameplay implementations are developed together. Keep gameplay behavior, data formats, defaults, and useful function/field names in parity unless a platform-specific presentation difference is intentional.

This file records current working rules only. Revision history belongs in archived baseline/update packages and source history, not here.

## Baseline and revision workflow

- Treat the highest established full-baseline ZIP for the chat as immutable.
- Work in separate extracted working and verification trees.
- Every update ZIP is a cumulative delta against that immutable baseline, not against the previous update.
- Increment the revision for every delivered update and keep the root and `reference/` revision files synchronized.
- Before normal delivery, apply the update ZIP to a fresh baseline extraction and compare it with the working tree.
- ZIP timestamps have no timezone. If they confuse Ninja on Linux, normalize timestamps only in disposable extracted trees, never in the baseline archive.
- `build.sh` intentionally may not be executable; invoke it with `bash build.sh`.
- Routine Linux verification uses `bash build.sh` (`-Og -DNDEBUG`). Use `bash build.sh --release` only when GCC optimization is relevant. Windows `build.bat` / VS2022 Release remains the authoritative optimized production build.

### Optional revision-candidate / beta workflow

The normal revision workflow above remains the default. Use this alternate workflow **only when the user explicitly asks for a “revision beta”, “revision candidate”, or equivalent wording indicating that they will perform the full verification locally**. Do not switch to candidate mode merely because verification is slow.

- A candidate targets the next ordinary numeric revision but adds a beta suffix **only to the package filename**. Example: `Ignatius_SDL_775b1_UPDATE.zip`.
- The project itself still uses the numeric revision (`775`) in `BUILD_REVISION.txt`, `reference/BUILD_REVISION.txt`, the game title, ABI/revision checks, and other internal revision fields. Do not write `775b1` into numeric revision files.
- Successive candidates for the same target revision use `b1`, `b2`, `b3`, ... and **do not consume additional revision numbers**. A failed `775b1` followed by a corrected `775b2` is still revision 775.
- Every beta ZIP is still a cumulative delta against the chat's immutable baseline, with the same directory structure and packaging exclusions as a normal update ZIP. It must never depend on applying an earlier beta first.
- Before handing over a beta, perform a reasonable local preflight rather than the full release gate: compile the affected native target/translation units when practical, run focused regressions for the changed behavior, run relevant JS syntax/focused tests, and verify the cumulative ZIP reconstructs the working tree from the immutable baseline. The point is to catch obvious implementation/package errors without spending the session on the complete cross-platform suite.
- The root-level `verify_revision_candidate.bat` is **revision-specific verification orchestration**, not a universal always-run-everything gate. When preparing each beta/update, manually curate its **no-argument** sequence for the files and behavior changed in that revision. Do not make the script infer the required tests from changed files. Put the fastest/highest-signal and most likely-to-fail checks first, and normally stop after a decisive failure when later checks would have to be rerun after the fix anyway. Continue independent checks after a failure only when the extra diagnostic information is worth the time.
- Expensive checks such as the complete navigation differential must appear in the default candidate sequence only when the revision can plausibly affect them. The script should retain an explicit option such as `--full` for a deliberately exhaustive cross-platform run; the exhaustive mode may collect multiple independent failures even when the revision-specific default is fail-fast.
- The user can apply the beta and normally just run `verify_revision_candidate.bat` with no arguments. An optional candidate label may still be supplied, for example `verify_revision_candidate.bat 775b1`; this must use the same curated default sequence. A full audit can be requested explicitly, for example `verify_revision_candidate.bat 775b1 --full`. The script writes one handoff report under `logs/`, such as `logs\Ignatius_SDL_775b1_VERIFICATION.txt`.
- When the user returns that verification report, inspect it before making further changes. If verification failed, correct the issue and issue the next beta suffix for the **same** numeric revision.
- If a beta passes and **no project file has changed since that exact beta ZIP was produced**, it may be promoted directly to the final package name, e.g. `Ignatius_SDL_775_UPDATE.zip`. Promotion should preserve the exact tested ZIP contents; renaming/copying the tested archive is preferable to rebuilding it.
- Any project-content change after a beta was tested, even a seemingly harmless cleanup, invalidates that beta's verification. Produce another beta and have that candidate verified before promotion.
- A user request beginning with `Quick:` still follows the existing Quick-mode rules unless the user explicitly also asks for a revision beta/candidate.

## Third-party licensing gate

- **Do not add or vendor any new open-source or third-party component without first reviewing its license for commercial/proprietary compatibility and obtaining the user's explicit approval.**
- Treat source libraries, header-only code, generated/transpiled ports, binary libraries, fonts, codecs, copied snippets, and build-time/runtime packages as third-party components for this rule.
- GPL, AGPL, LGPL, MPL, source-available/custom licenses, or any unusual reciprocal terms require explicit scrutiny; never assume compatibility from a package name or prior use elsewhere.
- Retain all required copyright/license notices, update `THIRD_PARTY_NOTICES.md`, and make release packaging include the notices required by the approved license.
- Throw-away investigation prototypes may evaluate a component outside the project tree, but evaluation does not authorize integrating or redistributing that component.

## Source of truth and compatibility

- Player-facing/gameplay changes normally update both JS and C++ implementations.
- Presentation layers may differ, but presentation must not own gameplay decisions.
- Keep function, method, variable, JSON-field, asset, and resource names close between ports where practical.
- Shared gameplay defaults live in `reference/resources/config/tuning.json`; every installed key must be consumed with the same meaning in both ports.
- This development phase is **current-schema only**. Backward compatibility with older saves, levels, character projects, settings, or retired JSON fields is not required unless explicitly requested. Update all bundled current data instead of preserving obsolete aliases or migrations.
- Ordinary `level_###` and experimental 800-series levels are mutable authored content. Never use them as behavioral test fixtures. Use reserved `level_tNN` levels for tests; `level_temp` is scratch playtest data only.

## Architecture and maintainability

- Portable gameplay belongs in browser `reference/src/core` / `reference/src/shared` and native `src/core` / `src/shared` equivalents.
- Browser startup/input belongs in `reference/src/browser`; browser rendering in `reference/src/presentation`; browser editors in `reference/src/tools` and the editor HTML entry points.
- Native renderer architecture is documented in `devel/RENDERER_ARCHITECTURE.md`.
- Prefer the smallest **coherent** fix. Fix the invariant or responsibility rather than accumulating symptom-specific exceptions.
- Larger refactors are appropriate when they simplify the system and can be verified safely.
- Avoid synchronous asset work, repeated allocation, rasterization, or other frame-time spikes on the ordinary scrolling/render path.
- Renderer selection is fixed after initialization. Automatic native startup may visibly fall back to SDL_Renderer with an explicit diagnostic. Explicit `--gpu` runs are strict tests and must fail rather than silently changing backend.
- SDL_GPU and SDL_Renderer resources are backend-owned. Do not restore readback or texture-sharing bridges between their caches.
- Native gameplay uses one authoritative simulation state. Rendering cadence/pacing must never create a second gameplay state or alter simulation semantics.

## Native resource and path rules

- Without `--resources-root`, native executables use executable-adjacent `content/resources`; `IgnatiusDevTool.exe` loads its HTML bundle from executable-adjacent `content`.
- Native application-owned writable/readable files stay below the executable directory: packaged content, logs, settings/saves, recordings, WebView2 data, screenshots, captures, traces, and performance output.
- The only project-content exception is an explicitly selected or command-line `--resources-root`.
- Do not auto-discover `reference/resources`, ancestor checkouts, working-directory content, system fonts, or other hidden fallbacks.
- Native UI fonts are bundled under `content/resources/fonts`; use the intended named variable-font weight rather than a system-font fallback.

## Testing rules

- Prefer deterministic headless/regression tests for gameplay, asset loading, serialized state, and editor contracts.
- Add or update regression coverage with gameplay changes when practical.
- Any verification that actually loads a level must use a reserved `level_tNN` fixture.
- Tests and tools should fail non-interactively with exit codes/log output rather than modal dialogs.
- For visual parity, prefer recordings, deterministic playback, frame captures, and state/trace comparison over eyeballing two unrelated runs.
- **Keep verification proportional to the change.** Run only the builds and tests that could realistically catch regressions caused by the files or behavior modified. Prefer targeted subsystem tests over full-project gates. Broaden verification only when the change is cross-cutting, its impact is uncertain, or a specific instruction requires it.
- `devel/README.md` documents retained diagnostic helpers.

## Enemy navigation and tactical AI

Ground-enemy navigation deliberately stays simpler than player traversal:

- Ground AI plans only through static authored collision/navigation supports. Moving platforms may physically carry an enemy already standing on them, but AI does not plan to board, wait for, ride, or disembark from them.
- Baked navigation excludes moving-platform geometry.
- Heuristic baking proposes jump/drop candidates; deterministic fixed-step simulation at `dt = 1/60` is the authoritative verifier.
- Keep `failed` edges in authored graphs with a compact failure reason, but runtime routing must never use them. Prefer `verified` transitions; `unverified` may remain a compatibility/fallback route when no verified route exists.
- Browser graph production goes through `reference/src/tools/navigation-rebake.js`; do not fork browser graph semantics into Level Editor, playtest, CLI, or Dev Tool implementations.
- The JS and native navigation rebakers are peer implementations of the same graph semantics. Prefer the native rebaker for authored navigation-data updates when practical because it is dramatically faster; use the Level Editor/JS rebaker when the native tool is unavailable or the editor workflow specifically calls for it. Neither rebaker is semantically more canonical than the other, so parity checks must keep their outputs aligned.
- Verification proof reuse is local to an edge and its relevant collision/input hash. Bump `NAVIGATION_VERIFICATION_INPUT_SCHEMA` when verifier/collision semantics change enough to invalidate stored proofs.
- The Dev Tool owns all-level incremental and clean rebake/verify workflows; process authored numeric levels only, never `level_tNN` or `level_temp`, and save completed levels incrementally.
- Bounded recovery such as repathing, last-seen investigation, stranded-patrol recovery, and retry/watchdog fallback is useful, but it must not invent traversal abilities or mask deterministic failures.

Enemy behavior invariants worth keeping explicit:

- Ordinary non-boss placements inherit catalog strategy by default, but `strategyOverride` may explicitly select any implemented character-enemy AI strategy (`hunter`, `simple_patrol`, `sentry`, `passive`, `bomber`, or `periodic`) without changing locomotion, attacks, or other catalog-authored properties. Boss overrides remain separate.
- For ground Patrol/Hunter idle behavior, `patrolDistance` defines the inner home interval around spawn. Ground Patrol/Sentry pursuit uses the outer `spawnX +/- patrolDistance` leash; Hunters are not pursuit-leashed by that field.
- Ranged attacks use hard minimum/maximum firing distances and a preferred positioning distance. Preferred distance is not an additional firing requirement.
- A grounded enemy with a legal off-cooldown melee or projectile opportunity attacks immediately even while running/coasting. Ordinary horizontal speed must not delay attack start.
- During deliberate tactical repositioning, an enemy may face its direction of travel and use only the player's **last genuinely seen** position to complete the plan. Turning away by choice must not immediately collapse into last-seen investigation, but it must not grant through-the-back live tracking either. When attack/lunge setup is ready, turn back and reacquire through normal perception before committing the attack.
- See `ENEMY_COMBAT_AUTHORING.md` for the current ranged/melee/lunge distance contract.

## Player movement and progression invariants

- Green walkable drop-through is press-scoped while grounded: a fresh Down press ignores the currently supported connected green component. Holding Down remains fast-fall input; unrelated lower green lines stay solid. Real upward velocity cancels the scoped ignore. Flight/water retain held-Down pass-through behavior.
- Flight neutral-input horizontal cruise is airborne-only. If Flight is active while Ignatius is grounded, neutral horizontal input uses ordinary ground friction so he can stand still; active Left/Right control remains available. Grounded Flight is an idle-exhaust presentation state: keep attached smoke/sparks at 50% normal puff lifetime but suppress the mounted flame at every effects quality; airborne Flight keeps the normal plume.
- Fresh progression starts with `lungeUnlocked = true` and `fallImpactExplosionUnlocked = true`; `fallDamageReductionUnlocked`, `stealthRocketUnlocked`, and `standardRocketRangeUnlocked` start false.
- Current installed rocket/talent balance and player-facing controls belong in `reference/GameManual.html` and current developer guidance, not in this file. Keep those documents synchronized when balance changes.

## Authoring tools and resource roots

- Character, Level, Asset, and Palette tools must honor the selected resources root consistently.
- Once a project root is connected, authoring reads/writes use that root. Do not silently fall back to packaged/page-relative resources when the selected root is unavailable.
- If a Save operation first selects a different resources root, reload from that root before writing already-loaded project data into it.
- Right-side inspector panel open/collapsed state is editor-local UI state and should not affect project data.
- `reference/src/tools/palette-builder-core.js` is the canonical deterministic palette-thumbnail generator. Browser and Node front ends must invoke the same core so equivalent inputs produce byte-identical PNG/JSON output. Do not add an alternate renderer fallback that silently produces different cache contents.
- `reference/resources/palette/thumbnails.json` binds the generated PNG with its hash. Catalog/resource changes may require metadata regeneration even when the PNG pixels remain unchanged.
- Level Editor expanded and compact palettes share the same model/selection logic. Asynchronous expanded-palette asset loads are session-bound so closing/replacing the modal cannot later arm placement.

## Diagnostics and failures

- A condition that should be impossible in a valid current build, or a required-resource/invariant failure hidden by graceful recovery, is a loggable exception.
- Route such incidents through the shared structured exception path with a stable type, concise message, and useful context.
- Recovery is appropriate only for isolated optional facilities where continuing is clearly safe. Fail core simulation/world/renderer reconstruction rather than building elaborate degradation paths after essential-state failures.
- Avoid repeating the same incident every frame.
- Persistent debug logging and gameplay recording are user preferences; development mode only supplies first-run defaults. Playback suppresses live recording without changing the saved preference.

## Focused documentation

Keep durable detail in focused documents instead of extending this file into a changelog:

- `LEVEL_GENERATOR.md`: current automatic-level-generator visual goals, asset metadata policy, recipe strategy, and deferred optimization/generator work.
- `ENEMY_COMBAT_AUTHORING.md`: combat distance and lunge authoring semantics.
- `PARITY_AUDIT.md`: current parity map/checklist and intentional divergences.
- `STRESS_TEST_PLAN.md`: current stress backends, scenarios, and leak-testing strategy.
- `devel/RENDERER_ARCHITECTURE.md`: native rendering ownership and pacing contract.
- `reference/ARCHITECTURE.md`: browser source classifications and dependency boundaries.
- `reference/DEVELOPER_MANUAL.md`: current developer/editor/gameplay guidance.
- `THIRD_PARTY_NOTICES.md`: licensing notices. Do not casually trim or delete it.
