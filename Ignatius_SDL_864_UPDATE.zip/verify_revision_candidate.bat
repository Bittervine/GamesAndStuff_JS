@echo off
setlocal EnableExtensions DisableDelayedExpansion

for %%I in ("%~dp0.") do set "ROOT=%%~fI"
cd /d "%ROOT%" || exit /b 2

set "FULL=0"
set "CLEAN_BUILD=0"
set "BUILD_MODE_OVERRIDDEN=0"
set "SKIP_PARITY=0"
set "RESUME_JS=0"
set "LABEL="
set "REVISION="

if not exist "%ROOT%\BUILD_REVISION.txt" (
    echo ERROR: BUILD_REVISION.txt was not found next to this script.
    exit /b 2
)
set /p REVISION=<"%ROOT%\BUILD_REVISION.txt"
if not defined REVISION (
    echo ERROR: BUILD_REVISION.txt is empty.
    exit /b 2
)
echo(%REVISION%| findstr /R /X "[0-9][0-9]*" >nul
if errorlevel 1 (
    echo ERROR: BUILD_REVISION.txt must contain a numeric revision. Found: %REVISION%
    exit /b 2
)

:parse_args
if "%~1"=="" goto args_done
if /I "%~1"=="--full" (
    set "FULL=1"
    shift
    goto parse_args
)
if /I "%~1"=="--clean" (
    set "CLEAN_BUILD=1"
    set "BUILD_MODE_OVERRIDDEN=1"
    shift
    goto parse_args
)
if /I "%~1"=="--incremental" (
    set "CLEAN_BUILD=0"
    set "BUILD_MODE_OVERRIDDEN=1"
    shift
    goto parse_args
)
if /I "%~1"=="--skip-parity" (
    set "SKIP_PARITY=1"
    shift
    goto parse_args
)
if /I "%~1"=="--resume-js" (
    set "RESUME_JS=1"
    shift
    goto parse_args
)
if /I "%~1"=="--help" goto usage
if /I "%~1"=="-h" goto usage
if not defined LABEL (
    set "LABEL=%~1"
    shift
    goto parse_args
)
echo ERROR: Unknown argument: %~1
exit /b 2

:args_done
if "%FULL%"=="1" if "%BUILD_MODE_OVERRIDDEN%"=="0" set "CLEAN_BUILD=1"
if not defined LABEL set "LABEL=%REVISION%-candidate"
echo(%LABEL%| findstr /R /X "[A-Za-z0-9._-][A-Za-z0-9._-]*" >nul
if errorlevel 1 (
    echo ERROR: Candidate label may contain only letters, digits, dot, underscore, and hyphen.
    echo Example: verify_revision_candidate.bat 776b1
    exit /b 2
)

if "%FULL%"=="1" (
    set "PROFILE=FULL"
    set "STEP_TOTAL=6"
) else (
    set "PROFILE=TARGETED-REV-%REVISION%"
    set "STEP_TOTAL=3"
)

if not exist "%ROOT%\logs" mkdir "%ROOT%\logs" >nul 2>nul
set "REPORT=%ROOT%\logs\Ignatius_SDL_%LABEL%_VERIFICATION.txt"
set "NAV_REPORT=%ROOT%\logs\navigation_parity_report.txt"
set "TEST_EXE=%ROOT%\build\Release\IgnatiusTests.exe"
set "REBAKER_EXE=%ROOT%\build\Release\navigation-rebaker.exe"

set "BUILD_STATUS=NOT-RUN"
set "FOCUSED_STATUS=NOT-RUN"
set "NATIVE_STATUS=NOT-RUN"
set "BATCH_STATUS=NOT-SELECTED"
set "EDITOR_STATUS=NOT-SELECTED"
set "GAME_STATUS=NOT-SELECTED"
set "SHARED_STATUS=NOT-SELECTED"
set "JS_STATUS=NOT-SELECTED"
set "PALETTE_STATUS=NOT-SELECTED"
set "PARITY_STATUS=NOT-SELECTED"
set "DOC_STATUS=NOT-RUN"
set "OVERALL=0"

>"%REPORT%" echo Ignatius SDL revision-candidate verification
>>"%REPORT%" echo ============================================
>>"%REPORT%" echo Candidate label: %LABEL%
>>"%REPORT%" echo Internal revision: %REVISION%
>>"%REPORT%" echo Verification profile: %PROFILE%
>>"%REPORT%" echo Root: %ROOT%
>>"%REPORT%" echo Started: %DATE% %TIME%
>>"%REPORT%" echo Clean build: %CLEAN_BUILD%
>>"%REPORT%" echo Navigation parity skipped: %SKIP_PARITY%
>>"%REPORT%" echo JS release gate resume: %RESUME_JS%
>>"%REPORT%" echo.
if "%FULL%"=="0" (
    >>"%REPORT%" echo Default revision-specific sequence for revision %REVISION%:
    >>"%REPORT%" echo   1. Revision consistency + browser Flight idle-exhaust gameplay/renderer regressions
    >>"%REPORT%" echo   2. Windows Release build
    >>"%REPORT%" echo   3. Native rocket-fuel-flight bench
    >>"%REPORT%" echo Revision 864 keeps grounded Flight as an idle exhaust and lengthens its smoke/spark puff lifetime from 40%% to 50%% of normal.
    >>"%REPORT%" echo Use --full to request the complete cross-platform battery.
    >>"%REPORT%" echo.
)

call :say "Candidate %LABEL%, internal revision %REVISION%"
call :say "Verification profile: %PROFILE%"
call :say "Complete output will be written to:"
call :say "  %REPORT%"
call :say ""

if "%FULL%"=="0" goto targeted_revision_864

call :section "Environment"
>>"%REPORT%" echo Windows:
ver >>"%REPORT%" 2>&1
>>"%REPORT%" echo.
>>"%REPORT%" echo Computer: %COMPUTERNAME%
>>"%REPORT%" echo Processor count: %NUMBER_OF_PROCESSORS%
>>"%REPORT%" echo.
call :record_version cmake "cmake --version"
call :record_version ctest "ctest --version"
call :record_version node "node --version"
if "%FULL%"=="1" (
    call :record_version npm "npm.cmd --version"
)

if not exist "%ROOT%\build.bat" (
    call :say "ERROR: build.bat is missing."
    >>"%REPORT%" echo ERROR: build.bat is missing.
    set "BUILD_STATUS=FAIL"
    set "OVERALL=1"
    goto final_summary
)
where cmake >nul 2>nul
if errorlevel 1 goto missing_cmake
where ctest >nul 2>nul
if errorlevel 1 goto missing_ctest
where node >nul 2>nul
if errorlevel 1 goto missing_node
if "%FULL%"=="1" goto check_full_prerequisites
goto prerequisites_ok

:check_full_prerequisites
if not exist "%ROOT%\reference\package.json" (
    call :say "ERROR: reference\package.json is missing."
    >>"%REPORT%" echo ERROR: reference\package.json is missing.
    set "OVERALL=1"
    goto final_summary
)
where npm.cmd >nul 2>nul
if errorlevel 1 goto missing_npm
goto prerequisites_ok

:missing_cmake
call :prereq_fail "cmake was not found in PATH."
goto final_summary
:missing_ctest
call :prereq_fail "ctest was not found in PATH."
goto final_summary
:missing_node
call :prereq_fail "node was not found in PATH."
goto final_summary
:missing_npm
call :prereq_fail "npm.cmd was not found in PATH."
goto final_summary


:targeted_revision_864
call :section "1/%STEP_TOTAL% Revision consistency + browser grounded-Flight idle-exhaust regressions"
if not exist "%ROOT%\reference\BUILD_REVISION.txt" goto targeted_revision_864_failed
set "REF_REVISION="
set /p REF_REVISION=<"%ROOT%\reference\BUILD_REVISION.txt"
if not "%REF_REVISION%"=="%REVISION%" goto targeted_revision_864_failed
where node >nul 2>nul
if errorlevel 1 goto targeted_revision_864_failed
pushd "%ROOT%\reference" >nul
set "TEST_FILTER=rocket-fuel governed Flight mode"
node tests\testbench.mjs >>"%REPORT%" 2>&1
if errorlevel 1 goto targeted_revision_864_pop_failed
set "TEST_FILTER=deluxe rocket exhaust renderer contract"
node tests\testbench.mjs >>"%REPORT%" 2>&1
if errorlevel 1 goto targeted_revision_864_pop_failed
set "TEST_FILTER="
popd >nul
set "JS_STATUS=PASS"
set "FOCUSED_STATUS=PASS"
call :say "[PASS] Browser Flight idle-exhaust gameplay + renderer regressions"
>>"%REPORT%" echo RESULT: PASS

call :section "2/%STEP_TOTAL% Windows Release build"
call :say "Running incremental Release build..."
>>"%REPORT%" echo Command: call build.bat release
call "%ROOT%\build.bat" release >>"%REPORT%" 2>&1
if errorlevel 1 goto targeted_revision_864_build_failed
set "BUILD_STATUS=PASS"
call :say "[PASS] Windows Release build"
>>"%REPORT%" echo RESULT: PASS

call :section "3/%STEP_TOTAL% Native grounded-Flight idle-exhaust regression"
if not exist "%TEST_EXE%" goto targeted_revision_864_native_failed
>>"%REPORT%" echo Command: "%TEST_EXE%" --test rocket-fuel-flight
"%TEST_EXE%" --test rocket-fuel-flight >>"%REPORT%" 2>&1
if errorlevel 1 goto targeted_revision_864_native_failed
set "NATIVE_STATUS=PASS"
call :say "[PASS] Native rocket-fuel Flight bench"
>>"%REPORT%" echo RESULT: PASS
>>"%REPORT%" echo MANUAL: With Flight active, land and walk/stand on the ground. The mounted flame should disappear at every Effects quality while a compact smoke/spark idle puff remains at 50%% normal lifetime; taking off should restore the normal airborne flame and smoke plume.
goto final_summary

:targeted_revision_864_pop_failed
set "TEST_FILTER="
popd >nul
goto targeted_revision_864_failed

:targeted_revision_864_build_failed
set "BUILD_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] Revision 864 Windows Release build"
>>"%REPORT%" echo RESULT: FAIL
goto final_summary

:targeted_revision_864_native_failed
set "NATIVE_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] Revision 864 native grounded-Flight idle-exhaust regression"
>>"%REPORT%" echo RESULT: FAIL
goto final_summary

:targeted_revision_864_failed
set "JS_STATUS=FAIL"
set "FOCUSED_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] Revision 864 browser grounded-Flight idle-exhaust verification"
>>"%REPORT%" echo RESULT: FAIL
goto final_summary


:targeted_revision_853
call :section "1/%STEP_TOTAL% Revision consistency + Stealth composite/palette regressions"
if not exist "%ROOT%\reference\BUILD_REVISION.txt" goto targeted_revision_853_failed
set "REF_REVISION="
set /p REF_REVISION=<"%ROOT%\reference\BUILD_REVISION.txt"
if not "%REF_REVISION%"=="%REVISION%" goto targeted_revision_853_failed
where node >nul 2>nul
if errorlevel 1 goto targeted_revision_853_failed
pushd "%ROOT%\reference" >nul
set "TEST_FILTER=wrench power-up arsenal"
node tests\testbench.mjs >>"%REPORT%" 2>&1
if errorlevel 1 goto targeted_revision_853_pop_failed
set "TEST_FILTER=Palette Builder shared core is reproducible"
node tests\testbench.mjs >>"%REPORT%" 2>&1
if errorlevel 1 goto targeted_revision_853_pop_failed
set "TEST_FILTER="
popd >nul
set "JS_STATUS=PASS"
set "PALETTE_STATUS=PASS"
set "FOCUSED_STATUS=PASS"
call :say "[PASS] Stealth composite + palette regressions"
>>"%REPORT%" echo RESULT: PASS

call :section "2/%STEP_TOTAL% Windows Release build"
call :say "Running incremental Release build..."
>>"%REPORT%" echo Command: call build.bat release
call "%ROOT%\build.bat" release >>"%REPORT%" 2>&1
if errorlevel 1 goto targeted_revision_853_build_failed
set "BUILD_STATUS=PASS"
call :say "[PASS] Windows Release build"
>>"%REPORT%" echo RESULT: PASS

call :section "3/%STEP_TOTAL% Native Stealth geometry + power-up benches"
if not exist "%TEST_EXE%" goto targeted_revision_853_native_failed
>>"%REPORT%" echo Command: "%TEST_EXE%" --test runtime-atlas-ownership --test rocket-fuel-flight
"%TEST_EXE%" --test runtime-atlas-ownership --test rocket-fuel-flight >>"%REPORT%" 2>&1
if errorlevel 1 goto targeted_revision_853_native_failed
set "NATIVE_STATUS=PASS"
call :say "[PASS] Native Stealth geometry + power-up benches"
>>"%REPORT%" echo RESULT: PASS
>>"%REPORT%" echo MANUAL: Playtest Magic Ring / Stealth in both renderers and confirm the 25%%-opacity player is unclipped while flame/exhaust remain opaque.
goto final_summary

:targeted_revision_853_pop_failed
set "TEST_FILTER="
popd >nul
goto targeted_revision_853_failed

:targeted_revision_853_build_failed
set "BUILD_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] Revision 853 Windows Release build"
>>"%REPORT%" echo RESULT: FAIL
goto final_summary

:targeted_revision_853_native_failed
set "NATIVE_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] Revision 853 native Stealth benches"
>>"%REPORT%" echo RESULT: FAIL
goto final_summary

:targeted_revision_853_failed
set "JS_STATUS=FAIL"
set "FOCUSED_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] Revision 853 Stealth/palette verification"
>>"%REPORT%" echo RESULT: FAIL
goto final_summary



:targeted_revision_849
call :section "1/%STEP_TOTAL% Revision consistency + focused wizard animation-set regression"
if not exist "%ROOT%\reference\BUILD_REVISION.txt" goto targeted_revision_849_failed
set "REF_REVISION="
set /p REF_REVISION=<"%ROOT%\reference\BUILD_REVISION.txt"
if not "%REF_REVISION%"=="%REVISION%" goto targeted_revision_849_failed
where node >nul 2>nul
if errorlevel 1 goto targeted_revision_849_failed
pushd "%ROOT%\reference" >nul
set "TEST_FILTER=data-driven wizard walk animation"
node tests\testbench.mjs >>"%REPORT%" 2>&1
if errorlevel 1 goto targeted_revision_849_pop_failed
set "TEST_FILTER="
popd >nul
set "JS_STATUS=PASS"
set "FOCUSED_STATUS=PASS"
set "DOC_STATUS=PASS"
call :say "[PASS] Wizard animation-set regression"
>>"%REPORT%" echo RESULT: PASS
goto final_summary

:targeted_revision_849_pop_failed
set "TEST_FILTER="
popd >nul
goto targeted_revision_849_failed

:targeted_revision_849_failed
set "DOC_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] Revision 849 wizard animation-set verification"
>>"%REPORT%" echo RESULT: FAIL
goto final_summary

:prerequisites_ok
call :section "1/%STEP_TOTAL% Windows Release build"
if "%CLEAN_BUILD%"=="1" goto clean_build
call :say "Running incremental Release build..."
>>"%REPORT%" echo Command: call build.bat release
call "%ROOT%\build.bat" release >>"%REPORT%" 2>&1
goto build_done

:clean_build
call :say "Running clean Release build..."
>>"%REPORT%" echo Command: call build.bat release clean
call "%ROOT%\build.bat" release clean >>"%REPORT%" 2>&1

:build_done
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" goto build_failed
set "BUILD_STATUS=PASS"
call :say "[PASS] Windows Release build"
>>"%REPORT%" echo RESULT: PASS
goto focused_test

:build_failed
set "BUILD_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] Windows Release build, exit code %RC%"
>>"%REPORT%" echo RESULT: FAIL, exit code %RC%
>>"%REPORT%" echo Remaining tests were skipped because the candidate did not compile.
goto final_summary



:focused_test
if "%FULL%"=="1" goto focused_full_rebaker
set "FOCUSED_STATUS=PASS"
goto targeted_native

:focused_full_rebaker
call :section "2/%STEP_TOTAL% Native rebaker level_t01 smoke test"
if not exist "%REBAKER_EXE%" (
    set "FOCUSED_STATUS=FAIL"
    set "OVERALL=1"
    call :say "[FAIL] Navigation rebaker executable is missing: %REBAKER_EXE%"
    >>"%REPORT%" echo ERROR: Navigation rebaker executable is missing: %REBAKER_EXE%
    goto final_summary
)
call :say "Running native level_t01 rebake/simulation without writing..."
>>"%REPORT%" echo Command: "%REBAKER_EXE%" --level level_t01 --simulate --no-write --resources-root "%ROOT%\reference\resources"
"%REBAKER_EXE%" --level level_t01 --simulate --no-write --resources-root "%ROOT%\reference\resources" >>"%REPORT%" 2>&1
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" goto focused_full_failed
set "FOCUSED_STATUS=PASS"
call :say "[PASS] Native rebaker level_t01 smoke test"
>>"%REPORT%" echo RESULT: PASS
goto native_tests

:focused_full_failed
set "FOCUSED_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] Native rebaker level_t01 smoke test, exit code %RC%"
>>"%REPORT%" echo RESULT: FAIL, exit code %RC%
goto native_tests
:targeted_native
call :section "2/%STEP_TOTAL% Native CTest suite"
call :say "Running native CTest suite..."
>>"%REPORT%" echo Command: ctest --test-dir build -C Release --output-on-failure
ctest --test-dir "%ROOT%\build" -C Release --output-on-failure >>"%REPORT%" 2>&1
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" goto targeted_native_failed
set "NATIVE_STATUS=PASS"
call :say "[PASS] Native CTest suite"
>>"%REPORT%" echo RESULT: PASS
goto targeted_game

:targeted_native_failed
set "NATIVE_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] Native CTest suite, exit code %RC%"
>>"%REPORT%" echo RESULT: FAIL, exit code %RC%
goto final_summary


:targeted_editor
call :section "4/%STEP_TOTAL% JS editor-2 gate"
pushd "%ROOT%\reference"
call :say "Running editor-2 tests..."
>>"%REPORT%" echo Command: node --expose-gc tests\testbench.mjs --progress --group=editor-2
node --expose-gc tests\testbench.mjs --progress --group=editor-2 >>"%REPORT%" 2>&1
set "RC=%ERRORLEVEL%"
popd
if not "%RC%"=="0" goto targeted_editor_failed
set "EDITOR_STATUS=PASS"
call :say "[PASS] JS editor-2 gate"
>>"%REPORT%" echo RESULT: PASS
goto final_summary

:targeted_editor_failed
set "EDITOR_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] JS editor-2 gate, exit code %RC%"
>>"%REPORT%" echo RESULT: FAIL, exit code %RC%
goto final_summary

:targeted_game
call :section "3/%STEP_TOTAL% JS editor-1 gate"
pushd "%ROOT%\reference"
call :say "Running editor-1 tests..."
>>"%REPORT%" echo Command: node --expose-gc tests\testbench.mjs --progress --group=editor-1
node --expose-gc tests\testbench.mjs --progress --group=editor-1 >>"%REPORT%" 2>&1
set "RC=%ERRORLEVEL%"
popd
if not "%RC%"=="0" goto targeted_game_failed
set "GAME_STATUS=PASS"
call :say "[PASS] JS editor-1 gate"
>>"%REPORT%" echo RESULT: PASS
goto targeted_editor

:targeted_game_failed
set "GAME_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] JS editor-1 gate, exit code %RC%"
>>"%REPORT%" echo RESULT: FAIL, exit code %RC%
goto final_summary


:targeted_shared
call :section "4/%STEP_TOTAL% JS shared-2 colour data/rendering gate"
pushd "%ROOT%\reference"
call :say "Running shared-2 tests..."
>>"%REPORT%" echo Command: node --expose-gc tests\testbench.mjs --progress --group=shared-2
node --expose-gc tests\testbench.mjs --progress --group=shared-2 >>"%REPORT%" 2>&1
set "RC=%ERRORLEVEL%"
popd
if not "%RC%"=="0" goto targeted_shared_failed
set "SHARED_STATUS=PASS"
call :say "[PASS] JS shared-2 gate"
>>"%REPORT%" echo RESULT: PASS
goto final_summary

:targeted_shared_failed
set "SHARED_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] JS shared-2 gate, exit code %RC%"
>>"%REPORT%" echo RESULT: FAIL, exit code %RC%
goto final_summary

:targeted_palette
call :section "2/%STEP_TOTAL% Palette thumbnail verification"
pushd "%ROOT%\reference"
call :say "Verifying committed palette thumbnails..."
>>"%REPORT%" echo Command: node devel\build_palette_thumbnails.mjs --verify
node devel\build_palette_thumbnails.mjs --verify >>"%REPORT%" 2>&1
set "RC=%ERRORLEVEL%"
popd
if not "%RC%"=="0" goto targeted_palette_failed
call :say "[PASS] Palette thumbnail verification"
>>"%REPORT%" echo RESULT: PASS
goto targeted_native

:targeted_palette_failed
set "PALETTE_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] Palette thumbnail verification, exit code %RC%"
>>"%REPORT%" echo RESULT: FAIL, exit code %RC%
goto final_summary

:native_tests
call :section "3/%STEP_TOTAL% Native CTest suite"
call :say "Running native CTest suite..."
>>"%REPORT%" echo Command: ctest --test-dir build -C Release --output-on-failure
ctest --test-dir "%ROOT%\build" -C Release --output-on-failure >>"%REPORT%" 2>&1
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" goto native_failed
set "NATIVE_STATUS=PASS"
call :say "[PASS] Native CTest suite"
>>"%REPORT%" echo RESULT: PASS
goto js_tests

:native_failed
set "NATIVE_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] Native CTest suite, exit code %RC%"
>>"%REPORT%" echo RESULT: FAIL, exit code %RC%
if "%FULL%"=="1" (
    >>"%REPORT%" echo Full mode was requested, so independent browser and parity checks will continue.
    goto js_tests
)
>>"%REPORT%" echo The targeted run stops after the native-suite failure because the broader navigation proof sweep would have to be rerun after a native fix anyway.
goto final_summary


:batch_rebaker
call :section "4/%STEP_TOTAL% Native rebaker campaign batch"
call :say "Checking all authored numeric levels with native bake/simulation and --no-write..."
>>"%REPORT%" echo Command: "%REBAKER_EXE%" --all --simulate --no-write --resources-root "%ROOT%\reference\resources"
"%REBAKER_EXE%" --all --simulate --no-write --resources-root "%ROOT%\reference\resources" >>"%REPORT%" 2>&1
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" goto batch_failed
set "BATCH_STATUS=PASS"
call :say "[PASS] Native rebaker campaign batch"
>>"%REPORT%" echo RESULT: PASS
goto final_summary

:batch_failed
set "BATCH_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] Native rebaker campaign batch, exit code %RC%"
>>"%REPORT%" echo RESULT: FAIL, exit code %RC%
goto final_summary

:js_tests
call :section "4/%STEP_TOTAL% JS/Node release gate"
pushd "%ROOT%\reference"
if "%RESUME_JS%"=="1" goto js_resume
call :say "Running full JS release gate..."
>>"%REPORT%" echo Command: npm.cmd run test:release
call npm.cmd run test:release >>"%REPORT%" 2>&1
goto js_done

:js_resume
call :say "Running JS release gate in resume mode..."
>>"%REPORT%" echo Command: npm.cmd run test:release:resume
call npm.cmd run test:release:resume >>"%REPORT%" 2>&1

:js_done
set "RC=%ERRORLEVEL%"
popd
if not "%RC%"=="0" goto js_failed
set "JS_STATUS=PASS"
call :say "[PASS] JS/Node release gate"
>>"%REPORT%" echo RESULT: PASS
goto palette_test

:js_failed
set "JS_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] JS/Node release gate, exit code %RC%"
>>"%REPORT%" echo RESULT: FAIL, exit code %RC%
goto palette_test

:palette_test
call :section "5/%STEP_TOTAL% Palette thumbnail verification"
pushd "%ROOT%\reference"
call :say "Verifying committed palette thumbnails..."
>>"%REPORT%" echo Command: npm.cmd run check:palette-thumbnails
call npm.cmd run check:palette-thumbnails >>"%REPORT%" 2>&1
set "RC=%ERRORLEVEL%"
popd
if not "%RC%"=="0" goto palette_failed
call :say "[PASS] Palette thumbnail verification"
>>"%REPORT%" echo RESULT: PASS
goto parity_test

:palette_failed
set "PALETTE_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] Palette thumbnail verification, exit code %RC%"
>>"%REPORT%" echo RESULT: FAIL, exit code %RC%
goto parity_test

:parity_test
call :section "6/%STEP_TOTAL% JS/C++ navigation differential"
if "%SKIP_PARITY%"=="1" goto parity_skipped
if not exist "%ROOT%\verify_navigation_parity.bat" (
    set "PARITY_STATUS=FAIL"
    set "OVERALL=1"
    call :say "[FAIL] verify_navigation_parity.bat is missing"
    >>"%REPORT%" echo ERROR: verify_navigation_parity.bat is missing.
    goto final_summary
)
call :say "Running complete JS/C++ navigation differential..."
>>"%REPORT%" echo Command: call verify_navigation_parity.bat
if exist "%NAV_REPORT%" del /q "%NAV_REPORT%" >nul 2>nul
call "%ROOT%\verify_navigation_parity.bat" >>"%REPORT%" 2>&1
set "RC=%ERRORLEVEL%"
if exist "%NAV_REPORT%" (
    >>"%REPORT%" echo.
    >>"%REPORT%" echo ----- BEGIN navigation_parity_report.txt -----
    type "%NAV_REPORT%" >>"%REPORT%"
    >>"%REPORT%" echo ----- END navigation_parity_report.txt -----
)
if not "%RC%"=="0" goto parity_failed
set "PARITY_STATUS=PASS"
call :say "[PASS] JS/C++ navigation differential"
>>"%REPORT%" echo RESULT: PASS
goto final_summary

:parity_failed
set "PARITY_STATUS=FAIL"
set "OVERALL=1"
call :say "[FAIL] JS/C++ navigation differential, exit code %RC%"
>>"%REPORT%" echo RESULT: FAIL, exit code %RC%
goto final_summary

:parity_skipped
set "PARITY_STATUS=SKIPPED-BY-REQUEST"
call :say "[SKIP] Navigation differential skipped by --skip-parity"
>>"%REPORT%" echo RESULT: SKIPPED-BY-REQUEST
goto final_summary

:final_summary
rem Recompute the result from the final selected statuses so a stale earlier failure
rem cannot produce an impossible "all PASS, OVERALL FAIL" summary.
set "OVERALL=0"
if "%FULL%"=="1" (
    if /I not "%BUILD_STATUS%"=="PASS" set "OVERALL=1"
    if /I not "%FOCUSED_STATUS%"=="PASS" set "OVERALL=1"
    if /I not "%NATIVE_STATUS%"=="PASS" set "OVERALL=1"
    if /I not "%JS_STATUS%"=="PASS" set "OVERALL=1"
    if /I not "%PALETTE_STATUS%"=="PASS" set "OVERALL=1"
    if /I not "%PARITY_STATUS%"=="PASS" if /I not "%PARITY_STATUS%"=="SKIPPED-BY-REQUEST" set "OVERALL=1"
) else (
    if /I not "%DOC_STATUS%"=="PASS" set "OVERALL=1"
)
>>"%REPORT%" echo.
>>"%REPORT%" echo ============================================================
>>"%REPORT%" echo FINAL SUMMARY
>>"%REPORT%" echo ============================================================
>>"%REPORT%" echo Candidate label:        %LABEL%
>>"%REPORT%" echo Internal revision:      %REVISION%
>>"%REPORT%" echo Verification profile:   %PROFILE%
if "%FULL%"=="1" (
    >>"%REPORT%" echo Windows Release build:  %BUILD_STATUS%
    >>"%REPORT%" echo Focused nav smoke:       %FOCUSED_STATUS%
    >>"%REPORT%" echo Native CTest suite:     %NATIVE_STATUS%
    >>"%REPORT%" echo JS/Node release gate:   %JS_STATUS%
    >>"%REPORT%" echo Palette verification:   %PALETTE_STATUS%
    >>"%REPORT%" echo Navigation differential:%PARITY_STATUS%
) else (
    >>"%REPORT%" echo Targeted rev-803 check: %DOC_STATUS%
)
if "%OVERALL%"=="0" (
    >>"%REPORT%" echo OVERALL:              PASS
) else (
    >>"%REPORT%" echo OVERALL:              FAIL
)
>>"%REPORT%" echo Finished: %DATE% %TIME%

call :say ""
call :say "============================================================"
call :say "Final summary"
call :say "============================================================"
call :say "Profile:     %PROFILE%"
if "%FULL%"=="1" (
    call :say "Build:       %BUILD_STATUS%"
    call :say "Focused nav: %FOCUSED_STATUS%"
    call :say "Native:      %NATIVE_STATUS%"
    call :say "JS release:  %JS_STATUS%"
    call :say "Palette:     %PALETTE_STATUS%"
    call :say "Nav parity:  %PARITY_STATUS%"
) else (
    call :say "Targeted rev-803: %DOC_STATUS%"
)
if "%OVERALL%"=="0" (
    call :say "OVERALL:     PASS"
) else (
    call :say "OVERALL:     FAIL"
)
call :say ""
call :say "Please send this single report file back with the candidate result:"
call :say "  %REPORT%"

exit /b %OVERALL%

:usage
echo Usage: verify_revision_candidate.bat [candidate-label] [options]
echo.
echo No arguments runs the manually curated verification sequence for this revision.
echo   --full         Run the complete cross-platform battery, including navigation parity.
echo   --clean        Force a clean Windows Release build.
echo   --incremental  Force an incremental Windows Release build.
echo   --resume-js    In --full mode, resume the sharded JS release gate.
echo   --skip-parity  In --full mode, omit the expensive navigation differential.
echo.
echo Examples:
echo   verify_revision_candidate.bat
echo   verify_revision_candidate.bat 776b1
echo   verify_revision_candidate.bat 776b1 --full
exit /b 0

:section
call :say ""
call :say "============================================================"
call :say "%~1"
call :say "Started: %DATE% %TIME%"
call :say "============================================================"
>>"%REPORT%" echo.
>>"%REPORT%" echo ============================================================
>>"%REPORT%" echo %~1
>>"%REPORT%" echo Started: %DATE% %TIME%
>>"%REPORT%" echo ============================================================
exit /b 0

:say
if "%~1"=="" (
    echo.
) else (
    echo %~1
)
exit /b 0

:record_version
>>"%REPORT%" echo %~1:
cmd /d /s /c "%~2" >>"%REPORT%" 2>&1
>>"%REPORT%" echo.
exit /b 0

:prereq_fail
set "BUILD_STATUS=FAIL"
set "OVERALL=1"
call :say "ERROR: %~1"
>>"%REPORT%" echo ERROR: %~1
exit /b 0
