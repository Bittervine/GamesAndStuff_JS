#include "native/app/internal.h"

// IgnatiusNativeScene partition: shared drawing helpers, rocket/pickup/effect rendering, projectile rendering, and enemy health overlays.
// Keep portable gameplay decisions in Simulation/shared code so JS/C++ parity
// remains reviewable independently of this SDL-specific presentation shell.

namespace Ignatius
{
    namespace IgnatiusAppDetail
    {
        std::uint64_t compiledIgnatiusAppEffectsRendererEnemyStateAbiSignature() noexcept
        {
            return enemyStateAbiSignature();
        }

            void IgnatiusNativeScene::syncCameraViewportFromView(const NativeRenderView& view)
            {
                // Match the browser reference: camera.viewportWidth/Height are the
                // virtual world-space viewport reported by the renderer, not the
                // physical output pixel dimensions. Gameplay systems such as homing
                // target visibility read these values during the fixed step.
                const double safeZoom = std::max(0.1, view.zoom);
                gameState.camera.viewportWidth = std::max(1.0, static_cast<double>(view.viewportWidth) / safeZoom);
                gameState.camera.viewportHeight = std::max(1.0, static_cast<double>(view.viewportHeight) / safeZoom);
            }



            SDL_FPoint IgnatiusNativeScene::worldToScreen(const NativeRenderView& view, double worldX, double worldY) const
            {
                return SDL_FPoint{
                    static_cast<float>((worldX - view.left) * view.zoom),
                    static_cast<float>((worldY - view.top) * view.zoom)
                };
            }



            bool IgnatiusNativeScene::worldPointVisible(const NativeRenderView& view, double worldX, double worldY, double marginPixels) const
            {
                const double marginWorld = marginPixels / std::max(0.1, view.zoom);
                return worldX >= view.left - marginWorld
                    && worldX <= view.left + static_cast<double>(view.viewportWidth) / view.zoom + marginWorld
                    && worldY >= view.top - marginWorld
                    && worldY <= view.top + static_cast<double>(view.viewportHeight) / view.zoom + marginWorld;
            }



            bool IgnatiusNativeScene::dynamicBoundsVisible(const FWorldRect& bounds, const NativeRenderView& view, double marginPixels) const
            {
                const double safeZoom = std::max(0.1, view.zoom);
                const double marginWorld = marginPixels / safeZoom;
                const double minX = std::min(bounds.x, bounds.x + bounds.w);
                const double maxX = std::max(bounds.x, bounds.x + bounds.w);
                const double minY = std::min(bounds.y, bounds.y + bounds.h);
                const double maxY = std::max(bounds.y, bounds.y + bounds.h);
                const double viewRight = view.left + static_cast<double>(view.viewportWidth) / safeZoom;
                const double viewBottom = view.top + static_cast<double>(view.viewportHeight) / safeZoom;
                return maxX >= view.left - marginWorld
                    && minX <= viewRight + marginWorld
                    && maxY >= view.top - marginWorld
                    && minY <= viewBottom + marginWorld;
            }



            void IgnatiusNativeScene::drawFilledEllipse(float centerX, float centerY, float radiusX, float radiusY, SDL_Color color)
            {
                if (!(radiusX > 0.0f) || !(radiusY > 0.0f) || color.a == 0)
                {
                    return;
                }

                if (rawGpuOverlayBatcher)
                {
                    const SDL_FColor fColor{
                        static_cast<float>(color.r) / 255.0f,
                        static_cast<float>(color.g) / 255.0f,
                        static_cast<float>(color.b) / 255.0f,
                        static_cast<float>(color.a) / 255.0f
                    };
                    if (rawWorldCircleTextureGpu)
                    {
                        rawGpuOverlayBatcher->appendQuad(
                            rawWorldCircleTextureGpu,
                            centerX - radiusX,
                            centerY - radiusY,
                            radiusX * 2.0f,
                            radiusY * 2.0f,
                            0.0f,
                            0.0f,
                            0.0f,
                            1.0f,
                            1.0f,
                            fColor);
                    }
                    else
                    {
                        const int extent = std::max(1, static_cast<int>(std::ceil(radiusY)));
                        for (int y = -extent; y <= extent; ++y)
                        {
                            const float normalizedY = static_cast<float>(y) / std::max(0.0001f, radiusY);
                            const float remaining = std::max(0.0f, 1.0f - normalizedY * normalizedY);
                            const float halfWidth = radiusX * std::sqrt(remaining);
                            rawGpuOverlayBatcher->drawSolidRect(
                                SDL_FRect{ centerX - halfWidth, centerY + static_cast<float>(y), halfWidth * 2.0f, 1.0f },
                                fColor);
                        }
                    }
                    return;
                }

                if (!renderer)
                {
                    return;
                }
                SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
                SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
                const int extent = std::max(1, static_cast<int>(std::ceil(radiusY)));
                for (int y = -extent; y <= extent; ++y)
                {
                    const float normalizedY = static_cast<float>(y) / std::max(0.0001f, radiusY);
                    const float remaining = std::max(0.0f, 1.0f - normalizedY * normalizedY);
                    const float halfWidth = radiusX * std::sqrt(remaining);
                    SDL_RenderLine(renderer, centerX - halfWidth, centerY + static_cast<float>(y), centerX + halfWidth, centerY + static_cast<float>(y));
                }
            }



            void IgnatiusNativeScene::drawFilledCircle(float centerX, float centerY, float radius, SDL_Color color)
            {
                drawFilledEllipse(centerX, centerY, radius, radius, color);
            }



            void IgnatiusNativeScene::drawSparkBurst(float x, float y, float viewZoom, double seed, std::int32_t count, float radius, const std::string& palette, float spreadX, float spreadY)
            {
                if (!(count > 0) || !(radius > 0.0f))
                {
                    return;
                }

                const bool overdrivePalette = palette == "overdrive";
                const bool enemyPalette = palette == "enemy";
                const float sizeScale = overdrivePalette ? 1.5f : 1.0f;
                const float safeSpreadX = std::max(0.1f, spreadX);
                const float safeSpreadY = std::max(0.1f, spreadY);
                for (std::int32_t index = 0; index < count; ++index)
                {
                    const double angle = projectileTrailHashNoise(seed, index) * std::numbers::pi * 2.0;
                    const float sparkDistance = radius * (0.25f + static_cast<float>(projectileTrailHashNoise(seed + 31.0, index)) * 0.75f);
                    const float sparkX = x + static_cast<float>(std::cos(angle) * sparkDistance * safeSpreadX);
                    const float sparkY = y + static_cast<float>(std::sin(angle) * sparkDistance * safeSpreadY);
                    const float sparkRadius = std::max(
                        0.8f,
                        (enemyPalette ? 0.9f : 1.1f)
                        * (1.0f + static_cast<float>(projectileTrailHashNoise(seed + 71.0, index))
                            * (enemyPalette ? 1.7f : 2.3f))
                        * viewZoom * sizeScale);
                    const double sparkAlpha = std::clamp(
                        ((enemyPalette ? 0.22 : 0.28) + static_cast<double>(projectileTrailHashNoise(seed + 109.0, index))
                            * (enemyPalette ? 0.28 : 0.38)) * 255.0,
                        0.0,
                        enemyPalette ? 128.0 : 189.0);
                    const Uint8 alpha = static_cast<Uint8>(sparkAlpha);
                    SDL_Color color = enemyPalette
                        ? (index % 2 == 0 ? SDL_Color{ 255, 92, 68, alpha } : SDL_Color{ 255, 155, 84, alpha })
                        : overdrivePalette
                            ? (index % 3 == 0 ? SDL_Color{ 255, 255, 206, alpha } : (index % 2 == 0 ? SDL_Color{ 255, 228, 86, alpha } : SDL_Color{ 255, 194, 40, alpha }))
                            : (index % 3 == 0 ? SDL_Color{ 255, 246, 166, alpha } : SDL_Color{ 255, 137, 82, alpha });
                    drawFilledCircle(sparkX, sparkY, sparkRadius, color);
                }
            }



            void IgnatiusNativeScene::drawRing(float centerX, float centerY, float radius, float thickness, SDL_Color color)
            {
                if (!(radius > 0.0f) || color.a == 0)
                {
                    return;
                }

                if (rawGpuOverlayBatcher)
                {
                    const SDL_FColor fColor{
                        static_cast<float>(color.r) / 255.0f,
                        static_cast<float>(color.g) / 255.0f,
                        static_cast<float>(color.b) / 255.0f,
                        static_cast<float>(color.a) / 255.0f
                    };
                    if (rawWorldRingTextureGpu)
                    {
                        const float diameter = radius * 2.0f;
                        rawGpuOverlayBatcher->appendQuad(
                            rawWorldRingTextureGpu,
                            centerX - radius,
                            centerY - radius,
                            diameter,
                            diameter,
                            0.0f,
                            0.0f,
                            0.0f,
                            1.0f,
                            1.0f,
                            fColor);
                    }
                    else
                    {
                        const int segments = std::clamp(static_cast<int>(radius * 0.8f), 24, 72);
                        float previousX = centerX + radius;
                        float previousY = centerY;
                        for (int segment = 1; segment <= segments; ++segment)
                        {
                            const double angle = static_cast<double>(segment) * 2.0 * std::numbers::pi / static_cast<double>(segments);
                            const float nextX = centerX + static_cast<float>(std::cos(angle) * radius);
                            const float nextY = centerY + static_cast<float>(std::sin(angle) * radius);
                            rawGpuOverlayBatcher->drawLine(
                                SDL_FPoint{ previousX, previousY },
                                SDL_FPoint{ nextX, nextY },
                                std::max(1.0f, thickness),
                                fColor);
                            previousX = nextX;
                            previousY = nextY;
                        }
                    }
                    return;
                }

                if (!renderer)
                {
                    return;
                }
                SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
                SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
                const int segments = std::clamp(static_cast<int>(radius * 0.8f), 24, 72);
                const float safeThickness = std::max(1.0f, thickness);
                for (int band = 0; band < static_cast<int>(std::ceil(safeThickness)); ++band)
                {
                    const float bandRadius = radius - static_cast<float>(band) * 0.55f;
                    float previousX = centerX + bandRadius;
                    float previousY = centerY;
                    for (int segment = 1; segment <= segments; ++segment)
                    {
                        const double angle = static_cast<double>(segment) * 2.0 * std::numbers::pi / static_cast<double>(segments);
                        const float nextX = centerX + static_cast<float>(std::cos(angle) * bandRadius);
                        const float nextY = centerY + static_cast<float>(std::sin(angle) * bandRadius);
                        SDL_RenderLine(renderer, previousX, previousY, nextX, nextY);
                        previousX = nextX;
                        previousY = nextY;
                    }
                }
            }



            void IgnatiusNativeScene::drawTextureRect(SDL_Texture* texture, SDL_GPUTexture* gpuTexture, float x, float y, float width, float height, SDL_Color color)
            {
                if (!(width > 0.0f) || !(height > 0.0f) || color.a == 0)
                {
                    return;
                }

                if (rawGpuOverlayBatcher)
                {
                    const SDL_FColor fColor{
                        static_cast<float>(color.r) / 255.0f,
                        static_cast<float>(color.g) / 255.0f,
                        static_cast<float>(color.b) / 255.0f,
                        static_cast<float>(color.a) / 255.0f
                    };
                    const SDL_FRect destination{ x, y, width, height };
                    if (gpuTexture)
                    {
                        rawGpuOverlayBatcher->drawSprite(gpuTexture, destination, fColor);
                    }
                    else
                    {
                        rawGpuOverlayBatcher->drawSolidRect(destination, fColor);
                    }
                    return;
                }

                if (!renderer)
                {
                    return;
                }

                SDL_FRect rect{ x, y, width, height };
                SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
                if (!texture)
                {
                    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
                    SDL_RenderFillRect(renderer, &rect);
                    return;
                }

                SDL_SetTextureColorModFloat(texture, static_cast<float>(color.r) / 255.0f, static_cast<float>(color.g) / 255.0f, static_cast<float>(color.b) / 255.0f);
                SDL_SetTextureAlphaModFloat(texture, static_cast<float>(color.a) / 255.0f);
                SDL_RenderTexture(renderer, texture, nullptr, &rect);
                SDL_SetTextureAlphaModFloat(texture, 1.0f);
                SDL_SetTextureColorModFloat(texture, 1.0f, 1.0f, 1.0f);
            }



            void IgnatiusNativeScene::drawTextureRectRotated(
                SDL_Texture* texture,
                SDL_GPUTexture* gpuTexture,
                const SDL_FRect& destination,
                float angleDegrees,
                SDL_Color color)
            {
                if (!(destination.w > 0.0f) || !(destination.h > 0.0f) || color.a == 0)
                {
                    return;
                }

                if (rawGpuOverlayBatcher)
                {
                    const SDL_FColor fColor{
                        static_cast<float>(color.r) / 255.0f,
                        static_cast<float>(color.g) / 255.0f,
                        static_cast<float>(color.b) / 255.0f,
                        static_cast<float>(color.a) / 255.0f
                    };
                    if (gpuTexture)
                    {
                        rawGpuOverlayBatcher->drawRotatedSprite(
                            gpuTexture,
                            destination,
                            angleDegrees,
                            SDL_FPoint{ 0.5f, 0.5f },
                            SDL_FLIP_NONE,
                            fColor);
                    }
                    else
                    {
                        rawGpuOverlayBatcher->drawSolidRect(destination, fColor);
                    }
                    return;
                }

                if (!renderer)
                {
                    return;
                }
                SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
                if (!texture)
                {
                    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
                    SDL_RenderFillRect(renderer, &destination);
                    return;
                }
                SDL_SetTextureColorModFloat(texture, static_cast<float>(color.r) / 255.0f, static_cast<float>(color.g) / 255.0f, static_cast<float>(color.b) / 255.0f);
                SDL_SetTextureAlphaModFloat(texture, static_cast<float>(color.a) / 255.0f);
                const SDL_FPoint center{ destination.w * 0.5f, destination.h * 0.5f };
                SDL_RenderTextureRotated(renderer, texture, nullptr, &destination, angleDegrees, &center, SDL_FLIP_NONE);
                SDL_SetTextureAlphaModFloat(texture, 1.0f);
                SDL_SetTextureColorModFloat(texture, 1.0f, 1.0f, 1.0f);
            }



            void IgnatiusNativeScene::drawTextureRectClipped(
                SDL_Texture* texture,
                SDL_GPUTexture* gpuTexture,
                const SDL_FRect& destination,
                const SDL_FRect& clipBounds,
                SDL_Color color)
            {
                if (!(destination.w > 0.0f) || !(destination.h > 0.0f) || color.a == 0)
                {
                    return;
                }

                const float left = std::max(destination.x, clipBounds.x);
                const float top = std::max(destination.y, clipBounds.y);
                const float right = std::min(destination.x + destination.w, clipBounds.x + clipBounds.w);
                const float bottom = std::min(destination.y + destination.h, clipBounds.y + clipBounds.h);
                if (!(right > left) || !(bottom > top))
                {
                    return;
                }

                const float u0 = std::clamp((left - destination.x) / destination.w, 0.0f, 1.0f);
                const float v0 = std::clamp((top - destination.y) / destination.h, 0.0f, 1.0f);
                const float u1 = std::clamp((right - destination.x) / destination.w, 0.0f, 1.0f);
                const float v1 = std::clamp((bottom - destination.y) / destination.h, 0.0f, 1.0f);
                const SDL_FRect clipped{ left, top, right - left, bottom - top };

                if (rawGpuOverlayBatcher && gpuTexture)
                {
                    const SDL_FColor fColor{
                        static_cast<float>(color.r) / 255.0f,
                        static_cast<float>(color.g) / 255.0f,
                        static_cast<float>(color.b) / 255.0f,
                        static_cast<float>(color.a) / 255.0f
                    };
                    rawGpuOverlayBatcher->appendQuad(
                        gpuTexture,
                        clipped.x,
                        clipped.y,
                        clipped.w,
                        clipped.h,
                        0.0f,
                        u0,
                        v0,
                        u1,
                        v1,
                        fColor);
                    return;
                }

                if (!renderer)
                {
                    return;
                }
                if (!texture)
                {
                    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
                    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
                    SDL_RenderFillRect(renderer, &clipped);
                    return;
                }

                float textureWidth = 0.0f;
                float textureHeight = 0.0f;
                SDL_GetTextureSize(texture, &textureWidth, &textureHeight);
                const SDL_FRect source{
                    u0 * textureWidth,
                    v0 * textureHeight,
                    (u1 - u0) * textureWidth,
                    (v1 - v0) * textureHeight
                };
                SDL_SetTextureColorModFloat(texture, static_cast<float>(color.r) / 255.0f, static_cast<float>(color.g) / 255.0f, static_cast<float>(color.b) / 255.0f);
                SDL_SetTextureAlphaModFloat(texture, static_cast<float>(color.a) / 255.0f);
                SDL_RenderTexture(renderer, texture, &source, &clipped);
            }



            void IgnatiusNativeScene::drawLineSegment(float x0, float y0, float x1, float y1, float thickness, SDL_Color color)
            {
                if (color.a == 0 || !(thickness > 0.0f))
                {
                    return;
                }

                const float dx = x1 - x0;
                const float dy = y1 - y0;
                const float length = std::hypot(dx, dy);
                if (!(length > 0.0f))
                {
                    return;
                }

                if (rawGpuOverlayBatcher && canvasWhiteTextureGpu)
                {
                    const SDL_FColor fColor{
                        static_cast<float>(color.r) / 255.0f,
                        static_cast<float>(color.g) / 255.0f,
                        static_cast<float>(color.b) / 255.0f,
                        static_cast<float>(color.a) / 255.0f
                    };
                    rawGpuOverlayBatcher->drawLine(
                        SDL_FPoint{ x0, y0 },
                        SDL_FPoint{ x1, y1 },
                        std::max(1.0f, thickness),
                        fColor);
                    return;
                }

                SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
                SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
                if (thickness <= 1.0f)
                {
                    SDL_RenderLine(renderer, x0, y0, x1, y1);
                    return;
                }

                const float halfThickness = thickness * 0.5f;
                const float normalX = -dy / length * halfThickness;
                const float normalY = dx / length * halfThickness;
                const SDL_FColor vertexColor{
                    static_cast<float>(color.r) / 255.0f,
                    static_cast<float>(color.g) / 255.0f,
                    static_cast<float>(color.b) / 255.0f,
                    static_cast<float>(color.a) / 255.0f
                };
                SDL_Vertex vertices[4]{};
                vertices[0].position = SDL_FPoint{ x0 + normalX, y0 + normalY };
                vertices[1].position = SDL_FPoint{ x1 + normalX, y1 + normalY };
                vertices[2].position = SDL_FPoint{ x1 - normalX, y1 - normalY };
                vertices[3].position = SDL_FPoint{ x0 - normalX, y0 - normalY };
                for (SDL_Vertex& vertex : vertices)
                {
                    vertex.color = vertexColor;
                }
                constexpr int indices[6] = { 0, 1, 2, 0, 2, 3 };
                SDL_RenderGeometry(renderer, nullptr, vertices, 4, indices, 6);

                // Canvas uses round line caps for projectile trails.  Matching
                // those caps also avoids gaps where curved trail segments meet.
                drawFilledCircle(x0, y0, halfThickness, color);
                drawFilledCircle(x1, y1, halfThickness, color);
            }



            void IgnatiusNativeScene::drawActorShadow(const NativeRenderView& view, double worldX, double groundY, double actorScale, double opacity)
            {
                if (!worldPointVisible(view, worldX, groundY, 80.0))
                {
                    return;
                }

                const double safeScale = std::max(0.05, actorScale);
                const SDL_FPoint screen = worldToScreen(view, worldX, groundY);
                const float radiusX = static_cast<float>(std::max(18.0, 46.0 * safeScale) * view.zoom);
                const float radiusY = static_cast<float>(std::max(4.0, 8.0 * safeScale) * view.zoom);
                const float centerY = screen.y + static_cast<float>(4.0 * safeScale * view.zoom);
                const Uint8 alpha = static_cast<Uint8>(std::clamp(opacity, 0.0, 1.0) * 0.26 * 255.0);
                drawFilledEllipse(screen.x, centerY, radiusX, radiusY, SDL_Color{ 0, 0, 0, alpha });
            }




            SDL_Color IgnatiusNativeScene::scaledAlpha(SDL_Color color, double alphaScale)
            {
                color.a = static_cast<Uint8>(std::clamp(static_cast<double>(color.a) * alphaScale, 0.0, 255.0));
                return color;
            }



            SDL_Color IgnatiusNativeScene::withAlpha(SDL_Color color, double alpha)
            {
                color.a = static_cast<Uint8>(std::clamp(alpha, 0.0, 255.0));
                return color;
            }



            int IgnatiusNativeScene::hexNibble(char ch)
            {
                if (ch >= '0' && ch <= '9')
                {
                    return ch - '0';
                }
                if (ch >= 'a' && ch <= 'f')
                {
                    return 10 + ch - 'a';
                }
                if (ch >= 'A' && ch <= 'F')
                {
                    return 10 + ch - 'A';
                }
                return -1;
            }



            std::optional<SDL_Color> IgnatiusNativeScene::parseHexColor(const std::string& value, Uint8 alpha)
            {
                if (value.size() != 7 || value[0] != '#')
                {
                    return {};
                }
                int components[3]{};
                for (int component = 0; component < 3; ++component)
                {
                    const int high = hexNibble(value[1 + component * 2]);
                    const int low = hexNibble(value[2 + component * 2]);
                    if (high < 0 || low < 0)
                    {
                        return {};
                    }
                    components[component] = high * 16 + low;
                }
                return SDL_Color{
                    static_cast<Uint8>(components[0]),
                    static_cast<Uint8>(components[1]),
                    static_cast<Uint8>(components[2]),
                    alpha
                };
            }



            SDL_FPoint IgnatiusNativeScene::rotateScreenOffset(float localX, float localY, double degrees)
            {
                const double radians = degrees * std::numbers::pi / 180.0;
                const double c = std::cos(radians);
                const double s = std::sin(radians);
                return SDL_FPoint{
                    static_cast<float>(static_cast<double>(localX) * c - static_cast<double>(localY) * s),
                    static_cast<float>(static_cast<double>(localX) * s + static_cast<double>(localY) * c)
                };
            }



            bool IgnatiusNativeScene::deluxeRocketExhaustEnabled() const
            {
                return persistentSettings.renderingQuality == "high"
                    && rendererUsesGpuBackend
                    && rawGpuOverlayBatcher != nullptr
                    && sharedSoftParticleTextureGpu != nullptr;
            }



            bool IgnatiusNativeScene::animatedRocketFlameAtlasEnabled() const
            {
                return persistentSettings.renderingQuality == "medium"
                    || (persistentSettings.renderingQuality == "high" && !deluxeRocketExhaustEnabled());
            }



            float IgnatiusNativeScene::rocketFlameAtlasTargetHeight(float rocketTargetHeight)
            {
                const double safeTargetHeight = std::max(0.0, static_cast<double>(rocketTargetHeight));
                const double gameplayScale = std::max(0.035, safeTargetHeight / DELUXE_ROCKET_EXHAUST_REFERENCE_HEIGHT);
                return static_cast<float>(ROCKET_FLAME_ATLAS_FRAME_HEIGHT * gameplayScale / ROCKET_FLAME_ATLAS_BAKED_TITLE_SCALE);
            }



            const FNativeAtlasFrameAsset* IgnatiusNativeScene::rocketFlameAtlasFrame(double seed) const
            {
                const auto baseFrame = static_cast<std::int64_t>(std::floor(
                    std::max(0.0, rocketFlamePresentationTime) * static_cast<double>(ROCKET_FLAME_ATLAS_FRAME_RATE)));
                const auto phaseOffset = static_cast<std::int64_t>(std::floor(std::abs(std::isfinite(seed) ? seed : 0.0)))
                    % static_cast<std::int64_t>(ROCKET_FLAME_ATLAS_FRAME_COUNT);
                const int frameIndex = static_cast<int>((baseFrame + phaseOffset)
                    % static_cast<std::int64_t>(ROCKET_FLAME_ATLAS_FRAME_COUNT));
                std::string frameId = "rocket_flame_";
                if (frameIndex < 10) frameId += "00";
                else if (frameIndex < 100) frameId += "0";
                frameId += std::to_string(frameIndex);
                return findLoadedCharacterFrame("ct_char_wizard_1", frameId);
            }



            bool IgnatiusNativeScene::drawAnimatedRocketFlameAtlas(
                float sourceX,
                float sourceY,
                double exhaustAngleRadians,
                float targetHeight,
                double seed)
            {
                if (!animatedRocketFlameAtlasEnabled() || !(targetHeight > 0.0f))
                {
                    return false;
                }
                const FNativeAtlasFrameAsset* asset = rocketFlameAtlasFrame(seed);
                if (!asset)
                {
                    return false;
                }
                if (rawGpuOverlayBatcher)
                {
                    rawGpuOverlayBatcher->setBlendMode(GpuCanvas2DBlendMode::Additive);
                }
                SDL_BlendMode previousBlendMode = SDL_BLENDMODE_BLEND;
                const bool additiveTexture = !rawGpuOverlayBatcher && renderer && asset->texture;
                if (additiveTexture)
                {
                    SDL_GetTextureBlendMode(asset->texture, &previousBlendMode);
                    SDL_SetTextureBlendMode(asset->texture, SDL_BLENDMODE_ADD);
                }
                const bool drew = drawAtlasFrameCentered(
                    asset,
                    sourceX,
                    sourceY,
                    targetHeight,
                    exhaustAngleRadians - std::numbers::pi * 0.5,
                    ROCKET_FLAME_ATLAS_ANCHOR_X / ROCKET_FLAME_ATLAS_FRAME_WIDTH,
                    ROCKET_FLAME_ATLAS_ANCHOR_Y / ROCKET_FLAME_ATLAS_FRAME_HEIGHT);
                if (rawGpuOverlayBatcher)
                {
                    // The captured flame is emissive, but the rest of the wizard rig is ordinary
                    // alpha artwork. Keep additive blending scoped to this atlas quad only.
                    rawGpuOverlayBatcher->setBlendMode(GpuCanvas2DBlendMode::Alpha);
                }
                if (additiveTexture)
                {
                    SDL_SetTextureBlendMode(asset->texture, previousBlendMode);
                }
                return drew;
            }



            bool IgnatiusNativeScene::mountedRocketExhaustActive() const
            {
                const FRocketState& rocket = gameState.equipment.rocket;
                const bool airborneFlight = rocket.state == "flight" && !gameState.player.onGround;
                return rocket.attachedBoosting
                    || airborneFlight
                    || rocket.state == "lunge"
                    || gameState.player.lungeActive;
            }



            bool IgnatiusNativeScene::mountedRocketNozzleTransform(
                const FRuntimeCharacterDrawPartInfo& partInfo,
                float& sourceX,
                float& sourceY,
                double& exhaustAngleRadians,
                double& particleScale) const
            {
                if (partInfo.partName != "rocket" || !partInfo.asset)
                {
                    return false;
                }
                const auto pivotIt = playerProject.rig.pivots.find("rocket");
                const auto partIt = playerProject.rig.parts.find("rocket");
                if (pivotIt == playerProject.rig.pivots.end() || partIt == playerProject.rig.parts.end())
                {
                    return false;
                }

                const FNativeAtlasFrameAsset& asset = *partInfo.asset;
                const FRigPoint& pivot = pivotIt->second;
                const double spriteScale = std::max(0.0001, partInfo.spriteScale);
                const float pivotScreenX = partInfo.placement.destination.x + partInfo.placement.rotationCenter.x;
                const float pivotScreenY = partInfo.placement.destination.y + partInfo.placement.rotationCenter.y;
                const float facingSign = partInfo.placement.flip == SDL_FLIP_HORIZONTAL ? -1.0f : 1.0f;
                const float localX = static_cast<float>((0.5 - pivot.x) * static_cast<double>(asset.w) * spriteScale) * facingSign;
                const float localY = static_cast<float>((0.965 - pivot.y) * static_cast<double>(asset.h) * spriteScale);
                const SDL_FPoint rotated = rotateScreenOffset(localX, localY, partInfo.placement.rotationDegrees);
                sourceX = pivotScreenX + rotated.x;
                sourceY = pivotScreenY + rotated.y;
                exhaustAngleRadians = partInfo.placement.rotationDegrees * std::numbers::pi / 180.0 + std::numbers::pi * 0.5;
                const double nominalTargetHeight = std::max(
                    0.001,
                    partIt->second.targetHeight * std::max(0.0001, playerProject.rig.global.scale));
                particleScale = std::max(0.01, partInfo.targetHeight / nominalTargetHeight);
                return true;
            }



            void IgnatiusNativeScene::drawDeluxeRocketExhaustSample(
                float sourceX,
                float sourceY,
                double exhaustAngleRadians,
                double scale,
                double seed,
                double gameTimeSeconds,
                bool includeSmoke)
            {
                if (!rawGpuOverlayBatcher || !sharedSoftParticleTextureGpu)
                {
                    return;
                }

                GpuCanvas2D& batcher = *rawGpuOverlayBatcher;
                SDL_GPUTexture* const softTexture = sharedSoftParticleTextureGpu;
                const double gameplayScale = std::max(0.035, std::isfinite(scale) ? scale : DELUXE_ROCKET_EXHAUST_TITLE_SCALE);
                const double elapsed = std::max(0.0, std::isfinite(gameTimeSeconds) ? gameTimeSeconds : 0.0) + seed * 0.013;
                const double directionX = std::cos(exhaustAngleRadians);
                const double directionY = std::sin(exhaustAngleRadians);
                const double perpendicularX = -directionY;
                const double perpendicularY = directionX;
                const float rotationDegrees = static_cast<float>(exhaustAngleRadians * 180.0 / std::numbers::pi);
                const auto fract = [](double value) { return value - std::floor(value); };
                const auto hash01 = [&](int index, int salt)
                {
                    return fract(std::sin((static_cast<double>(index) + 1.0 + seed * 0.017) * 12.9898 + static_cast<double>(salt) * 78.233) * 43758.5453123);
                };
                const auto queueSoft = [&](double x, double y, double radiusX, double radiusY, SDL_FColor color, double alpha, bool additive)
                {
                    color.a = static_cast<float>(std::clamp(alpha, 0.0, 1.0));
                    batcher.setBlendMode(additive ? GpuCanvas2DBlendMode::AlphaAdditive : GpuCanvas2DBlendMode::Alpha);
                    return batcher.appendTransformedQuad(
                        softTexture,
                        static_cast<float>(x),
                        static_cast<float>(y),
                        static_cast<float>(std::max(0.5, radiusX * gameplayScale * 2.0)),
                        static_cast<float>(std::max(0.5, radiusY * gameplayScale * 2.0)),
                        rotationDegrees,
                        0.5f,
                        0.5f,
                        0.0f,
                        0.0f,
                        0.0f,
                        1.0f,
                        1.0f,
                        SDL_FLIP_NONE,
                        color);
                };

                // High is an on/off gate for this title-derived recipe. Do not apply
                // the generic High-quality 1.5x particle multiplier a second time.
                if (includeSmoke)
                {
                    constexpr int smokeCount = 14;
                    for (int index = 0; index < smokeCount; ++index)
                    {
                        const double age = fract(elapsed / 2.05 + hash01(index, 3));
                        const double distance = 42.0 + age * 280.0;
                        const double lateral = (hash01(index, 4) - 0.5) * (24.0 + age * 88.0)
                            + std::sin(elapsed * 1.7 + index * 2.41) * (3.0 + age * 8.0);
                        const double rise = age * (18.0 + 24.0 * hash01(index, 8));
                        const double x = sourceX + (directionX * distance + perpendicularX * lateral) * gameplayScale;
                        const double y = sourceY + (directionY * distance + perpendicularY * lateral - rise) * gameplayScale;
                        const double fade = std::pow(1.0 - age, 1.15);
                        const double radius = 18.0 + age * 38.0 + hash01(index, 9) * 10.0;
                        queueSoft(x, y, radius * 1.25, radius, SDL_FColor{ 218.0f / 255.0f, 210.0f / 255.0f, 205.0f / 255.0f, 1.0f }, 0.30 * fade, false);
                    }
                }

                const double nozzlePulse = 0.94 + 0.06 * std::sin(elapsed * 12.7);
                const double nozzleX = sourceX + directionX * 22.0 * gameplayScale;
                const double nozzleY = sourceY + directionY * 22.0 * gameplayScale;
                queueSoft(nozzleX, nozzleY, 72.0 * nozzlePulse, 46.0 * nozzlePulse, SDL_FColor{ 1.0f, 132.0f / 255.0f, 16.0f / 255.0f, 1.0f }, 0.46, true);
                queueSoft(nozzleX, nozzleY, 52.0 * nozzlePulse, 33.0 * nozzlePulse, SDL_FColor{ 1.0f, 218.0f / 255.0f, 78.0f / 255.0f, 1.0f }, 0.64, true);
                queueSoft(nozzleX, nozzleY, 31.0 * nozzlePulse, 20.0 * nozzlePulse, SDL_FColor{ 1.0f, 1.0f, 238.0f / 255.0f, 1.0f }, 0.87, true);

                constexpr int coreCount = 9;
                for (int index = coreCount - 1; index >= 0; --index)
                {
                    const double t = (static_cast<double>(index) + 0.2) / static_cast<double>(coreCount);
                    const double flicker = 0.91 + 0.09 * std::sin(elapsed * 10.5 + index * 1.83);
                    const double distance = (8.0 + t * 160.0) * flicker;
                    const double lateral = (hash01(index, 14) - 0.5) * (8.0 + t * 20.0)
                        + std::sin(elapsed * 8.7 + index * 1.31) * (2.0 + t * 7.0);
                    const double x = sourceX + (directionX * distance + perpendicularX * lateral) * gameplayScale;
                    const double y = sourceY + (directionY * distance + perpendicularY * lateral) * gameplayScale;
                    const double width = (30.0 + t * 36.0) * (0.94 + 0.08 * std::sin(elapsed * 12.1 + index));
                    const double length = width * (1.18 + 0.42 * (1.0 - t));
                    const double tailFade = std::pow(1.0 - t * 0.72, 1.15);
                    queueSoft(x, y, length * 1.35, width * 1.28, SDL_FColor{ 1.0f, 88.0f / 255.0f, 8.0f / 255.0f, 1.0f }, 0.30 * tailFade, true);
                    queueSoft(x, y, length * 0.95, width * 0.86, SDL_FColor{ 1.0f, 185.0f / 255.0f, 38.0f / 255.0f, 1.0f }, 0.44 * tailFade, true);
                    queueSoft(x, y, length * 0.55, width * 0.52, SDL_FColor{ 1.0f, 250.0f / 255.0f, 222.0f / 255.0f, 1.0f }, 0.56 * tailFade, true);
                }

                // Advance only the gameplay flame phase faster. Age stays normalized, so the
                // authored distance/radius envelope (and therefore plume length) is unchanged.
                const double flameElapsed = elapsed * DELUXE_ROCKET_FLAME_ANIMATION_SPEED;
                constexpr int flameCount = 30;
                for (int index = 0; index < flameCount; ++index)
                {
                    const double age = fract(flameElapsed / 3.88 + hash01(index, 1));
                    const double fade = std::pow(1.0 - age, 1.35);
                    const double distance = 12.0 + age * (215.0 + 100.0 * hash01(index, 10));
                    const double lateral = (hash01(index, 2) - 0.5) * (12.0 + age * 55.0)
                        + std::sin(flameElapsed * 6.8 + index * 1.7) * 4.0;
                    const double x = sourceX + (directionX * distance + perpendicularX * lateral) * gameplayScale;
                    const double y = sourceY + (directionY * distance + perpendicularY * lateral) * gameplayScale;
                    const double radius = 5.0 + 20.0 * fade + 7.0 * hash01(index, 11);
                    queueSoft(x, y, radius * 1.6, radius * 1.12, SDL_FColor{ 1.0f, 97.0f / 255.0f, 9.0f / 255.0f, 1.0f }, 0.27 * fade, true);
                    queueSoft(x, y, radius, radius * 0.74, SDL_FColor{ 1.0f, 201.0f / 255.0f, 54.0f / 255.0f, 1.0f }, 0.47 * fade, true);
                    queueSoft(x, y, radius * 0.48, radius * 0.42, SDL_FColor{ 1.0f, 251.0f / 255.0f, 226.0f / 255.0f, 1.0f }, 0.62 * fade, true);
                }

                constexpr int sparkCount = 28;
                for (int index = 0; index < sparkCount; ++index)
                {
                    const double age = fract(elapsed / 3.89 + hash01(index, 5));
                    const double distance = 12.0 + age * (180.0 + 260.0 * hash01(index, 7));
                    const double lateral = (hash01(index, 6) - 0.5) * (48.0 + age * 220.0);
                    const double gravity = age * age * (18.0 + 42.0 * hash01(index, 12));
                    const double x = sourceX + (directionX * distance + perpendicularX * lateral) * gameplayScale;
                    const double y = sourceY + (directionY * distance + perpendicularY * lateral + gravity) * gameplayScale;
                    const double fade = std::pow(1.0 - age, 1.9);
                    const double radius = 1.3 + (2.0 + 3.0 * hash01(index, 13)) * fade;
                    queueSoft(x, y, radius * 3.8, radius * 3.8, SDL_FColor{ 1.0f, 151.0f / 255.0f, 18.0f / 255.0f, 1.0f }, 0.36 * (0.18 + 0.82 * fade), true);
                    queueSoft(x, y, std::max(0.65, radius * 0.70), std::max(0.65, radius * 0.70), SDL_FColor{ 1.0f, 245.0f / 255.0f, 178.0f / 255.0f, 1.0f }, 0.92 * (0.18 + 0.82 * fade), true);
                }
                batcher.setBlendMode(GpuCanvas2DBlendMode::Alpha);
            }



            void IgnatiusNativeScene::drawDeluxeRocketExhaust(
                float sourceX,
                float sourceY,
                double exhaustAngleRadians,
                double scale,
                double seed)
            {
                if (!deluxeRocketExhaustEnabled())
                {
                    return;
                }
                drawDeluxeRocketExhaustSample(
                    sourceX,
                    sourceY,
                    exhaustAngleRadians,
                    scale,
                    seed,
                    gameState.clock.time,
                    true);
            }



            void IgnatiusNativeScene::drawMountedRocketSmoke(const FRuntimeCharacterDrawPartInfo& partInfo)
            {
                float sourceX = 0.0f;
                float sourceY = 0.0f;
                double exhaustAngleRadians = 0.0;
                double particleScale = 1.0;
                if (!mountedRocketNozzleTransform(partInfo, sourceX, sourceY, exhaustAngleRadians, particleScale))
                {
                    return;
                }

                const double directionX = std::cos(exhaustAngleRadians);
                const double directionY = std::sin(exhaustAngleRadians);
                const double perpendicularX = -directionY;
                const double perpendicularY = directionX;
                const bool gpuSmoke = rawGpuOverlayBatcher != nullptr && sharedSoftParticleTextureGpu != nullptr;
                for (const FSmokePuffState& puff : gameState.effects.smokePuffs)
                {
                    if (puff.kind != "attachedRocketSmokePuff")
                    {
                        continue;
                    }
                    const double lifetime = std::max(0.001, puff.lifetime);
                    const double progress = std::clamp(puff.age / lifetime, 0.0, 1.0);
                    const double localX = puff.x * particleScale;
                    const double localY = puff.y * particleScale;
                    const float centerX = static_cast<float>(sourceX + perpendicularX * localX + directionX * localY);
                    const float centerY = static_cast<float>(sourceY + perpendicularY * localX + directionY * localY);
                    const float radius = static_cast<float>(std::max(1.0, puff.radius) * (0.75 + progress * 1.65) * particleScale);
                    const double smokeAlpha = 0.30 * std::pow(1.0 - progress, 1.25);

                    if (gpuSmoke)
                    {
                        GpuCanvas2D& batcher = *rawGpuOverlayBatcher;
                        batcher.setBlendMode(GpuCanvas2DBlendMode::Alpha);
                        batcher.appendTransformedQuad(
                            sharedSoftParticleTextureGpu,
                            centerX,
                            centerY,
                            radius * 2.0f,
                            radius * 2.0f,
                            0.0f,
                            0.5f,
                            0.5f,
                            0.0f,
                            0.0f,
                            0.0f,
                            1.0f,
                            1.0f,
                            SDL_FLIP_NONE,
                            SDL_FColor{ 207.0f / 255.0f, 198.0f / 255.0f, 218.0f / 255.0f, static_cast<float>(smokeAlpha) });
                    }
                    else
                    {
                        drawSmokeStampApprox(centerX, centerY, radius, smokeAlpha, std::nullopt);
                    }

                    const double sparkFade = std::pow(1.0 - progress, 1.9);
                    if (sparkFade <= 0.025)
                    {
                        continue;
                    }
                    const std::int32_t sparkCount = 1 + static_cast<std::int32_t>(std::floor(2.0 * (1.0 - progress)));
                    for (std::int32_t index = 0; index < sparkCount; ++index)
                    {
                        const double seed = static_cast<double>(puff.sparkleSeed + index * 17);
                        const double angle = projectileTrailHashNoise(seed, index) * std::numbers::pi * 2.0;
                        const double sparkDistance = radius * (0.12 + projectileTrailHashNoise(seed + 31.0, index) * 0.64);
                        const double twinkle = 0.72 + 0.28 * std::sin((gameState.clock.time + puff.age) * 18.0 + static_cast<double>(index) * 1.4);
                        const float sparkRadius = static_cast<float>((0.9 + projectileTrailHashNoise(seed + 79.0, index) * 2.2) * particleScale);
                        const double alpha = std::clamp(0.10 + sparkFade * twinkle * 0.62, 0.0, 0.74);
                        const SDL_Color sparkColor = index % 3 == 0
                            ? SDL_Color{ 204, 157, 255, static_cast<Uint8>(alpha * 255.0) }
                            : SDL_Color{ 255, 238, 129, static_cast<Uint8>(alpha * 255.0) };
                        const float sparkX = centerX + static_cast<float>(std::cos(angle) * sparkDistance);
                        const float sparkY = centerY + static_cast<float>(std::sin(angle) * sparkDistance);
                        if (gpuSmoke)
                        {
                            GpuCanvas2D& batcher = *rawGpuOverlayBatcher;
                            batcher.setBlendMode(GpuCanvas2DBlendMode::AlphaAdditive);
                            batcher.appendTransformedQuad(
                                sharedSoftParticleTextureGpu,
                                sparkX,
                                sparkY,
                                std::max(1.4f, sparkRadius * 2.0f),
                                std::max(1.4f, sparkRadius * 2.0f),
                                0.0f,
                                0.5f,
                                0.5f,
                                0.0f,
                                0.0f,
                                0.0f,
                                1.0f,
                                1.0f,
                                SDL_FLIP_NONE,
                                SDL_FColor{
                                    static_cast<float>(sparkColor.r) / 255.0f,
                                    static_cast<float>(sparkColor.g) / 255.0f,
                                    static_cast<float>(sparkColor.b) / 255.0f,
                                    static_cast<float>(sparkColor.a) / 255.0f });
                        }
                        else
                        {
                            drawSmokeSpark(sparkX, sparkY, std::max(0.7f, sparkRadius), sparkColor);
                        }
                    }
                }
                if (gpuSmoke)
                {
                    // Smoke uses alpha and its sparks use alpha-additive, but neither is allowed
                    // to leak blend state into subsequent wizard rig parts. This matters even
                    // while the rocket is idle because the mounted-smoke callback still runs.
                    rawGpuOverlayBatcher->setBlendMode(GpuCanvas2DBlendMode::Alpha);
                }
            }



            void IgnatiusNativeScene::drawMountedRocketAtlasFlame(const FRuntimeCharacterDrawPartInfo& partInfo)
            {
                if (!mountedRocketExhaustActive() || !animatedRocketFlameAtlasEnabled())
                {
                    return;
                }
                float sourceX = 0.0f;
                float sourceY = 0.0f;
                double exhaustAngleRadians = 0.0;
                double particleScale = 1.0;
                if (!mountedRocketNozzleTransform(partInfo, sourceX, sourceY, exhaustAngleRadians, particleScale))
                {
                    return;
                }
                drawAnimatedRocketFlameAtlas(
                    sourceX,
                    sourceY,
                    exhaustAngleRadians,
                    rocketFlameAtlasTargetHeight(partInfo.targetHeight),
                    41.0);
            }



            void IgnatiusNativeScene::drawMountedRocketDeluxeExhaust(const FRuntimeCharacterDrawPartInfo& partInfo)
            {
                if (!mountedRocketExhaustActive() || !deluxeRocketExhaustEnabled())
                {
                    return;
                }
                float sourceX = 0.0f;
                float sourceY = 0.0f;
                double exhaustAngleRadians = 0.0;
                double particleScale = 1.0;
                if (!mountedRocketNozzleTransform(partInfo, sourceX, sourceY, exhaustAngleRadians, particleScale))
                {
                    return;
                }
                drawDeluxeRocketExhaust(
                    sourceX,
                    sourceY,
                    exhaustAngleRadians,
                    std::max(0.035, partInfo.targetHeight / DELUXE_ROCKET_EXHAUST_REFERENCE_HEIGHT),
                    41.0);
            }



            void IgnatiusNativeScene::drawFuelBulbDepletionMask(float centerX, float centerY, float radius, double ratio)
            {
                const double clampedRatio = std::clamp(ratio, 0.0, 1.0);
                if (!(clampedRatio > 0.0) || !(clampedRatio < 1.0) || !(radius > 0.0f))
                {
                    return;
                }

                const float cutY = -radius + radius * 2.0f * static_cast<float>(1.0 - clampedRatio);
                const int minY = static_cast<int>(std::floor(-radius));
                const int maxY = static_cast<int>(std::ceil(std::min(radius, cutY)));
                for (int y = minY; y <= maxY; ++y)
                {
                    const float yValue = static_cast<float>(y);
                    const float remaining = std::max(0.0f, radius * radius - yValue * yValue);
                    const float halfWidth = std::sqrt(remaining);
                    drawLineSegment(
                        centerX - halfWidth,
                        centerY + yValue,
                        centerX + halfWidth,
                        centerY + yValue,
                        1.0f,
                        SDL_Color{ 0, 0, 0, 66 });
                }
            }



            void IgnatiusNativeScene::drawMountedRocketFuelBulb(const FRuntimeCharacterDrawPartInfo& partInfo)
            {
                if (gameState.tuning.rocketFuelBulbEnabled == false || gameState.player.visible == false)
                {
                    return;
                }
                if (partInfo.partName != "rocket" || !partInfo.asset)
                {
                    return;
                }
                const auto pivotIt = playerProject.rig.pivots.find("rocket");
                if (pivotIt == playerProject.rig.pivots.end())
                {
                    return;
                }

                const FNativeAtlasFrameAsset& asset = *partInfo.asset;
                const FRigPoint& pivot = pivotIt->second;
                const double spriteScale = std::max(0.0001, partInfo.spriteScale);
                const float pivotScreenX = partInfo.placement.destination.x + partInfo.placement.rotationCenter.x;
                const float pivotScreenY = partInfo.placement.destination.y + partInfo.placement.rotationCenter.y;
                const float facingSign = partInfo.placement.flip == SDL_FLIP_HORIZONTAL ? -1.0f : 1.0f;
                const float localX = static_cast<float>((0.46 - pivot.x) * static_cast<double>(asset.w) * spriteScale) * facingSign;
                const float localY = static_cast<float>((0.47 - pivot.y) * static_cast<double>(asset.h) * spriteScale);
                const SDL_FPoint rotated = rotateScreenOffset(localX, localY, partInfo.placement.rotationDegrees);
                const float centerX = pivotScreenX + rotated.x;
                const float centerY = pivotScreenY + rotated.y;

                const double maxFuel = std::max(1.0, gameState.fuel.max);
                const double ratio = std::clamp(gameState.fuel.amount / maxFuel, 0.0, 1.0);
                const double percent = ratio * 100.0;
                const double low = gameState.tuning.rocketFuelBulbLowThreshold;
                const double mid = gameState.tuning.rocketFuelBulbMediumThreshold;
                const float radius = static_cast<float>(std::max(5.0, static_cast<double>(std::min(asset.w, asset.h)) * 0.055 * std::max(0.0, gameState.tuning.rocketFuelBulbScale)) * spriteScale);
                if (!(radius > 0.0f))
                {
                    return;
                }

                const bool passivePowerUpRecovering =
                    activePowerUpEffect(gameState.statusEffects.active, POWER_UP_EFFECT_IDS::FLIGHT).has_value()
                    && gameState.fuel.amount < gameState.fuel.max;
                const bool canRechargeNow = !gameState.tuning.fuelRechargeRequiresGround || gameState.player.onGround || gameState.fuel.rechargeLatched;
                const bool recharging = gameState.tuning.rocketFuelBulbPulseWhenRecharging
                    && (passivePowerUpRecovering
                        || (!gameState.equipment.rocket.attachedBoosting
                            && canRechargeNow
                            && gameState.fuel.rechargeDelayTimer <= 0.0
                            && gameState.fuel.amount < std::min(gameState.fuel.rechargeCap, gameState.fuel.max)));
                const bool unavailable = !passivePowerUpRecovering
                    && ((gameState.tuning.fuelRechargeRequiresGround && !gameState.player.onGround && !gameState.fuel.rechargeLatched)
                        || gameState.fuel.rechargeDelayTimer > 0.0);
                const double flash = std::clamp(gameState.equipment.rocket.fuelBulbFlashTimer / 0.45, 0.0, 1.0);
                const double pulse = recharging ? 0.5 + 0.5 * std::sin(gameState.clock.time * 13.5) : 0.0;
                const double dim = unavailable && !recharging ? 0.62 : 1.0;

                SDL_Color fill{ 18, 16, 20, 224 };
                SDL_Color glow{ 0, 0, 0, 0 };
                if (percent > 0.5 && percent < low)
                {
                    fill = SDL_Color{ 220, 59, 58, 242 };
                    glow = SDL_Color{ 255, 67, 53, 115 };
                }
                else if (percent >= low && percent < mid)
                {
                    fill = SDL_Color{ 239, 198, 71, 245 };
                    glow = SDL_Color{ 255, 217, 75, 107 };
                }
                else if (percent >= mid)
                {
                    fill = SDL_Color{ 103, 218, 117, 245 };
                    glow = SDL_Color{ 100, 244, 126, 107 };
                }

                if (percent > 0.5)
                {
                    const float glowRadius = radius * static_cast<float>(2.2 + pulse * 0.75 + flash * 1.8);
                    drawFilledCircle(centerX, centerY, glowRadius, scaledAlpha(glow, dim * (0.38 + pulse * 0.18 + flash * 0.24)));
                }

                drawFilledCircle(centerX, centerY, radius * 1.28f, SDL_Color{ 5, 4, 7, 192 });
                drawFilledCircle(centerX, centerY, radius, scaledAlpha(fill, dim));
                drawFuelBulbDepletionMask(centerX, centerY, radius, ratio);

                const SDL_Color ring = flash > 0.01
                    ? SDL_Color{ 255, 255, 210, 250 }
                    : (unavailable ? SDL_Color{ 255, 255, 255, 82 } : SDL_Color{ 255, 255, 255, 168 });
                drawRing(
                    centerX,
                    centerY,
                    radius * static_cast<float>(1.06 + flash * 0.35),
                    std::max(1.25f, radius * 0.18f),
                    SDL_Color{ ring.r, ring.g, ring.b, static_cast<Uint8>(std::clamp(0.88 * static_cast<double>(ring.a), 0.0, 255.0)) });
                drawFilledCircle(
                    centerX - radius * 0.28f,
                    centerY - radius * 0.32f,
                    std::max(0.8f, radius * 0.23f),
                    SDL_Color{ 255, 255, 255, 146 });

                if (percent <= 0.5)
                {
                    const Uint8 slashAlpha = static_cast<Uint8>(std::clamp(0.42 + 0.22 * std::sin(gameState.clock.time * 10.0), 0.0, 1.0) * 194.0);
                    drawLineSegment(
                        centerX - radius * 0.55f,
                        centerY + radius * 0.52f,
                        centerX + radius * 0.55f,
                        centerY - radius * 0.52f,
                        std::max(1.0f, radius * 0.12f),
                        SDL_Color{ 255, 80, 62, slashAlpha });
                }
            }



            const FNativeAtlasFrameAsset* IgnatiusNativeScene::findLoadedCharacterFrame(
                const std::string& characterId,
                const std::string& frameId,
                const std::string& partName) const
            {
                const FRuntimeCharacterProject* project = findLoadedCharacterProject(characterId);
                if (!project)
                {
                    return nullptr;
                }

                if (!partName.empty())
                {
                    const auto partIt = project->assets.find(partName);
                    if (partIt != project->assets.end())
                    {
                        return &partIt->second;
                    }
                }

                if (!frameId.empty())
                {
                    const auto primaryIt = project->primaryAtlas.frames.find(frameId);
                    if (primaryIt != project->primaryAtlas.frames.end())
                    {
                        return &primaryIt->second;
                    }
                    for (const FNativeAtlas& atlas : project->supplementalAtlases)
                    {
                        const auto frameIt = atlas.frames.find(frameId);
                        if (frameIt != atlas.frames.end())
                        {
                            return &frameIt->second;
                        }
                    }
                }

                return nullptr;
            }



            const FNativeAtlasFrameAsset* IgnatiusNativeScene::findProjectileFrameAsset(
                const FProjectileState& projectile,
                const std::string& fallbackCharacterId,
                const std::string& fallbackFrameId) const
            {
                const std::string characterId = projectile.characterId.empty() ? fallbackCharacterId : projectile.characterId;
                const std::string frameId = projectile.frameId.empty() ? fallbackFrameId : projectile.frameId;
                const FNativeAtlasFrameAsset* asset = findLoadedCharacterFrame(
                    characterId,
                    frameId,
                    projectile.projectilePartName);
                return asset ? asset : findLoadedCharacterFrame(fallbackCharacterId, fallbackFrameId);
            }



            SDL_Color IgnatiusNativeScene::projectileTrailColorAtHeat(const FProjectileTrailPalette& palette, double heat)
            {
                const double scaled = std::clamp(heat, 0.0, 1.0) * static_cast<double>(palette.colors.size() - 1u);
                const std::size_t lowerIndex = std::min<std::size_t>(palette.colors.size() - 1u, static_cast<std::size_t>(std::floor(scaled)));
                const std::size_t upperIndex = std::min<std::size_t>(palette.colors.size() - 1u, lowerIndex + 1u);
                const double blend = scaled - static_cast<double>(lowerIndex);
                const SDL_Color& lower = palette.colors[lowerIndex];
                const SDL_Color& upper = palette.colors[upperIndex];
                const auto channel = [blend](Uint8 from, Uint8 to)
                {
                    return static_cast<Uint8>(std::clamp(
                        std::lround(static_cast<double>(from) + (static_cast<double>(to) - static_cast<double>(from)) * blend),
                        0l,
                        255l));
                };
                return SDL_Color{
                    channel(lower.r, upper.r),
                    channel(lower.g, upper.g),
                    channel(lower.b, upper.b),
                    255u
                };
            }



            bool IgnatiusNativeScene::drawAtlasFrameRect(
                const FNativeAtlasFrameAsset* asset,
                const SDL_FRect& destination,
                SDL_Color color)
            {
                if (!asset || !(destination.w > 0.0f) || !(destination.h > 0.0f) || color.a == 0)
                {
                    return false;
                }

                const SDL_FRect source{
                    static_cast<float>(asset->x),
                    static_cast<float>(asset->y),
                    static_cast<float>(asset->w),
                    static_cast<float>(asset->h)
                };
                const float textureWidth = static_cast<float>(std::max(1, asset->textureWidth));
                const float textureHeight = static_cast<float>(std::max(1, asset->textureHeight));
                const float u0 = source.x / textureWidth;
                const float v0 = source.y / textureHeight;
                const float u1 = (source.x + source.w) / textureWidth;
                const float v1 = (source.y + source.h) / textureHeight;
                const SDL_FColor fColor{
                    static_cast<float>(color.r) / 255.0f,
                    static_cast<float>(color.g) / 255.0f,
                    static_cast<float>(color.b) / 255.0f,
                    static_cast<float>(color.a) / 255.0f
                };

                if (rawGpuOverlayBatcher && asset->gpuTexture)
                {
                    if (rawGpuOverlayBatcher->appendQuad(
                            asset->gpuTexture,
                            destination.x,
                            destination.y,
                            destination.w,
                            destination.h,
                            0.0f,
                            u0,
                            v0,
                            u1,
                            v1,
                            fColor))
                    {
                        return true;
                    }
                }

                if (!renderer || !asset->texture)
                {
                    return false;
                }

                SDL_SetTextureColorModFloat(asset->texture, fColor.r, fColor.g, fColor.b);
                SDL_SetTextureAlphaModFloat(asset->texture, fColor.a);
                SDL_RenderTexture(renderer, asset->texture, &source, &destination);
                SDL_SetTextureAlphaModFloat(asset->texture, 1.0f);
                SDL_SetTextureColorModFloat(asset->texture, 1.0f, 1.0f, 1.0f);
                return true;
            }



            bool IgnatiusNativeScene::drawAtlasFrameCentered(
                const FNativeAtlasFrameAsset* asset,
                float centerX,
                float centerY,
                float targetHeight,
                double rotationRadians,
                float pivotX,
                float pivotY,
                double alpha,
                SDL_FlipMode flip)
            {
                if (!asset || !(targetHeight > 0.0f))
                {
                    return false;
                }

                const float scale = targetHeight / static_cast<float>(std::max(1, asset->h));
                const float drawWidth = static_cast<float>(asset->w) * scale;
                const float drawHeight = static_cast<float>(asset->h) * scale;
                const SDL_FRect source{
                    static_cast<float>(asset->x),
                    static_cast<float>(asset->y),
                    static_cast<float>(asset->w),
                    static_cast<float>(asset->h)
                };
                const SDL_FPoint rotationCenter{
                    drawWidth * pivotX,
                    drawHeight * pivotY
                };
                const SDL_FRect destination{
                    centerX - rotationCenter.x,
                    centerY - rotationCenter.y,
                    drawWidth,
                    drawHeight
                };
                const SDL_FColor color{ 1.0f, 1.0f, 1.0f, static_cast<float>(std::clamp(alpha, 0.0, 1.0)) };
                const float textureWidth = static_cast<float>(std::max(1, asset->textureWidth));
                const float textureHeight = static_cast<float>(std::max(1, asset->textureHeight));
                const float u0 = source.x / textureWidth;
                const float v0 = source.y / textureHeight;
                const float u1 = (source.x + source.w) / textureWidth;
                const float v1 = (source.y + source.h) / textureHeight;

                if (rawGpuOverlayBatcher && asset->gpuTexture)
                {
                    if (rawGpuOverlayBatcher->appendTransformedQuad(
                            asset->gpuTexture,
                            centerX,
                            centerY,
                            drawWidth,
                            drawHeight,
                            static_cast<float>(rotationRadians * 180.0 / std::numbers::pi),
                            pivotX,
                            pivotY,
                            0.0f,
                            u0,
                            v0,
                            u1,
                            v1,
                            flip,
                            color))
                    {
                        return true;
                    }
                }

                if (!renderer || !asset->texture)
                {
                    return false;
                }

                if (!renderTexturedQuadGeometry(
                        renderer,
                        asset->texture,
                        static_cast<int>(std::lround(textureWidth)),
                        static_cast<int>(std::lround(textureHeight)),
                        source,
                        destination,
                        rotationRadians * 180.0 / std::numbers::pi,
                        rotationCenter,
                        flip,
                        color))
                {
                    SDL_SetTextureAlphaModFloat(asset->texture, color.a);
                    SDL_RenderTextureRotated(
                        renderer,
                        asset->texture,
                        &source,
                        &destination,
                        rotationRadians * 180.0 / std::numbers::pi,
                        &rotationCenter,
                        flip);
                    SDL_SetTextureAlphaModFloat(asset->texture, 1.0f);
                }
                return true;
            }



            void IgnatiusNativeScene::drawTargetMarkers(const NativeRenderView& view)
            {
                for (const FTargetState& target : gameState.targets)
                {
                    if (!target.targetable || !target.showMarker || target.state != "active" || !worldPointVisible(view, target.x, target.y))
                    {
                        continue;
                    }
                    const SDL_FPoint screen = worldToScreen(view, target.x, target.y);
                    const float pulse = static_cast<float>(0.86 + 0.14 * std::sin(gameState.clock.time * 5.0 + target.x * 0.01));
                    const float radius = static_cast<float>(std::max(12.0, target.radius) * view.zoom * pulse);
                    drawRing(screen.x, screen.y, radius, std::max(1.0f, static_cast<float>(2.0 * view.zoom)), SDL_Color{ 255, 217, 93, 205 });
                    const float cross = std::max(4.0f, radius * 0.35f);
                    drawLineSegment(screen.x - cross, screen.y, screen.x + cross, screen.y, std::max(1.0f, static_cast<float>(2.0 * view.zoom)), SDL_Color{ 255, 240, 178, 180 });
                    drawLineSegment(screen.x, screen.y - cross, screen.x, screen.y + cross, std::max(1.0f, static_cast<float>(2.0 * view.zoom)), SDL_Color{ 255, 240, 178, 180 });
                }
            }



            bool IgnatiusNativeScene::drawPowerUpCompositeNative(
                const FPowerUpPickupState& powerUp,
                float centerX,
                float centerY,
                float size,
                double time,
                double alpha)
            {
                const std::string atlasId = powerUp.atlasId.empty() ? std::string("it_atlas_001") : powerUp.atlasId;
                const auto atlasIt = environmentAtlases.find(atlasId);
                if (atlasIt == environmentAtlases.end())
                {
                    return false;
                }

                const FNativeAtlas& atlas = atlasIt->second;
                const std::string glowFrameName = powerUp.glowFrame.empty() ? std::string("powerup_glow_white") : powerUp.glowFrame;
                const std::string iconFrameName = powerUp.iconFrame.empty() ? std::string("powerup_icon_lightning") : powerUp.iconFrame;
                const auto glowFrameIt = atlas.frames.find(glowFrameName);
                const auto iconFrameIt = atlas.frames.find(iconFrameName);
                if (glowFrameIt == atlas.frames.end() || iconFrameIt == atlas.frames.end())
                {
                    return false;
                }

                const std::string effectId = powerUp.effectId;
                const bool isWrench = effectId.rfind("wrench", 0) == 0;
                const int glowPasses = isWrench ? 3 : 1;
                const float glowScale = effectId == "overdrive" ? 0.70f : 1.16f;
                const float pulse = static_cast<float>(0.92 + std::sin(time * 5.4) * 0.08);
                const float drawSize = std::max(1.0f, size * pulse);
                const SDL_Color tint = parseHexColor(powerUp.glowTint.empty() ? std::string("#ffb52f") : powerUp.glowTint, 235)
                    .value_or(SDL_Color{ 255, 181, 47, 235 });
                const double clampedAlpha = std::clamp(alpha, 0.0, 1.0);

                const SDL_FRect glowRect{
                    centerX - drawSize * glowScale * 0.5f,
                    centerY - drawSize * glowScale * 0.5f,
                    drawSize * glowScale,
                    drawSize * glowScale
                };
                const SDL_Color glowColor = scaledAlpha(tint, 0.92 * clampedAlpha);
                for (int pass = 0; pass < glowPasses; ++pass)
                {
                    drawAtlasFrameRect(&glowFrameIt->second, glowRect, glowColor);
                }

                const FNativeAtlasFrameAsset& iconFrame = iconFrameIt->second;
                const float iconSize = drawSize * 0.47f;
                const float iconAspect = static_cast<float>(iconFrame.w) / std::max(1.0f, static_cast<float>(iconFrame.h));
                const float iconW = iconAspect >= 1.0f ? iconSize : iconSize * iconAspect;
                const float iconH = iconAspect >= 1.0f ? iconSize / std::max(0.0001f, iconAspect) : iconSize;
                const SDL_FRect iconRect{
                    centerX - iconW * 0.5f,
                    centerY - iconH * 0.5f,
                    iconW,
                    iconH
                };
                drawAtlasFrameRect(&iconFrame, iconRect, SDL_Color{ 255, 255, 255, static_cast<Uint8>(std::clamp(clampedAlpha * 255.0, 0.0, 255.0)) });
                return true;
            }



            bool IgnatiusNativeScene::pickupRendersInFrontOfEnemies(const FPickupState& pickup)
            {
                return pickup.dropped;
            }



            void IgnatiusNativeScene::drawProceduralPickups(const NativeRenderView& view, bool frontLayer)
            {
                for (const FPickupState& pickup : gameState.pickups)
                {
                    if (pickup.visualized || pickup.collected || !worldPointVisible(view, pickup.x, pickup.centerY)
                        || pickupRendersInFrontOfEnemies(pickup) != frontLayer)
                    {
                        continue;
                    }

                    const bool powerUp = pickup.kind == "powerUp" && pickup.powerUp.has_value();
                    const float pickupScale = powerUp
                        ? static_cast<float>(std::max(0.1, pickup.powerUp->worldScale))
                        : 1.0f;
                    const float bob = (powerUp || pickup.bob)
                        ? static_cast<float>(std::sin(gameState.clock.time * 2.8 + pickup.x * 0.01) * 7.0 * view.zoom)
                        : 0.0f;
                    const SDL_FPoint screen = worldToScreen(view, pickup.x, pickup.centerY);
                    const float radius = static_cast<float>(std::max(8.0, pickup.radius) * view.zoom);
                    if (powerUp)
                    {
                        const float size = std::max(static_cast<float>(44.0 * view.zoom), radius * 2.25f) * pickupScale;
                        if (drawPowerUpCompositeNative(*pickup.powerUp, screen.x, screen.y + bob, size, gameState.clock.time))
                        {
                            continue;
                        }
                    }
                    if (!pickup.assetId.empty())
                    {
                        const std::string atlasId = pickup.atlasId.empty() ? std::string("it_atlas_001") : pickup.atlasId;
                        const auto atlasIt = environmentAtlases.find(atlasId);
                        if (atlasIt != environmentAtlases.end())
                        {
                            const auto frameIt = atlasIt->second.frames.find(pickup.assetId);
                            if (frameIt != atlasIt->second.frames.end())
                            {
                                const SDL_FRect destination{
                                    screen.x - static_cast<float>(pickup.width * view.zoom * 0.5),
                                    screen.y + bob - static_cast<float>(pickup.height * view.zoom * 0.5),
                                    static_cast<float>(pickup.width * view.zoom),
                                    static_cast<float>(pickup.height * view.zoom)
                                };
                                drawAtlasFrameRect(&frameIt->second, destination, SDL_Color{ 255, 255, 255, 255 });
                                continue;
                            }
                        }
                    }

                    const double discPulse = 0.82 + 0.18 * std::sin(gameState.clock.time * 5.0 + pickup.x);
                    SDL_Color glow{ 205, 122, 232, static_cast<Uint8>(std::clamp(80.0 * discPulse, 0.0, 255.0)) };
                    SDL_Color core{ 255, 189, 74, 235 };
                    if (pickup.pickupKind == "shield")
                    {
                        glow = { 45, 150, 255, static_cast<Uint8>(std::clamp(84.0 * discPulse, 0.0, 255.0)) };
                        core = { 130, 215, 255, 240 };
                    }
                    else if (pickup.pickupKind == "overdrive")
                    {
                        glow = { 255, 91, 74, static_cast<Uint8>(std::clamp(90.0 * discPulse, 0.0, 255.0)) };
                        core = { 255, 205, 88, 245 };
                    }
                    drawFilledCircle(screen.x, screen.y + bob, radius * 1.55f, glow);
                    drawFilledCircle(screen.x, screen.y + bob, radius * 0.72f, core);
                    drawRing(screen.x, screen.y + bob, radius, std::max(1.0f, static_cast<float>(2.0 * view.zoom)), SDL_Color{ 255, 255, 255, 190 });
                }
            }



            void IgnatiusNativeScene::drawReactiveObjects(const NativeRenderView& view)
            {
                for (const FReactiveObjectState& object : gameState.reactiveObjects)
                {
                    if (object.visualized || object.state == object.destroyedState || !worldPointVisible(view, object.x, object.y))
                    {
                        continue;
                    }
                    const SDL_FPoint topLeft = worldToScreen(view, object.x - object.width * 0.5, object.y - object.height);
                    SDL_FRect rect{
                        topLeft.x,
                        topLeft.y,
                        static_cast<float>(object.width * view.zoom),
                        static_cast<float>(object.height * view.zoom)
                    };
                    const double healthRatio = object.maxHealth > 0.0 ? std::clamp(object.health / object.maxHealth, 0.0, 1.0) : 1.0;
                    drawTextureRect(canvasWhiteTexture, canvasWhiteTextureGpu, rect.x, rect.y, rect.w, rect.h, SDL_Color{ 102, 73, 54, 220 });
                    const SDL_Color border{
                        238,
                        196,
                        112,
                        static_cast<Uint8>(120.0 + healthRatio * 100.0)
                    };
                    drawLineSegment(rect.x, rect.y, rect.x + rect.w, rect.y, 1.0f, border);
                    drawLineSegment(rect.x + rect.w, rect.y, rect.x + rect.w, rect.y + rect.h, 1.0f, border);
                    drawLineSegment(rect.x + rect.w, rect.y + rect.h, rect.x, rect.y + rect.h, 1.0f, border);
                    drawLineSegment(rect.x, rect.y + rect.h, rect.x, rect.y, 1.0f, border);
                }
            }



            void IgnatiusNativeScene::drawSmokeStampApprox(float centerX, float centerY, float radius, double alpha, std::optional<SDL_Color> tint)
            {
                if (!(radius > 0.0f) || !(alpha > 0.0))
                {
                    return;
                }

                // Canvas reference uses a cached radial smoke stamp: tinted low-alpha core,
                // a pale lavender body, a purple-grey shoulder, and a transparent edge.
                // Layered circles give the SDL renderer the same soft-edged mass without
                // introducing another generated texture path.
                drawFilledCircle(centerX, centerY, radius, SDL_Color{ 92, 84, 112, static_cast<Uint8>(std::clamp(alpha * 18.0, 0.0, 255.0)) });
                drawFilledCircle(centerX, centerY, radius * 0.76f, SDL_Color{ 155, 145, 170, static_cast<Uint8>(std::clamp(alpha * 122.0, 0.0, 255.0)) });
                drawFilledCircle(centerX, centerY, radius * 0.56f, SDL_Color{ 207, 198, 218, static_cast<Uint8>(std::clamp(alpha * 224.0, 0.0, 255.0)) });
                if (tint.has_value())
                {
                    SDL_Color tinted = *tint;
                    tinted.a = static_cast<Uint8>(std::clamp(alpha * 87.0, 0.0, 255.0));
                    drawFilledCircle(centerX, centerY, radius * 0.34f, tinted);
                }
            }



            void IgnatiusNativeScene::drawSmokeSpark(float centerX, float centerY, float radius, SDL_Color color)
            {
                drawFilledCircle(centerX, centerY, radius * 1.55f, scaledAlpha(color, 0.18));
                drawFilledCircle(centerX, centerY, radius, color);
            }



            void IgnatiusNativeScene::drawSmokePuffs(const NativeRenderView& view)
            {
                for (const FSmokePuffState& puff : gameState.effects.smokePuffs)
                {
                    if (puff.kind == "attachedRocketSmokePuff")
                    {
                        continue;
                    }
                    // Cover sparks are composited after the still-visible wizard so
                    // they progressively hide the rig before the outward burst.
                    if (puff.kind == "wizardDeathCoverSpark")
                    {
                        continue;
                    }

                    const double lifetime = std::max(0.001, puff.lifetime);
                    const double progress = std::clamp(puff.age / lifetime, 0.0, 1.0);
                    const double radiusWorld = std::max(1.0, puff.radius) * (0.75 + progress * 1.65);
                    if (!worldPointVisible(view, puff.x, puff.y, radiusWorld * view.zoom + 64.0))
                    {
                        continue;
                    }

                    const SDL_FPoint screen = worldToScreen(view, puff.x, puff.y);
                    const float radius = static_cast<float>(radiusWorld * view.zoom);

                    if (puff.kind == "enemyProjectileImpactPuff")
                    {
                        const double fade = std::pow(1.0 - progress, 1.35);
                        const float darkRadius = radius * static_cast<float>(0.82 + progress * 0.28);
                        drawFilledCircle(screen.x, screen.y, darkRadius, SDL_Color{ 20, 17, 24, static_cast<Uint8>(std::clamp(fade * 32.0, 0.0, 255.0)) });
                        drawFilledCircle(screen.x, screen.y, darkRadius * 0.74f, SDL_Color{ 48, 37, 45, static_cast<Uint8>(std::clamp(fade * 107.0, 0.0, 255.0)) });
                        drawFilledCircle(screen.x, screen.y, darkRadius * 0.42f, SDL_Color{ 82, 51, 58, static_cast<Uint8>(std::clamp(fade * 128.0, 0.0, 255.0)) });
                        continue;
                    }

                    if (puff.kind == "wizardDeathBurstParticle" || puff.kind == "wizardCrushParticle" || puff.kind == "smokeParticle")
                    {
                        const bool smokeParticle = puff.kind == "smokeParticle";
                        const double fade = std::pow(1.0 - progress, smokeParticle ? 1.55 : 1.35);
                        const float shardRadius = static_cast<float>(std::max(1.0, puff.radius) * view.zoom * (0.9 + (1.0 - progress) * 0.1));
                        const std::int32_t paletteIndex = smokeParticle
                            ? ((puff.colorIndex % 4) + 4) % 4
                            : ((puff.colorIndex % 3) + 3) % 3;
                        const SDL_Color color = smokeParticle
                            ? (paletteIndex == 0
                                ? SDL_Color{ 196, 196, 196, static_cast<Uint8>(std::clamp(0.90 * fade * 255.0, 0.0, 255.0)) }
                                : (paletteIndex == 1
                                    ? SDL_Color{ 164, 164, 164, static_cast<Uint8>(std::clamp(0.90 * fade * 255.0, 0.0, 255.0)) }
                                    : (paletteIndex == 2
                                        ? SDL_Color{ 136, 136, 136, static_cast<Uint8>(std::clamp(0.90 * fade * 255.0, 0.0, 255.0)) }
                                        : SDL_Color{ 106, 106, 106, static_cast<Uint8>(std::clamp(0.90 * fade * 255.0, 0.0, 255.0)) })))
                            : (paletteIndex == 0
                                ? SDL_Color{ 161, 72, 255, static_cast<Uint8>(std::clamp(0.94 * fade * 255.0, 0.0, 255.0)) }
                                : (paletteIndex == 1
                                    ? SDL_Color{ 255, 220, 65, static_cast<Uint8>(std::clamp(0.97 * fade * 255.0, 0.0, 255.0)) }
                                    : SDL_Color{ 255, 255, 246, static_cast<Uint8>(std::clamp(0.98 * fade * 255.0, 0.0, 255.0)) }));
                        drawFilledCircle(screen.x, screen.y, shardRadius * 1.8f, scaledAlpha(color, smokeParticle ? 0.22 : 0.58));
                        const float cosine = static_cast<float>(std::cos(puff.rotation));
                        const float sine = static_cast<float>(std::sin(puff.rotation));
                        const auto rotatedPoint = [&](float localX, float localY)
                        {
                            return SDL_FPoint{
                                screen.x + localX * cosine - localY * sine,
                                screen.y + localX * sine + localY * cosine
                            };
                        };
                        const SDL_FPoint top = rotatedPoint(0.0f, -shardRadius * 1.45f);
                        const SDL_FPoint right = rotatedPoint(shardRadius * 0.76f, 0.0f);
                        const SDL_FPoint bottom = rotatedPoint(0.0f, shardRadius * 1.45f);
                        const SDL_FPoint left = rotatedPoint(-shardRadius * 0.76f, 0.0f);
                        drawLineSegment(top.x, top.y, right.x, right.y, shardRadius * 0.9f, color);
                        drawLineSegment(right.x, right.y, bottom.x, bottom.y, shardRadius * 0.9f, color);
                        drawLineSegment(bottom.x, bottom.y, left.x, left.y, shardRadius * 0.9f, color);
                        drawLineSegment(left.x, left.y, top.x, top.y, shardRadius * 0.9f, color);
                        continue;
                    }

                    if (puff.kind == "enemyTeleportFlash")
                    {
                        const double fade = std::pow(1.0 - progress, 1.45);
                        const float flashRadius = static_cast<float>(std::max(2.0, puff.radius) * view.zoom * (0.34 + progress * 0.92));
                        drawFilledCircle(screen.x, screen.y, flashRadius, SDL_Color{ 90, 34, 180, static_cast<Uint8>(std::clamp(0.10 * fade * 255.0, 0.0, 255.0)) });
                        drawFilledCircle(screen.x, screen.y, flashRadius * 0.58f, SDL_Color{ 163, 88, 255, static_cast<Uint8>(std::clamp(0.52 * fade * 255.0, 0.0, 255.0)) });
                        drawFilledCircle(screen.x, screen.y, flashRadius * 0.24f, SDL_Color{ 124, 236, 255, static_cast<Uint8>(std::clamp(0.74 * fade * 255.0, 0.0, 255.0)) });
                        drawRing(screen.x, screen.y, flashRadius * 0.78f, std::max(1.0f, static_cast<float>(2.4 * view.zoom * (1.0 - progress * 0.45))), SDL_Color{ 202, 142, 255, static_cast<Uint8>(std::clamp(0.90 * fade * 255.0, 0.0, 255.0)) });
                        continue;
                    }

                    if (puff.kind == "enemyTeleportSpark")
                    {
                        const double fade = std::pow(1.0 - progress, 1.2);
                        const float shardRadius = static_cast<float>(std::max(1.0, puff.radius) * view.zoom);
                        const std::int32_t paletteIndex = ((puff.colorIndex % 3) + 3) % 3;
                        const SDL_Color color = paletteIndex == 0
                            ? SDL_Color{ 255, 255, 255, static_cast<Uint8>(std::clamp(0.98 * fade * 255.0, 0.0, 255.0)) }
                            : (paletteIndex == 1
                                ? SDL_Color{ 116, 235, 255, static_cast<Uint8>(std::clamp(0.94 * fade * 255.0, 0.0, 255.0)) }
                                : SDL_Color{ 190, 104, 255, static_cast<Uint8>(std::clamp(0.94 * fade * 255.0, 0.0, 255.0)) });
                        drawLineSegment(screen.x, screen.y - shardRadius * 1.7f, screen.x, screen.y + shardRadius * 1.7f, std::max(1.0f, shardRadius * 0.8f), color);
                        drawLineSegment(screen.x - shardRadius * 0.72f, screen.y, screen.x + shardRadius * 0.72f, screen.y, std::max(1.0f, shardRadius * 0.8f), color);
                        continue;
                    }

                    const double smokeAlpha = 0.30 * std::pow(1.0 - progress, 1.25);
                    const std::optional<SDL_Color> trailTint = (puff.kind == "rocketSmokePuff" && !puff.trailTint.empty())
                        ? parseHexColor(puff.trailTint, 255)
                        : std::optional<SDL_Color>{};
                    drawSmokeStampApprox(screen.x, screen.y, radius, smokeAlpha, trailTint);

                    const double sparkFade = std::pow(1.0 - progress, 1.9);
                    const std::int32_t sparkMax = puff.kind == "rocketSmokePuff" ? 3 : (puff.kind == "attachedRocketSmokePuff" ? 2 : 0);
                    if (sparkMax > 0 && sparkFade > 0.025)
                    {
                        const std::int32_t sparkCount = 1 + static_cast<std::int32_t>(std::floor(static_cast<double>(sparkMax) * (1.0 - progress)));
                        for (std::int32_t index = 0; index < sparkCount; ++index)
                        {
                            const double seed = static_cast<double>(puff.sparkleSeed + index * 17);
                            const double angle = projectileTrailHashNoise(seed, index) * std::numbers::pi * 2.0;
                            const double sparkDistance = radius * (0.12 + projectileTrailHashNoise(seed + 31.0, index) * 0.64);
                            const double twinkle = 0.72 + 0.28 * std::sin((gameState.clock.time + puff.age) * 18.0 + static_cast<double>(index) * 1.4);
                            const float sparkRadius = static_cast<float>((0.9 + projectileTrailHashNoise(seed + 79.0, index) * 2.2) * view.zoom);
                            const Uint8 alpha = static_cast<Uint8>(std::clamp((0.10 + sparkFade * twinkle * 0.62) * 255.0, 0.0, 189.0));
                            SDL_Color sparkColor = index % 3 == 0
                                ? SDL_Color{ 204, 157, 255, alpha }
                                : SDL_Color{ 255, 238, 129, alpha };
                            if (trailTint.has_value() && index % 3 == 0)
                            {
                                sparkColor = *trailTint;
                                sparkColor.a = alpha;
                            }
                            drawSmokeSpark(
                                screen.x + static_cast<float>(std::cos(angle) * sparkDistance),
                                screen.y + static_cast<float>(std::sin(angle) * sparkDistance),
                                std::max(0.7f, sparkRadius),
                                sparkColor);
                        }
                    }
                }
            }



            void IgnatiusNativeScene::drawPlayerDeathCover(const NativeRenderView& view)
            {
                if (gameState.player.deathPhase != "cover")
                {
                    return;
                }

                for (const FSmokePuffState& spark : gameState.effects.smokePuffs)
                {
                    if (spark.kind != "wizardDeathCoverSpark")
                    {
                        continue;
                    }

                    const double delay = std::max(0.0, spark.delay);
                    if (spark.age < delay)
                    {
                        continue;
                    }

                    const double localAge = std::max(0.0, spark.age - delay);
                    const double ramp = std::clamp(localAge / 0.075, 0.0, 1.0);
                    const double twinkle = 0.7 + 0.3 * std::sin(localAge * 36.0 + static_cast<double>(spark.sparkleSeed) * 0.17);
                    const double alpha = ramp * twinkle;
                    const double radiusWorld = std::max(1.0, spark.radius) * 2.1;
                    if (!worldPointVisible(view, spark.x, spark.y, radiusWorld * view.zoom + 48.0))
                    {
                        continue;
                    }

                    const SDL_FPoint point = worldToScreen(view, spark.x, spark.y);
                    const float radius = static_cast<float>(std::max(1.0, spark.radius) * view.zoom);
                    const std::int32_t paletteIndex = ((spark.colorIndex % 3) + 3) % 3;
                    const SDL_Color base = paletteIndex == 0
                        ? SDL_Color{ 168, 78, 255, 255 }
                        : (paletteIndex == 1
                            ? SDL_Color{ 255, 222, 70, 255 }
                            : SDL_Color{ 255, 255, 250, 255 });
                    const double paletteAlpha = paletteIndex == 0 ? 0.96 : (paletteIndex == 1 ? 0.98 : 1.0);
                    const SDL_Color color = scaledAlpha(base, paletteAlpha * alpha);

                    drawFilledCircle(point.x, point.y, radius * 2.15f, scaledAlpha(color, 0.34));
                    drawFilledCircle(point.x, point.y, radius * 0.68f, color);

                    const float cosine = static_cast<float>(std::cos(spark.rotation));
                    const float sine = static_cast<float>(std::sin(spark.rotation));
                    const auto rotatedPoint = [&](float localX, float localY)
                    {
                        return SDL_FPoint{
                            point.x + localX * cosine - localY * sine,
                            point.y + localX * sine + localY * cosine
                        };
                    };
                    const SDL_FPoint horizontalStart = rotatedPoint(-radius * 1.55f, 0.0f);
                    const SDL_FPoint horizontalEnd = rotatedPoint(radius * 1.55f, 0.0f);
                    const SDL_FPoint verticalStart = rotatedPoint(0.0f, -radius * 1.55f);
                    const SDL_FPoint verticalEnd = rotatedPoint(0.0f, radius * 1.55f);
                    const float thickness = std::max(1.0f, radius * 0.42f);
                    drawLineSegment(horizontalStart.x, horizontalStart.y, horizontalEnd.x, horizontalEnd.y, thickness, color);
                    drawLineSegment(verticalStart.x, verticalStart.y, verticalEnd.x, verticalEnd.y, thickness, color);
                }
            }



            bool IgnatiusNativeScene::isUndeathProjectile(const FProjectileState& projectile) const
            {
                return projectile.trailEffect == "undeath" || projectile.visualStyle == "undeath";
            }



            void IgnatiusNativeScene::drawEnemyFireballTrailParticles(const FProjectileState& projectile, const NativeRenderView& view)
            {
                const bool undeath = isUndeathProjectile(projectile);
                const FNativeAtlasFrameAsset* projectileAsset = undeath ? nullptr : findProjectileFrameAsset(projectile);
                const FProjectileTrailPalette* trailPalette = projectileAsset && projectileAsset->projectileTrailPalette.valid
                    ? &projectileAsset->projectileTrailPalette
                    : nullptr;
                for (const FProjectileTrailPoint& particle : projectile.trail)
                {
                    const double age = gameState.clock.time - particle.birth;
                    const double lifetime = std::max(0.0001, particle.lifetime > 0.0 ? particle.lifetime : 0.2);
                    if (age < 0.0 || age > lifetime)
                    {
                        continue;
                    }

                    const double fade = 1.0 - age / lifetime;
                    const double worldX = particle.x + particle.vx * age;
                    const double worldY = particle.y + particle.vy * age;
                    if (!worldPointVisible(view, worldX, worldY, 48.0))
                    {
                        continue;
                    }

                    const SDL_FPoint screen = worldToScreen(view, worldX, worldY);
                    const float radius = static_cast<float>(std::max(0.15 * view.zoom, (particle.radius > 0.0 ? particle.radius : 2.0) * fade * view.zoom));
                    const Uint8 alpha = static_cast<Uint8>(std::clamp(fade * 0.92 * 255.0, 0.0, 255.0));
                    if (undeath)
                    {
                        if (rawGpuOverlayBatcher && rawWorldUndeathBubbleTextureGpu)
                        {
                            const float diameter = radius * 2.45f;
                            rawGpuOverlayBatcher->appendQuad(
                                rawWorldUndeathBubbleTextureGpu,
                                screen.x - diameter * 0.5f,
                                screen.y - diameter * 0.5f,
                                diameter,
                                diameter,
                                0.0f,
                                0.0f,
                                0.0f,
                                1.0f,
                                1.0f,
                                SDL_FColor{ 1.0f, 1.0f, 1.0f, static_cast<float>(alpha) / 255.0f });
                        }
                        else
                        {
                            // Software fallback approximates the same dark-green radial bubble.
                            drawFilledCircle(screen.x, screen.y, radius * 1.225f, SDL_Color{ 18, 70, 0, static_cast<Uint8>(alpha * 0.68) });
                            drawFilledCircle(screen.x, screen.y, radius * 0.90f, SDL_Color{ 43, 126, 4, static_cast<Uint8>(alpha * 0.82) });
                            drawRing(screen.x, screen.y, radius * 0.83f, std::max(1.0f, radius * 0.09f), SDL_Color{ 74, 184, 4, static_cast<Uint8>(alpha * 0.54) });
                            drawFilledCircle(screen.x - radius * 0.32f, screen.y - radius * 0.34f, std::max(0.7f, radius * 0.14f), SDL_Color{ 154, 255, 28, static_cast<Uint8>(alpha * 0.48) });
                        }
                        continue;
                    }

                    const double cooledHeat = std::clamp(particle.heat * (0.45 + fade * 0.55), 0.0, 1.0);
                    SDL_Color outer{ 150, 16, 12, static_cast<Uint8>(alpha * 0.42) };
                    SDL_Color middle{ 220, 44, 18, static_cast<Uint8>(alpha * 0.72) };
                    SDL_Color core{ 255, 100, 28, alpha };
                    if (cooledHeat > 0.78)
                    {
                        outer = { 255, 90, 12, static_cast<Uint8>(alpha * 0.42) };
                        middle = { 255, 180, 45, static_cast<Uint8>(alpha * 0.72) };
                        core = { 255, 255, 245, alpha };
                    }
                    else if (cooledHeat > 0.50)
                    {
                        outer = { 160, 20, 12, static_cast<Uint8>(alpha * 0.42) };
                        middle = { 255, 96, 18, static_cast<Uint8>(alpha * 0.72) };
                        core = { 255, 240, 130, alpha };
                    }
                    else if (cooledHeat > 0.25)
                    {
                        outer = { 120, 10, 8, static_cast<Uint8>(alpha * 0.42) };
                        middle = { 210, 40, 14, static_cast<Uint8>(alpha * 0.72) };
                        core = { 255, 176, 58, alpha };
                    }
                    if (trailPalette)
                    {
                        outer = scaledAlpha(
                            projectileTrailColorAtHeat(*trailPalette, std::clamp(cooledHeat - 0.26, 0.0, 1.0)),
                            static_cast<double>(alpha) / 255.0 * 0.42);
                        middle = scaledAlpha(
                            projectileTrailColorAtHeat(*trailPalette, cooledHeat),
                            static_cast<double>(alpha) / 255.0 * 0.72);
                        core = scaledAlpha(
                            projectileTrailColorAtHeat(*trailPalette, std::clamp(cooledHeat + 0.20, 0.0, 1.0)),
                            static_cast<double>(alpha) / 255.0);
                    }
                    drawFilledCircle(screen.x, screen.y, radius * 1.35f, outer);
                    drawFilledCircle(screen.x, screen.y, radius * 0.86f, middle);
                    drawFilledCircle(screen.x - radius * 0.12f, screen.y - radius * 0.16f, radius * 0.42f, core);
                }
            }



            void IgnatiusNativeScene::drawRocketPathTrail(const FProjectileState& projectile, const NativeRenderView& view)
            {
                struct TrailPoint
                {
                    float x = 0.0f;
                    float y = 0.0f;
                    double time = 0.0;
                };

                const double speed = std::max(0.001, std::hypot(projectile.vx, projectile.vy));
                const float trailOffsetX = static_cast<float>(
                    -projectile.vy / speed * ROCKET_TRAIL_LATERAL_OFFSET_PX * view.zoom);
                const float trailOffsetY = static_cast<float>(
                    projectile.vx / speed * ROCKET_TRAIL_LATERAL_OFFSET_PX * view.zoom);

                std::vector<TrailPoint> screenTrail;
                screenTrail.reserve(projectile.trail.size() + 1);
                for (const FProjectileTrailPoint& point : projectile.trail)
                {
                    const SDL_FPoint screen = worldToScreen(view, point.x, point.y);
                    screenTrail.push_back(TrailPoint{ screen.x + trailOffsetX, screen.y + trailOffsetY, point.time });
                }
                const SDL_FPoint current = worldToScreen(view, projectile.x, projectile.y);
                screenTrail.push_back(TrailPoint{ current.x + trailOffsetX, current.y + trailOffsetY, gameState.clock.time });
                if (screenTrail.size() < 2)
                {
                    return;
                }

                const double maxScreenLength = static_cast<double>(view.viewportWidth) * 0.075;
                std::vector<TrailPoint> visibleReverse;
                visibleReverse.reserve(screenTrail.size());
                visibleReverse.push_back(screenTrail.back());
                double distanceSoFar = 0.0;
                for (std::size_t reverseIndex = screenTrail.size() - 1; reverseIndex > 0; --reverseIndex)
                {
                    const TrailPoint& newer = screenTrail[reverseIndex];
                    const TrailPoint& older = screenTrail[reverseIndex - 1];
                    const double segment = std::hypot(static_cast<double>(newer.x - older.x), static_cast<double>(newer.y - older.y));
                    if (distanceSoFar + segment > maxScreenLength)
                    {
                        const double remaining = std::max(0.0, maxScreenLength - distanceSoFar);
                        const double ratio = segment <= 0.0 ? 0.0 : remaining / segment;
                        visibleReverse.push_back(TrailPoint{
                            static_cast<float>(newer.x + (older.x - newer.x) * ratio),
                            static_cast<float>(newer.y + (older.y - newer.y) * ratio),
                            older.time
                        });
                        break;
                    }
                    visibleReverse.push_back(older);
                    distanceSoFar += segment;
                }
                std::reverse(visibleReverse.begin(), visibleReverse.end());
                if (visibleReverse.size() < 2)
                {
                    return;
                }

                for (std::size_t index = 0; index + 1 < visibleReverse.size(); ++index)
                {
                    const TrailPoint& a = visibleReverse[index];
                    const TrailPoint& b = visibleReverse[index + 1];
                    const double u = static_cast<double>(index) / static_cast<double>(std::max<std::size_t>(1, visibleReverse.size() - 2));
                    const double age = std::clamp((gameState.clock.time - a.time) / 1.25, 0.0, 1.0);
                    const double smokeAlpha = (0.05 + 0.16 * u) * (1.0 - age * 0.55);
                    const float smokeWidth = std::max(2.0f, static_cast<float>((18.0 - u * 9.0) * view.zoom));
                    drawLineSegment(
                        a.x,
                        a.y,
                        b.x,
                        b.y,
                        smokeWidth,
                        SDL_Color{ 184, 172, 198, static_cast<Uint8>(std::clamp(smokeAlpha * 255.0, 0.0, 255.0)) });
                }

                const std::int32_t sparkCount = std::min<std::int32_t>(42, std::max<std::int32_t>(8, static_cast<std::int32_t>(visibleReverse.size()) * 2));
                const double seed = static_cast<double>(projectile.id.size() * 97)
                    + std::floor(projectile.x * 0.11)
                    + std::floor(projectile.y * 0.07);
                for (std::int32_t index = 0; index < sparkCount; ++index)
                {
                    const std::size_t segmentIndex = std::min<std::size_t>(
                        visibleReverse.size() - 2,
                        static_cast<std::size_t>(std::floor(projectileTrailHashNoise(seed + 13.0, index) * static_cast<double>(visibleReverse.size() - 1))));
                    const TrailPoint& a = visibleReverse[segmentIndex];
                    const TrailPoint& b = visibleReverse[segmentIndex + 1];
                    const double t = projectileTrailHashNoise(seed + 31.0, index);
                    const double x = a.x + (b.x - a.x) * t;
                    const double y = a.y + (b.y - a.y) * t;
                    const double dx = b.x - a.x;
                    const double dy = b.y - a.y;
                    const double length = std::max(1.0, std::hypot(dx, dy));
                    const double nx = -dy / length;
                    const double ny = dx / length;
                    const double u = (static_cast<double>(segmentIndex) + t) / static_cast<double>(std::max<std::size_t>(1, visibleReverse.size() - 1));
                    const double spread = (5.0 + (1.0 - u) * 11.0) * view.zoom;
                    const double jitter = (projectileTrailHashNoise(seed + 71.0, index) - 0.5) * spread;
                    const double age = std::clamp((gameState.clock.time - a.time) / 1.25, 0.0, 1.0);
                    const double twinkle = 0.72 + 0.28 * std::sin(gameState.clock.time * 19.0 + static_cast<double>(index) * 1.7);
                    const double fade = std::pow(std::max(0.0, u), 0.38) * (1.0 - age * 0.55) * twinkle;
                    const float size = static_cast<float>((0.8 + projectileTrailHashNoise(seed + 101.0, index) * 2.1) * view.zoom * (0.45 + fade));
                    const Uint8 alpha = static_cast<Uint8>(std::clamp((0.04 + fade * 0.52) * 255.0, 0.0, 173.0));
                    const SDL_Color color = index % 7 == 0
                        ? SDL_Color{ 197, 151, 255, alpha }
                        : (index % 2 == 0 ? SDL_Color{ 255, 239, 126, alpha } : SDL_Color{ 255, 133, 82, alpha });
                    drawFilledCircle(
                        static_cast<float>(x + nx * jitter),
                        static_cast<float>(y + ny * jitter),
                        std::max(0.5f, size),
                        color);
                }
            }



            void IgnatiusNativeScene::drawProjectileExplosionEffects(const NativeRenderView& view)
            {
                for (const FProjectileState& projectile : gameState.projectiles)
                {
                    const bool enemyAreaExplosion = projectile.owner == "enemy" && projectile.areaDamageRadius > 0.0;
                    const bool mortarAreaExplosion = enemyAreaExplosion && projectile.explosionEffect == "rocket";
                    if (projectile.state != "exploding" || (projectile.owner == "enemy" && !enemyAreaExplosion))
                    {
                        continue;
                    }

                    const double explosionScale = std::max(1.0, projectile.explosionVisualScale);
                    const double extentWorld = std::max({ 36.0, projectile.radius, projectile.areaDamageRadius, 22.0 * explosionScale });
                    const double marginWorld = 96.0 / std::max(0.1, view.zoom);
                    const double viewportRight = view.left + static_cast<double>(view.viewportWidth) / view.zoom;
                    const double viewportBottom = view.top + static_cast<double>(view.viewportHeight) / view.zoom;
                    if (projectile.x + extentWorld < view.left - marginWorld
                        || projectile.x - extentWorld > viewportRight + marginWorld
                        || projectile.y + extentWorld < view.top - marginWorld
                        || projectile.y - extentWorld > viewportBottom + marginWorld)
                    {
                        continue;
                    }

                    const SDL_FPoint screen = worldToScreen(view, projectile.x, projectile.y);
                    // Canvas reference parity: player rockets retain their orange/yellow
                    // spark burst while the shared projectile remains in its exploding state.
                    const bool rocketStyleExplosion = projectile.owner != "enemy" || mortarAreaExplosion;
                    const std::int32_t sparkCount = rocketStyleExplosion
                        ? std::max<std::int32_t>(9, static_cast<std::int32_t>(std::lround(9.0 * explosionScale)))
                        : 7;
                    const float sparkRadius = rocketStyleExplosion
                        ? static_cast<float>(22.0 * explosionScale * view.zoom)
                        : static_cast<float>(16.0 * view.zoom);
                    drawSparkBurst(
                        screen.x,
                        screen.y,
                        static_cast<float>(view.zoom),
                        projectile.age + projectile.x,
                        sparkCount,
                        sparkRadius,
                        "rocket");

                    const double areaRadius = std::max(0.0, projectile.areaDamageRadius);
                    if (areaRadius > 0.0)
                    {
                        const double total = std::max(0.001, gameState.tuning.rocketProjectileExplosionSeconds);
                        const double remaining = std::max(0.0, projectile.explosionTimer);
                        const double progress = std::clamp(1.0 - remaining / total, 0.0, 1.0);
                        const float ringRadius = static_cast<float>(areaRadius * view.zoom * (0.18 + progress * 0.82));
                        const float ringThickness = std::max(2.0f, static_cast<float>(7.0 * (1.0 - progress * 0.65) * view.zoom));
                        const Uint8 alpha = static_cast<Uint8>(std::clamp((1.0 - progress) * 0.58 * 0.92 * 255.0, 0.0, 255.0));
                        drawRing(screen.x, screen.y, ringRadius, ringThickness, SDL_Color{ 255, 208, 89, alpha });
                    }
                }
            }



            void IgnatiusNativeScene::drawProjectile(const FProjectileState& projectile, const NativeRenderView& view)
            {
                const bool fireball = projectile.kind == "enemyFireball" || projectile.kind == "fireball";
                const bool undeath = isUndeathProjectile(projectile);
                const bool lingeringUndeath = undeath && (projectile.state == "exploding" || projectile.state == "trailFading");
                if ((projectile.state != "launched" && !lingeringUndeath) || !worldPointVisible(view, projectile.x, projectile.y, 160.0))
                {
                    return;
                }

                if (fireball)
                {
                    drawEnemyFireballTrailParticles(projectile, view);
                    if (projectile.state != "launched" || undeath)
                    {
                        return;
                    }
                }

                const SDL_FPoint screen = worldToScreen(view, projectile.x, projectile.y);
                const double angle = std::atan2(projectile.vy, projectile.vx);
                const float pulse = static_cast<float>(0.92 + 0.08 * std::sin(gameState.clock.time * 19.0 + projectile.age * 11.0));

                if (projectile.owner == "player" || projectile.kind == "rocket")
                {
                    const std::string projectileFrameId = projectile.frameId.empty()
                        ? std::string("rocket_projectile")
                        : projectile.frameId;
                    const double speed = std::max(0.001, std::hypot(projectile.vx, projectile.vy));
                    const double directionX = projectile.vx / speed;
                    const double directionY = projectile.vy / speed;
                    const double rightX = -directionY;
                    const double rightY = directionX;
                    const double baseRocketTargetHeight = projectileFrameId == "rocket_projectile_rocketpunch"
                        ? 99.0
                        : 58.0;
                    const float rocketTargetHeight = static_cast<float>(baseRocketTargetHeight * std::max(0.1, projectile.visualScale) * view.zoom);
                    const float exhaustTargetHeight = projectileFrameId == "rocket_projectile_rocketpunch"
                        ? static_cast<float>(rocketTargetHeight * (58.0 / 99.0))
                        : rocketTargetHeight;
                    drawRocketPathTrail(projectile, view);
                    double stableSeed = 0.0;
                    for (std::size_t index = 0; index < projectile.id.size(); ++index)
                    {
                        stableSeed += static_cast<unsigned char>(projectile.id[index]) * static_cast<double>(index + 1);
                    }
                    const bool rocketpunch = projectileFrameId == "rocket_projectile_rocketpunch";
                    const double backOffsetPx = rocketpunch
                        ? (0.965 - 0.78) * baseRocketTargetHeight * std::max(0.1, projectile.visualScale)
                        : 23.0;
                    const double lateralOffsetPx = ROCKET_TRAIL_LATERAL_OFFSET_PX;
                    const double forwardOffsetPx = ROCKET_FLAME_FORWARD_OFFSET_PX;
                    const float adjustedFlameX = screen.x + static_cast<float>((
                        -directionX * backOffsetPx
                        + rightX * lateralOffsetPx
                        + directionX * forwardOffsetPx) * view.zoom);
                    const float adjustedFlameY = screen.y + static_cast<float>((
                        -directionY * backOffsetPx
                        + rightY * lateralOffsetPx
                        + directionY * forwardOffsetPx) * view.zoom);
                    const double exhaustAngle = std::atan2(-directionY, -directionX);
                    if (deluxeRocketExhaustEnabled())
                    {
                        drawDeluxeRocketExhaust(
                            adjustedFlameX,
                            adjustedFlameY,
                            exhaustAngle,
                            std::max(0.035, static_cast<double>(exhaustTargetHeight) / DELUXE_ROCKET_EXHAUST_REFERENCE_HEIGHT),
                            stableSeed);
                    }
                    else if (animatedRocketFlameAtlasEnabled())
                    {
                        drawAnimatedRocketFlameAtlas(
                            adjustedFlameX,
                            adjustedFlameY,
                            exhaustAngle,
                            rocketFlameAtlasTargetHeight(exhaustTargetHeight),
                            stableSeed);
                    }
                    else
                    {
                        drawFilledCircle(adjustedFlameX, adjustedFlameY, static_cast<float>(9.0 * view.zoom * pulse), SDL_Color{ 153, 76, 222, 100 });
                        drawFilledCircle(adjustedFlameX, adjustedFlameY, static_cast<float>(5.5 * view.zoom * pulse), SDL_Color{ 255, 194, 64, 220 });
                    }
                    const FNativeAtlasFrameAsset* asset = findLoadedCharacterFrame(
                        projectile.characterId.empty() ? std::string("ct_char_wizard_1") : projectile.characterId,
                        projectileFrameId,
                        projectile.projectilePartName);
                    if (!asset)
                    {
                        asset = findLoadedCharacterFrame("ct_char_wizard_1", "rocket_projectile");
                    }
                    if (!drawAtlasFrameCentered(
                        asset,
                        screen.x,
                        screen.y,
                        rocketTargetHeight,
                        angle + std::numbers::pi * 0.5,
                        0.5f,
                        0.78f))
                    {
                        drawFilledCircle(screen.x, screen.y, static_cast<float>(8.0 * view.zoom), SDL_Color{ 255, 206, 86, 245 });
                    }
                    return;
                }

                const std::string characterId = projectile.characterId;
                const FNativeAtlasFrameAsset* asset = findLoadedCharacterFrame(characterId, projectile.frameId, projectile.projectilePartName);
                if (fireball)
                {
                    asset = findProjectileFrameAsset(projectile, "ct_char_enemy_010", "fireball");
                    if (drawAtlasFrameCentered(
                            asset,
                            screen.x,
                            screen.y,
                            static_cast<float>(std::max(8.0, projectile.radius) * 2.0 * view.zoom),
                            angle))
                    {
                        return;
                    }

                    const float radius = static_cast<float>(std::max(2.0, projectile.radius) * view.zoom);
                    drawFilledCircle(screen.x, screen.y, radius * 1.4f * pulse, SDL_Color{ 255, 57, 22, 92 });
                    drawFilledCircle(screen.x, screen.y, radius * 0.82f * pulse, SDL_Color{ 255, 142, 41, 218 });
                    return;
                }

                if (projectile.kind == "enemyMusketBall")
                {
                    if (!asset)
                    {
                        asset = findLoadedCharacterFrame(
                            characterId.empty() ? std::string("ct_char_enemy_011") : characterId,
                            projectile.frameId.empty() ? std::string("cannonball") : projectile.frameId,
                            projectile.projectilePartName);
                    }
                    if (!asset)
                    {
                        asset = findLoadedCharacterFrame("ct_char_enemy_011", "cannonball");
                    }
                    if (!asset)
                    {
                        asset = findLoadedCharacterFrame("ct_char_enemy_010", "cannonball");
                    }
                    const double projectileRotation = projectile.orientToVelocity ? angle : projectile.age * projectile.rotationSpeed;
                    if (drawAtlasFrameCentered(
                            asset,
                            screen.x,
                            screen.y,
                            static_cast<float>(std::max(3.0, projectile.radius) * 2.45 * std::max(0.01, projectile.visualScale) * view.zoom),
                            projectileRotation))
                    {
                        return;
                    }

                    const float radius = static_cast<float>(std::max(3.0, projectile.radius) * view.zoom);
                    drawFilledCircle(screen.x, screen.y, radius, SDL_Color{ 42, 44, 49, 250 });
                    drawFilledCircle(screen.x - radius * 0.28f, screen.y - radius * 0.30f, std::max(1.3f, radius * 0.28f), SDL_Color{ 255, 255, 255, 64 });
                    return;
                }

                const double projectileVisualScale = std::max(0.01, projectile.visualScale);
                const float targetHeight = projectile.kind == "enemyKnife"
                    ? static_cast<float>(std::max(8.0, projectile.radius * 1.45) * projectileVisualScale * view.zoom)
                    : static_cast<float>(std::max(12.0, projectile.radius * 2.35) * projectileVisualScale * view.zoom);
                const double projectileRotation = projectile.orientToVelocity ? angle : projectile.age * projectile.rotationSpeed;
                if (drawAtlasFrameCentered(asset, screen.x, screen.y, targetHeight, projectileRotation))
                {
                    return;
                }

                const float radius = static_cast<float>(std::max(4.0, projectile.radius) * view.zoom);
                drawFilledCircle(screen.x, screen.y, radius * 1.35f, SDL_Color{ 154, 74, 205, 65 });
                drawFilledCircle(screen.x, screen.y, radius * 0.72f, SDL_Color{ 225, 187, 255, 235 });
            }



            void IgnatiusNativeScene::drawProjectiles(const NativeRenderView& view)
            {
                for (const FProjectileState& projectile : gameState.projectiles)
                {
                    drawProjectile(projectile, view);
                }
            }



            void IgnatiusNativeScene::drawEnemyHealthBar(const FEnemyState& enemy, const NativeRenderView& view)
            {
                const double maxHealth = std::max(0.0, enemy.maxHealth);
                const double health = std::clamp(enemy.health, 0.0, maxHealth > 0.0 ? maxHealth : 1.0);
                if (enemy.isBoss || enemy.invulnerable || health <= 0.0 || maxHealth <= 0.0 || health >= maxHealth || enemy.healthBarTimer <= 0.0)
                {
                    return;
                }

                const double actorScale = std::max(0.05, enemy.renderScale);
                const double ratio = std::clamp(health / maxHealth, 0.0, 1.0);
                const SDL_FPoint center = worldToScreen(
                    view,
                    enemy.x,
                    enemy.y - enemy.height - 10.0 / actorScale);
                const float width = static_cast<float>(std::max(34.0, std::min(74.0, enemy.width * std::max(0.75, actorScale))) * view.zoom);
                const float height = static_cast<float>(6.0 * view.zoom);

                drawTextureRect(
                    canvasWhiteTexture,
                    canvasWhiteTextureGpu,
                    center.x - width * 0.5f - static_cast<float>(view.zoom),
                    center.y - static_cast<float>(view.zoom),
                    width + static_cast<float>(view.zoom * 2.0),
                    height + static_cast<float>(view.zoom * 2.0),
                    SDL_Color{ 14, 10, 22, 199 });
                drawTextureRect(
                    canvasWhiteTexture,
                    canvasWhiteTextureGpu,
                    center.x - width * 0.5f,
                    center.y,
                    width,
                    height,
                    SDL_Color{ 92, 36, 52, 235 });
                drawTextureRect(
                    canvasWhiteTexture,
                    canvasWhiteTextureGpu,
                    center.x - width * 0.5f,
                    center.y,
                    width * static_cast<float>(ratio),
                    height,
                    SDL_Color{ 245, 202, 86, 245 });
            }



            const FEnemyState* IgnatiusNativeScene::activeBoss() const
            {
                for (const FEnemyState& enemy : gameState.enemies)
                {
                    if (enemy.isBoss && !enemy.invulnerable && enemy.health > 0.0 && (enemy.engaged || enemy.alerted || enemy.health < enemy.maxHealth))
                    {
                        return &enemy;
                    }
                }
                return nullptr;
            }
    }
}
