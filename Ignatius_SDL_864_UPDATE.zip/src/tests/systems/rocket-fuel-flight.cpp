#include "tests/support/test-suite.h"

namespace IgnatiusTests
{
    void runRocketFuelFlightBench()
    {
        const std::optional<FPowerUpEffectDefinition> magicRing = powerUpEffectDefinition(POWER_UP_EFFECT_IDS::MAGIC_RING);
        check(magicRing.has_value(), "Magic Ring is a first-class timed power-up");
        if (magicRing.has_value())
        {
            check(std::abs(magicRing->durationSeconds - MAGIC_RING_DURATION_SECONDS) < 0.000001,
                "Magic Ring conceals Ignatius for exactly twenty-five seconds");
            check(std::abs(MAGIC_RING_DURATION_SECONDS - 25.0) < 0.000001,
                "Magic Ring concealment duration stays at twenty-five seconds");
            check(std::abs(MAGIC_RING_PANIC_SECONDS - 10.0) < 0.000001,
                "unseen attackers retain ten seconds of panic memory after their last hit");
            check(std::abs(MAGIC_RING_STEALTH_ALPHA - 0.25) < 0.000001,
                "Magic Ring presentation draws the assembled player at twenty-five percent opacity");
            check(magicRing->stacking == POWER_UP_STACKING_RULES::REFRESH,
                "collecting another Magic Ring refreshes concealment");
        }

        {
            FGameState ringPickupState = createInitialGameState();
            Json ringLevel = {
                { "levelId", "level_t94" },
                { "testPlayerStart", { { "x", 100.0 }, { "y", 300.0 } } },
                { "entities", Json::array({
                    Json{
                        { "id", "magic_ring_pickup_test" },
                        { "type", "magicRingPickup" },
                        { "x", 100.0 },
                        { "y", 300.0 },
                        { "w", 55.0 },
                        { "h", 54.0 },
                        { "pickupKind", "magicRing" },
                        { "effectId", "magicRing" },
                        { "amount", 1 },
                        { "state", "available" },
                        { "visualStates", {
                            { "available", Json::array() },
                            { "collected", Json::array() }
                        } }
                    }
                }) }
            };
            check(applyEditorLevelToWorld(ringPickupState, ringLevel),
                "synthetic native Magic Ring pickup fixture applies without an authored campaign level");
            ringPickupState.story.portalIntro.reset();
            ringPickupState.story.portalExit.reset();
            ringPickupState.story.mailboxEvents.clear();
            ringPickupState.story.mailboxEventIndex = NO_MAILBOX_EVENT_INDEX;
            ringPickupState.player.x = 100.0;
            ringPickupState.player.y = 300.0;
            stepSimulation(ringPickupState, createInputFrame(), MAX_SIM_DT);
            check(!ringPickupState.pickups.empty() && ringPickupState.pickups.front().kind == "powerUp",
                "native Magic Ring entity normalizes to a collectible power-up");
            check(!ringPickupState.pickups.empty() && ringPickupState.pickups.front().collected,
                "touching a native Magic Ring collects it");
            const std::optional<FActivePowerUpEffectState> activeRing = activePowerUpEffect(
                ringPickupState.statusEffects.active,
                POWER_UP_EFFECT_IDS::MAGIC_RING);
            check(activeRing.has_value(), "collecting a native Magic Ring activates concealment");
            if (activeRing.has_value() && activeRing->remainingSeconds.has_value())
            {
                check(activeRing->remainingSeconds.value() > 24.9 && activeRing->remainingSeconds.value() <= 25.0,
                    "fresh native Magic Ring concealment begins with essentially the full twenty-five-second timer");
            }


            const auto activateTestMagicRing = [&](FGameState& state)
            {
                FActivePowerUpEffectState effect;
                effect.id = POWER_UP_EFFECT_IDS::MAGIC_RING;
                effect.definition = *magicRing;
                effect.remainingSeconds = MAGIC_RING_DURATION_SECONDS;
                effect.activatedAt = state.clock.time;
                state.statusEffects.active[effect.id] = effect;
            };
            const auto magicRingIsActive = [](const FGameState& state)
            {
                return activePowerUpEffect(state.statusEffects.active, POWER_UP_EFFECT_IDS::MAGIC_RING).has_value();
            };
            const auto prepareGameplayState = [](FGameState& state)
            {
                state.story.portalIntro.reset();
                state.story.portalExit.reset();
                state.story.mailboxEvents.clear();
                state.story.mailboxEventIndex = NO_MAILBOX_EVENT_INDEX;
            };

            FGameState damageBreakState = createInitialGameState();
            prepareGameplayState(damageBreakState);
            activateTestMagicRing(damageBreakState);
            check(damagePlayer(damageBreakState, 1.0, "magic_ring_damage_break", true) > 0.0,
                "native Magic Ring damage-break fixture takes real damage");
            check(!magicRingIsActive(damageBreakState),
                "taking any real damage immediately cancels native Magic Ring concealment");

            FGameState contactDamageBreakState = createInitialGameState();
            prepareGameplayState(contactDamageBreakState);
            Json contactLevel = {
                { "levelId", "level_t95" },
                { "testPlayerStart", { { "x", 200.0 }, { "y", 520.0 } } },
                { "entities", Json::array({
                    Json{
                        { "id", "contact_damage_enemy" },
                        { "type", "characterEnemy" },
                        { "x", 200.0 },
                        { "y", 520.0 },
                        { "enemyCatalogId", "enemy_010" },
                        { "patrolDistance", 0.0 }
                    }
                }) }
            };
            check(applyEditorLevelToWorld(contactDamageBreakState, contactLevel),
                "synthetic native Magic Ring contact-damage fixture applies without an authored campaign level");
            prepareGameplayState(contactDamageBreakState);
            activateTestMagicRing(contactDamageBreakState);
            contactDamageBreakState.player.x = 200.0;
            contactDamageBreakState.player.y = 520.0;
            contactDamageBreakState.player.onGround = false;
            contactDamageBreakState.player.wasOnGround = false;
            const double contactHealthBefore = contactDamageBreakState.health.amount;
            stepSimulation(contactDamageBreakState, createInputFrame(), MAX_SIM_DT);
            check(contactDamageBreakState.health.amount < contactHealthBefore,
                "native Magic Ring contact-damage fixture takes real enemy body-contact damage");
            check(!magicRingIsActive(contactDamageBreakState),
                "enemy body-contact damage immediately cancels native Magic Ring concealment");

            FGameState movementState = createInitialGameState();
            prepareGameplayState(movementState);
            movementState.player.onGround = true;
            movementState.player.wasOnGround = true;
            activateTestMagicRing(movementState);
            FInputFrame runInput = createInputFrame();
            runInput.moveRight = true;
            runInput.moveAxis = 1.0;
            stepSimulation(movementState, runInput, MAX_SIM_DT);
            check(magicRingIsActive(movementState), "running does not break native Magic Ring concealment");
            FInputFrame jumpInput = createInputFrame();
            jumpInput.jumpPressed = true;
            jumpInput.jumpHeld = true;
            stepSimulation(movementState, jumpInput, MAX_SIM_DT);
            check(magicRingIsActive(movementState), "jumping does not break native Magic Ring concealment");
            movementState.player.onGround = false;
            movementState.player.wasOnGround = false;
            movementState.equipment.rocket.attachedBoosting = true;
            FInputFrame hoverInput = createInputFrame();
            hoverInput.boostHeld = true;
            stepSimulation(movementState, hoverInput, MAX_SIM_DT);
            check(magicRingIsActive(movementState), "rocket-assisted hovering does not break native Magic Ring concealment");

            FGameState lungeBreakState = createInitialGameState();
            prepareGameplayState(lungeBreakState);
            lungeBreakState.player.x = 135.0;
            lungeBreakState.player.y = 600.0;
            lungeBreakState.player.vx = 0.0;
            lungeBreakState.player.vy = 0.0;
            lungeBreakState.player.onGround = true;
            lungeBreakState.player.wasOnGround = true;
            lungeBreakState.player.supportId = "test_floor";
            activateTestMagicRing(lungeBreakState);
            FInputFrame lungeInput = createInputFrame();
            lungeInput.lungePressed = true;
            lungeInput.lungeHeld = true;
            stepSimulation(lungeBreakState, lungeInput, MAX_SIM_DT);
            check(lungeBreakState.player.lungeCharging && magicRingIsActive(lungeBreakState),
                "charging a native lunge preserves Magic Ring concealment until the attack commits");
            lungeBreakState.player.lungeChargeTime = std::max(0.0, lungeBreakState.tuning.playerLungeChargeSeconds - MAX_SIM_DT);
            lungeInput.lungePressed = false;
            stepSimulation(lungeBreakState, lungeInput, MAX_SIM_DT);
            check(lungeBreakState.player.lungeActive, "native Magic Ring lunge fixture commits the attack");
            check(!magicRingIsActive(lungeBreakState), "committing a native lunge immediately cancels Magic Ring concealment");

            FGameState bodySlamBreakState = createInitialGameState();
            prepareGameplayState(bodySlamBreakState);
            bodySlamBreakState.player.onGround = true;
            bodySlamBreakState.player.wasOnGround = true;
            activateTestMagicRing(bodySlamBreakState);
            bodySlamBreakState.player.y = 420.0;
            bodySlamBreakState.player.vy = bodySlamBreakState.tuning.fallDamageSafeImpactSpeed + 120.0;
            bodySlamBreakState.player.onGround = false;
            bodySlamBreakState.player.wasOnGround = false;
            bodySlamBreakState.player.airborneTime = 1.0;
            FInputFrame slamInput = createInputFrame();
            slamInput.dropHeld = true;
            stepSimulation(bodySlamBreakState, slamInput, MAX_SIM_DT);
            check(bodySlamBreakState.player.bodySlamCommitted, "native Magic Ring body-slam fixture commits the slam");
            check(!magicRingIsActive(bodySlamBreakState), "committing a native body slam immediately cancels Magic Ring concealment");

            FGameState failedRocketState = createInitialGameState();
            prepareGameplayState(failedRocketState);
            activateTestMagicRing(failedRocketState);
            failedRocketState.fuel.amount = 0.0;
            FInputFrame rocketInput = createInputFrame();
            rocketInput.weaponPressed = true;
            stepSimulation(failedRocketState, rocketInput, MAX_SIM_DT);
            check(magicRingIsActive(failedRocketState), "an unsuccessful native rocket attempt does not break Magic Ring concealment");

            FGameState rocketBreakState = createInitialGameState();
            prepareGameplayState(rocketBreakState);
            activateTestMagicRing(rocketBreakState);
            stepSimulation(rocketBreakState, rocketInput, MAX_SIM_DT);
            check(!magicRingIsActive(rocketBreakState), "firing a native rocket normally cancels Magic Ring concealment");

            FGameState stealthRocketState = createInitialGameState();
            prepareGameplayState(stealthRocketState);
            stealthRocketState.playerProgression.stealthRocketUnlocked = true;
            activateTestMagicRing(stealthRocketState);
            stepSimulation(stealthRocketState, rocketInput, MAX_SIM_DT);
            check(magicRingIsActive(stealthRocketState),
                "the persistent native Stealth Rocket talent allows rockets without breaking Magic Ring concealment");
        }

        const std::optional<FPowerUpEffectDefinition> cursed = powerUpEffectDefinition(POWER_UP_EFFECT_IDS::CURSED);
        check(cursed.has_value(), "Cursed is a first-class timed native power-up");
        if (cursed.has_value())
        {
            check(std::abs(cursed->durationSeconds - 10.0) < 0.000001, "native Cursed lasts ten seconds");
            check(cursed->stacking == POWER_UP_STACKING_RULES::REFRESH, "another native cursed skull refreshes the timer");
            check(cursed->clearOnDeath, "native Cursed clears on death/respawn");

            const std::optional<FPowerUpEffectDefinition> curseFlight = powerUpEffectDefinition(POWER_UP_EFFECT_IDS::FLIGHT);
            const std::optional<FPowerUpEffectDefinition> curseOverdrive = powerUpEffectDefinition(POWER_UP_EFFECT_IDS::OVERDRIVE);
            check(curseFlight.has_value() && curseOverdrive.has_value(), "Cursed cancellation fixture has Flight and Overdrive definitions");

            FGameState cursedPickupState = createInitialGameState();
            Json cursedLevel = {
                { "levelId", "level_t96" },
                { "testPlayerStart", { { "x", 100.0 }, { "y", 300.0 } } },
                { "entities", Json::array({
                    Json{
                        { "id", "curse_a" },
                        { "type", "cursedPickup" },
                        { "x", 100.0 },
                        { "y", 300.0 },
                        { "w", 50.0 },
                        { "h", 50.0 },
                        { "effectId", "cursed" },
                        { "respawnSeconds", 1.0 },
                        { "radius", 30.0 },
                        { "state", "available" },
                        { "visualStates", {
                            { "available", Json::array({ Json{
                                { "atlasId", "it_atlas_001" },
                                { "assetId", "skull" },
                                { "layer", "decorFront" },
                                { "alpha", 0.25 },
                                { "pickupPresentation", false }
                            } }) },
                            { "collected", Json::array() }
                        } }
                    },
                    Json{
                        { "id", "shield_while_cursed" },
                        { "type", "shieldPickup" },
                        { "x", 300.0 },
                        { "y", 300.0 },
                        { "w", 96.0 },
                        { "h", 96.0 },
                        { "effectId", "shield" },
                        { "respawnSeconds", 60.0 },
                        { "radius", 30.0 },
                        { "state", "available" },
                        { "visualStates", { { "available", Json::array() }, { "collected", Json::array() } } }
                    },
                    Json{
                        { "id", "curse_b" },
                        { "type", "cursedPickup" },
                        { "x", 500.0 },
                        { "y", 300.0 },
                        { "w", 50.0 },
                        { "h", 50.0 },
                        { "effectId", "cursed" },
                        { "respawnSeconds", 1.0 },
                        { "radius", 30.0 },
                        { "state", "available" },
                        { "visualStates", { { "available", Json::array() }, { "collected", Json::array() } } }
                    }
                }) }
            };
            check(applyEditorLevelToWorld(cursedPickupState, cursedLevel),
                "synthetic native Cursed pickup fixture applies");
            const auto cursedSkullVisual = std::find_if(
                cursedPickupState.world.visuals.begin(), cursedPickupState.world.visuals.end(),
                [](const FWorldVisual& visual) { return visual.entityId == "curse_a" && visual.assetId == "skull"; });
            check(cursedSkullVisual != cursedPickupState.world.visuals.end()
                    && std::abs(cursedSkullVisual->alpha - 0.25) < 0.000001,
                "native Cursed skull begins at quarter opacity");
            check(cursedSkullVisual != cursedPickupState.world.visuals.end() && !cursedSkullVisual->pickupPresentation,
                "native Cursed skull opts out of generic pickup bobbing/pulsing");
            const auto authoredCursePickup = std::find_if(
                cursedPickupState.pickups.begin(), cursedPickupState.pickups.end(),
                [](const FPickupState& pickup) { return pickup.id == "curse_a"; });
            check(authoredCursePickup != cursedPickupState.pickups.end()
                    && std::abs(authoredCursePickup->respawnSeconds - 1.0) < 0.000001,
                "native Cursed skull runtime pickup retains the one-second respawn");
            cursedPickupState.story.portalIntro.reset();
            cursedPickupState.story.portalExit.reset();
            cursedPickupState.story.mailboxEvents.clear();
            cursedPickupState.story.mailboxEventIndex = NO_MAILBOX_EVENT_INDEX;

            if (curseFlight.has_value() && curseOverdrive.has_value())
            {
                for (const FPowerUpEffectDefinition* definition : { &*curseFlight, &*curseOverdrive })
                {
                    FActivePowerUpEffectState effect;
                    effect.id = definition->id;
                    effect.definition = *definition;
                    effect.remainingSeconds = definition->durationSeconds;
                    effect.activatedAt = cursedPickupState.clock.time;
                    cursedPickupState.statusEffects.active[effect.id] = effect;
                }
            }
            cursedPickupState.equipment.rocket.state = "flight";
            cursedPickupState.equipment.rocket.attachedBoosting = true;
            cursedPickupState.player.lungeCharging = true;
            cursedPickupState.player.lungeChargeTime = 0.1;
            cursedPickupState.player.bodySlamCommitted = true;
            cursedPickupState.player.x = 100.0;
            cursedPickupState.player.y = 300.0;
            stepSimulation(cursedPickupState, createInputFrame(), MAX_SIM_DT);
            check(activePowerUpEffect(cursedPickupState.statusEffects.active, POWER_UP_EFFECT_IDS::CURSED).has_value(),
                "touching a native cursed skull activates Cursed");
            const auto cursedPickupEvent = std::find_if(
                cursedPickupState.debug.lastEvents.rbegin(), cursedPickupState.debug.lastEvents.rend(),
                [](const FDebugEvent& event)
                {
                    return event.type == "POWER_UP_PICKUP_COLLECTED";
                });
            check(cursedPickupEvent != cursedPickupState.debug.lastEvents.rend()
                    && cursedPickupEvent->effectId == POWER_UP_EFFECT_IDS::CURSED,
                "native Cursed pickup event carries the cursed effect identity for audio filtering");
            check(!activePowerUpEffect(cursedPickupState.statusEffects.active, POWER_UP_EFFECT_IDS::FLIGHT).has_value(),
                "native Cursed cancels active Flight");
            check(!activePowerUpEffect(cursedPickupState.statusEffects.active, POWER_UP_EFFECT_IDS::OVERDRIVE).has_value(),
                "native Cursed cancels other temporary power-ups");
            check(!cursedPickupState.equipment.rocket.attachedBoosting,
                "native Cursed immediately cancels attached boost");
            check(cursedPickupState.equipment.rocket.state != "flight",
                "native Cursed exits Flight rocket state");
            check(!cursedPickupState.player.lungeCharging && !cursedPickupState.player.lungeActive,
                "native Cursed immediately cancels lunge state");
            check(!cursedPickupState.player.bodySlamCommitted,
                "native Cursed immediately cancels body slam commitment");
            const auto cursedSmokeCount = [](const FGameState& state)
            {
                return static_cast<std::size_t>(std::count_if(
                    state.effects.smokePuffs.begin(),
                    state.effects.smokePuffs.end(),
                    [](const FSmokePuffState& puff) { return puff.kind == "smokeParticle"; }));
            };
            const std::size_t curseSmokeAfterActivation = cursedSmokeCount(cursedPickupState);
            check(curseSmokeAfterActivation > 0,
                "entering native Cursed emits the destroyed-atlas-asset smoke effect");

            cursedPickupState.player.x = 700.0;
            cursedPickupState.player.y = 300.0;
            const auto cursePickupIt = std::find_if(
                cursedPickupState.pickups.begin(), cursedPickupState.pickups.end(),
                [](const FPickupState& pickup) { return pickup.id == "curse_a"; });
            if (cursePickupIt != cursedPickupState.pickups.end())
            {
                cursePickupIt->respawnTimer = MAX_SIM_DT * 0.5;
            }
            stepSimulation(cursedPickupState, createInputFrame(), MAX_SIM_DT);
            const auto respawnedCursePickupIt = std::find_if(
                cursedPickupState.pickups.begin(), cursedPickupState.pickups.end(),
                [](const FPickupState& pickup) { return pickup.id == "curse_a"; });
            check(respawnedCursePickupIt != cursedPickupState.pickups.end() && !respawnedCursePickupIt->collected,
                "native Cursed skull respawns normally when its timer elapses");
            const auto respawnedSkullVisual = std::find_if(
                cursedPickupState.world.visuals.begin(), cursedPickupState.world.visuals.end(),
                [](const FWorldVisual& visual) { return visual.entityId == "curse_a" && visual.assetId == "skull"; });
            check(respawnedSkullVisual != cursedPickupState.world.visuals.end()
                    && std::abs(respawnedSkullVisual->alpha - 0.25) < 0.000001,
                "respawned native Cursed skull retains quarter opacity");
            check(respawnedSkullVisual != cursedPickupState.world.visuals.end() && !respawnedSkullVisual->pickupPresentation,
                "respawned native Cursed skull remains static");

            cursedPickupState.player.x = 300.0;
            cursedPickupState.player.y = 300.0;
            stepSimulation(cursedPickupState, createInputFrame(), MAX_SIM_DT);
            const auto shieldPickupIt = std::find_if(
                cursedPickupState.pickups.begin(), cursedPickupState.pickups.end(),
                [](const FPickupState& pickup) { return pickup.id == "shield_while_cursed"; });
            check(shieldPickupIt != cursedPickupState.pickups.end() && shieldPickupIt->collected,
                "native temporary power-up touched while cursed is consumed");
            check(!activePowerUpEffect(cursedPickupState.statusEffects.active, POWER_UP_EFFECT_IDS::SHIELD).has_value(),
                "native temporary power-up touched while cursed does not activate");

            const auto shieldPickupEvent = std::find_if(
                cursedPickupState.debug.lastEvents.rbegin(), cursedPickupState.debug.lastEvents.rend(),
                [](const FDebugEvent& event)
                {
                    return event.type == "POWER_UP_PICKUP_COLLECTED";
                });
            check(shieldPickupEvent != cursedPickupState.debug.lastEvents.rend()
                    && shieldPickupEvent->effectId == POWER_UP_EFFECT_IDS::SHIELD,
                "ordinary native power-up pickup events retain their effect identity while Cursed is active");

            auto activeCurseIt = cursedPickupState.statusEffects.active.find(POWER_UP_EFFECT_IDS::CURSED);
            if (activeCurseIt != cursedPickupState.statusEffects.active.end())
            {
                activeCurseIt->second.remainingSeconds = 2.0;
            }
            cursedPickupState.player.x = 500.0;
            cursedPickupState.player.y = 300.0;
            stepSimulation(cursedPickupState, createInputFrame(), MAX_SIM_DT);
            const std::optional<FActivePowerUpEffectState> refreshedCurse = activePowerUpEffect(
                cursedPickupState.statusEffects.active, POWER_UP_EFFECT_IDS::CURSED);
            check(refreshedCurse.has_value() && refreshedCurse->remainingSeconds.has_value()
                    && refreshedCurse->remainingSeconds.value() > 9.9,
                "another native cursed skull refreshes Cursed to essentially ten seconds");
            check(cursedSmokeCount(cursedPickupState) == curseSmokeAfterActivation,
                "refreshing already-active native Cursed does not emit another transformation smoke burst");

            const auto addCurse = [&](FGameState& state, double remaining = 10.0)
            {
                FActivePowerUpEffectState effect;
                effect.id = cursed->id;
                effect.definition = *cursed;
                effect.remainingSeconds = remaining;
                effect.activatedAt = state.clock.time;
                state.statusEffects.active[effect.id] = effect;
            };

            FGameState cursedActionState = createInitialGameState();
            cursedActionState.story.portalIntro.reset();
            cursedActionState.story.portalExit.reset();
            cursedActionState.story.mailboxEvents.clear();
            cursedActionState.story.mailboxEventIndex = NO_MAILBOX_EVENT_INDEX;
            addCurse(cursedActionState);
            cursedActionState.player.onGround = true;
            cursedActionState.player.wasOnGround = true;
            FInputFrame cursedJump = createInputFrame();
            cursedJump.jumpPressed = true;
            cursedJump.jumpHeld = true;
            stepSimulation(cursedActionState, cursedJump, MAX_SIM_DT);
            check(cursedActionState.player.vy < 0.0, "native Cursed retains the ordinary grounded jump");
            FInputFrame cursedRelease = createInputFrame();
            cursedRelease.jumpReleased = true;
            stepSimulation(cursedActionState, cursedRelease, MAX_SIM_DT);
            FInputFrame cursedSecondJump = createInputFrame();
            cursedSecondJump.jumpPressed = true;
            cursedSecondJump.jumpHeld = true;
            stepSimulation(cursedActionState, cursedSecondJump, MAX_SIM_DT);
            check(!cursedActionState.equipment.rocket.attachedBoosting,
                "native Cursed blocks attached boost/double jump");

            const std::size_t projectilesBefore = cursedActionState.projectiles.size();
            FInputFrame cursedFire = createInputFrame();
            cursedFire.weaponPressed = true;
            stepSimulation(cursedActionState, cursedFire, MAX_SIM_DT);
            check(cursedActionState.projectiles.size() == projectilesBefore,
                "native Cursed blocks rocket fire");

            cursedActionState.player.y = 420.0;
            cursedActionState.player.vy = cursedActionState.tuning.fallDamageSafeImpactSpeed + 150.0;
            cursedActionState.player.onGround = false;
            cursedActionState.player.wasOnGround = false;
            cursedActionState.player.airborneTime = 1.0;
            FInputFrame cursedDown = createInputFrame();
            cursedDown.dropHeld = true;
            stepSimulation(cursedActionState, cursedDown, MAX_SIM_DT);
            check(!cursedActionState.player.bodySlamCommitted, "native Cursed blocks body slam");

            cursedActionState.player.y = 600.0;
            cursedActionState.player.vx = 0.0;
            cursedActionState.player.vy = 0.0;
            cursedActionState.player.onGround = true;
            cursedActionState.player.wasOnGround = true;
            FInputFrame cursedLunge = createInputFrame();
            cursedLunge.lungePressed = true;
            cursedLunge.lungeHeld = true;
            stepSimulation(cursedActionState, cursedLunge, MAX_SIM_DT);
            check(!cursedActionState.player.lungeCharging && !cursedActionState.player.lungeActive,
                "native Cursed blocks lunge");

            FGameState cursedExpiryState = createInitialGameState();
            addCurse(cursedExpiryState, MAX_SIM_DT * 0.5);
            stepSimulation(cursedExpiryState, createInputFrame(), MAX_SIM_DT);
            check(!activePowerUpEffect(cursedExpiryState.statusEffects.active, POWER_UP_EFFECT_IDS::CURSED).has_value(),
                "native Cursed expires normally");
            check(cursedSmokeCount(cursedExpiryState) > 0,
                "naturally leaving native Cursed emits the destroyed-atlas-asset smoke effect");

            FGameState cursedResetState = createInitialGameState();
            addCurse(cursedResetState);
            resetPlayer(cursedResetState, "cursedDeathResetTest");
            check(!activePowerUpEffect(cursedResetState.statusEffects.active, POWER_UP_EFFECT_IDS::CURSED).has_value(),
                "native player reset clears Cursed");
            check(cursedSmokeCount(cursedResetState) == 0,
                "native death/reset clearing Cursed does not add transformation smoke on top of death presentation");
        }

        const std::optional<FPowerUpEffectDefinition> flight = powerUpEffectDefinition(POWER_UP_EFFECT_IDS::FLIGHT);
        check(flight.has_value(), "rocket-fuel Flight definition exists");
        if (!flight.has_value())
        {
            return;
        }

        check(flight->label == "Flight", "rocket fuel names its timed mode Flight");
        check(std::abs(flight->durationSeconds - 30.0) < 0.000001, "Flight lasts thirty seconds");
        check(flight->stacking == POWER_UP_STACKING_RULES::REFRESH, "collecting more rocket fuel refreshes Flight");
        check(flight->hud.iconFrame == "rocket_fuel_canister", "Flight keeps the rocket-fuel canister HUD icon");
        const std::optional<FPowerUpPickupState> flightPickup = normalizePowerUpPickup(Json{ { "effectId", POWER_UP_EFFECT_IDS::FLIGHT } });
        check(flightPickup.has_value() && std::abs(flightPickup->worldScale - 1.2) < 0.000001, "Flight pickups use sixty percent of their former double world scale");
        check(std::abs(flight->hud.priority - 190.0) < 0.000001, "Flight retains its legacy HUD priority metadata");
        check(std::abs(flight->rocket.launchFuelCostMultiplier - 1.0) < 0.000001, "Flight does not discount projectile fuel cost");

        const std::optional<FPowerUpEffectDefinition> wrench = powerUpEffectDefinition(POWER_UP_EFFECT_IDS::WRENCH_DART);
        const std::optional<FPowerUpEffectDefinition> shield = powerUpEffectDefinition(POWER_UP_EFFECT_IDS::SHIELD);
        const std::optional<FPowerUpEffectDefinition> overdrive = powerUpEffectDefinition(POWER_UP_EFFECT_IDS::OVERDRIVE);
        if (wrench.has_value() && shield.has_value() && overdrive.has_value())
        {
            check(std::abs(wrench->durationSeconds - 25.0) < 0.000001, "Wrench effects last twenty-five seconds");
            check(std::abs(shield->durationSeconds - 10.0) < 0.000001, "Shield lasts ten seconds");
            check(std::abs(overdrive->durationSeconds - 25.0) < 0.000001, "Overdrive lasts twenty-five seconds");
            std::unordered_map<std::string, FActivePowerUpEffectState> active;
            for (const FPowerUpEffectDefinition* definition : { &*wrench, &*flight, &*shield, &*overdrive })
            {
                FActivePowerUpEffectState effect;
                effect.id = definition->id;
                effect.definition = *definition;
                effect.remainingSeconds = definition->durationSeconds;
                active[effect.id] = effect;
            }
            active[wrench->id].remainingSeconds = 12.0;
            active[flight->id].remainingSeconds = 40.0;
            active[shield->id].remainingSeconds = 7.0;
            active[overdrive->id].remainingSeconds = 15.0;
            check(shortestRemainingActivePowerUpEffect(active)->id == shield->id,
                "Power HUD selects the shortest seven-second Shield timer regardless of legacy priority metadata");
            active.erase(shield->id);
            check(shortestRemainingActivePowerUpEffect(active)->id == wrench->id,
                "Power HUD selects the twelve-second wrench ahead of longer Overdrive and Flight timers");
            active.erase(wrench->id);
            check(shortestRemainingActivePowerUpEffect(active)->id == overdrive->id,
                "Power HUD selects the fifteen-second Overdrive ahead of the longer Flight timer");
        }

        Json levelJson;
        std::string error;
        check(loadJsonAsset("levels/level_t04.json", levelJson, error),
            "load Level 800 rocket-fuel fixture" + (error.empty() ? std::string() : (": " + error)));
        if (!levelJson.empty())
        {
            const Json* highFuel = nullptr;
            if (const Json* entities = jsonArrayField(levelJson, "entities"))
            {
                for (const Json& entity : *entities)
                {
                    if (jsonStringOr(entity, "id") == "flight_fuel_001")
                    {
                        highFuel = &entity;
                        break;
                    }
                }
            }
            check(highFuel != nullptr, "Level 800 contains the high rocket-fuel pickup");
            if (highFuel)
            {
                check(jsonStringOr(*highFuel, "effectId") == POWER_UP_EFFECT_IDS::FLIGHT,
                    "Level 800 rocket fuel explicitly grants Flight");
                check(highFuel->find("durationSeconds") == highFuel->end(),
                    "authored Flight fuel inherits the built-in duration instead of freezing it into level JSON");
                check(jsonNumberOr(*highFuel, "y", 9999.0) < 200.0,
                    "Level 800 rocket fuel is placed high in the level");
                check(std::abs(jsonNumberOr(*highFuel, "w") - 32.4) < 0.000001
                    && std::abs(jsonNumberOr(*highFuel, "h") - 54.0) < 0.000001
                    && std::abs(jsonNumberOr(*highFuel, "radius") - 13.2) < 0.000001,
                    "Level 800 rocket fuel uses sixty percent of its former authored size");
            }

            FGameState loaded = createInitialGameState();
            check(applyEditorLevelToWorld(loaded, levelJson), "Level 800 applies with Flight fuel");
            const auto runtimeFuel = std::find_if(loaded.pickups.begin(), loaded.pickups.end(), [](const FPickupState& pickup)
            {
                return pickup.id == "flight_fuel_001";
            });
            check(runtimeFuel != loaded.pickups.end(), "Level 800 Flight fuel becomes a runtime pickup");
            if (runtimeFuel != loaded.pickups.end())
            {
                check(runtimeFuel->kind == "powerUp", "fuel entities normalize to timed power-ups");
                check(runtimeFuel->powerUp.has_value() && runtimeFuel->powerUp->effectId == POWER_UP_EFFECT_IDS::FLIGHT,
                    "fuel entities normalize to the Flight effect");
                check(runtimeFuel->powerUp.has_value() && std::abs(runtimeFuel->powerUp->effect.durationSeconds - flight->durationSeconds) < 0.000001,
                    "Flight fuel without an authored duration inherits the built-in runtime duration");
                check(std::abs(runtimeFuel->width - 32.4) < 0.000001
                    && std::abs(runtimeFuel->height - 54.0) < 0.000001
                    && std::abs(runtimeFuel->radius - 13.2) < 0.000001,
                    "runtime Flight fuel retains the reduced authored dimensions and collection radius");
                check(runtimeFuel->powerUp.has_value() && std::abs(runtimeFuel->powerUp->worldScale - 1.2) < 0.000001,
                    "runtime Flight fallback presentation uses the reduced world scale");
            }
        }

        FGameState presentationState = createInitialGameState();
        const Json pickupPresentationLevel = {
            { "levelId", "pickup_presentation_test" },
            { "world", { { "bounds", { { "x", 0.0 }, { "y", 0.0 }, { "w", 1000.0 }, { "h", 700.0 } } } } },
            { "testPlayerStart", { { "x", 80.0 }, { "y", 500.0 } } },
            { "placements", Json::array() },
            { "entities", Json::array({
                Json{
                    { "id", "fuel_test" }, { "type", "fuel" },
                    { "x", 400.0 }, { "y", 360.0 }, { "w", 32.4 }, { "h", 54.0 },
                    { "radius", 13.2 }, { "effectId", "flight" }, { "state", "available" },
                    { "visualStates", { { "available", Json::array({ Json{ { "atlasId", "it_atlas_001" }, { "assetId", "rocket_fuel_canister" }, { "layer", "decorFront" } } }) } } }
                },
                Json{
                    { "id", "fuel_upgrade_test" }, { "type", "fuelUpgrade" },
                    { "x", 500.0 }, { "y", 360.0 }, { "w", 72.0 }, { "h", 86.0 },
                    { "pickupKind", "fuelUpgrade" }, { "upgradeKind", "fuelUpgrade" }, { "state", "available" },
                    { "visualStates", { { "available", Json::array({ Json{ { "atlasId", "it_atlas_001" }, { "assetId", "herb_blue" }, { "layer", "decorFront" } } }) } } }
                },
                Json{
                    { "id", "treasure_test" }, { "type", "treasureChest" },
                    { "x", 300.0 }, { "y", 500.0 }, { "w", 68.0 }, { "h", 80.0 }, { "state", "openLoot" },
                    { "visualStates", { { "openLoot", Json::array({ Json{ { "atlasId", "it_atlas_001" }, { "assetId", "chest_open_loot" }, { "layer", "decorFront" } } }) } } }
                }
            }) }
        };
        check(applyEditorLevelToWorld(presentationState, pickupPresentationLevel),
            "pickup-presentation fixture applies");
        const auto fuelVisual = std::find_if(presentationState.world.visuals.begin(), presentationState.world.visuals.end(), [](const FWorldVisual& visual)
        {
            return visual.entityId == "fuel_test" && visual.assetId == "rocket_fuel_canister";
        });
        const auto upgradeVisual = std::find_if(presentationState.world.visuals.begin(), presentationState.world.visuals.end(), [](const FWorldVisual& visual)
        {
            return visual.entityId == "fuel_upgrade_test" && visual.assetId == "herb_blue";
        });
        const auto chestVisual = std::find_if(presentationState.world.visuals.begin(), presentationState.world.visuals.end(), [](const FWorldVisual& visual)
        {
            return visual.entityId == "treasure_test" && visual.assetId == "chest_open_loot";
        });
        check(fuelVisual != presentationState.world.visuals.end() && fuelVisual->pickupPresentation,
            "SDL atlas-backed rocket fuel opts into pickup hovering and pulsing");
        check(upgradeVisual != presentationState.world.visuals.end() && upgradeVisual->pickupPresentation,
            "SDL permanent-upgrade visuals opt into pickup hovering and pulsing");
        check(chestVisual != presentationState.world.visuals.end() && !chestVisual->pickupPresentation,
            "SDL treasure chests remain grounded and unpulsed");

        if (fuelVisual != presentationState.world.visuals.end())
        {
            check(!worldVisualHiddenByCollectedPickup(presentationState, *fuelVisual),
                "available atlas-backed rocket fuel remains visible in SDL");
            const auto fuelPickup = std::find_if(presentationState.pickups.begin(), presentationState.pickups.end(), [](const FPickupState& pickup)
            {
                return pickup.id == "fuel_test";
            });
            check(fuelPickup != presentationState.pickups.end(),
                "pickup-presentation fixture creates the fuel runtime");
            if (fuelPickup != presentationState.pickups.end())
            {
                fuelPickup->collected = true;
                check(worldVisualHiddenByCollectedPickup(presentationState, *fuelVisual),
                    "collected atlas-backed rocket fuel is hidden from SDL world-visual passes");
            }
        }
        if (chestVisual != presentationState.world.visuals.end())
        {
            check(!worldVisualHiddenByCollectedPickup(presentationState, *chestVisual),
                "non-pickup world visuals are unaffected by collected-pickup visibility filtering");
        }

        FGameState state = createInitialGameState();
        state.story.portalIntro.reset();
        state.story.portalExit.reset();
        state.enemies.clear();
        state.targets.clear();
        state.pickups.clear();
        state.projectiles.clear();
        state.world.autoSpawnEnemies.enabled = false;
        state.world.enemySpawners.clear();
        state.world.solids.clear();
        state.world.segments.clear();
        state.world.collisionPolygons.clear();
        state.world.caveKillBoundary.enabled = false;
        state.world.bounds = { -2000.0, -2000.0, 4000.0, 4000.0 };
        state.player.x = 300.0;
        state.player.y = 600.0;
        state.player.spawnX = 300.0;
        state.player.spawnY = 600.0;
        state.player.vx = 0.0;
        state.player.vy = 0.0;
        state.player.onGround = false;
        state.player.wasOnGround = false;
        state.fuel.amount = 10.0;
        state.fuel.rechargeDelayTimer = 10.0;
        state.fuel.rechargeLatched = false;
        state.equipment.rocket.state = "flight";
        state.equipment.rocket.attachedBoosting = false;

        FActivePowerUpEffectState activeFlight;
        activeFlight.id = flight->id;
        activeFlight.definition = *flight;
        activeFlight.remainingSeconds = flight->durationSeconds;
        activeFlight.sourceId = "flight_test";
        state.statusEffects.active[activeFlight.id] = activeFlight;

        const double passiveRecoveryRate = state.tuning.attachedBoostDrainRate
            * FLIGHT_PASSIVE_FUEL_RECOVERY_DRAIN_FACTOR;
        stepSimulation(state, createInputFrame(), MAX_SIM_DT);
        check(std::abs(state.player.vy) < 0.000001, "Flight hovers steadily without vertical input");
        check(std::abs(state.fuel.amount - (10.0 + passiveRecoveryRate * MAX_SIM_DT)) < 0.0001,
            "Flight passively recovers fuel while airborne and inside recharge delay");
        check(!state.equipment.rocket.attachedBoosting, "Flight does not use fuel-draining attached boost state");
        check(state.equipment.rocket.state == "flight", "mounted rocket exposes Flight presentation state");

        // Keep vertical-governor coverage isolated from horizontal idle cruise.
        state.tuning.flightIdleHorizontalSpeedFactor = 0.0;
        FInputFrame up = createInputFrame();
        up.jumpHeld = true;
        stepSimulation(state, up, MAX_SIM_DT);
        check(state.player.vy < 0.0 && state.player.vy > -state.tuning.flightVerticalSpeed * 1.5,
            "Up eases into Flight climb rather than snapping to full speed");
        for (std::int32_t tick = 0; tick < 45; ++tick)
        {
            stepSimulation(state, up, MAX_SIM_DT);
        }
        check(std::abs(state.player.vy + state.tuning.flightVerticalSpeed * 1.5) < 0.0001,
            "sustained Up reaches governed Flight climb speed");

        const double climbSpeed = state.player.vy;
        for (std::int32_t tick = 0; tick < 10; ++tick)
        {
            stepSimulation(state, createInputFrame(), MAX_SIM_DT);
        }
        check(std::abs(state.player.vy) < std::abs(climbSpeed), "releasing Up eases back toward hover");
        for (std::int32_t tick = 0; tick < 35; ++tick)
        {
            stepSimulation(state, createInputFrame(), MAX_SIM_DT);
        }
        check(std::abs(state.player.vy) < 0.0001, "released Flight controls settle into steady hover");

        FInputFrame down = createInputFrame();
        down.dropHeld = true;
        for (std::int32_t tick = 0; tick < 10; ++tick)
        {
            stepSimulation(state, down, MAX_SIM_DT);
        }
        check(state.player.vy > 0.0 && state.player.vy < state.tuning.flightVerticalSpeed * 1.5,
            "Down eases into Flight descent");
        for (std::int32_t tick = 0; tick < 35; ++tick)
        {
            stepSimulation(state, down, MAX_SIM_DT);
        }
        check(std::abs(state.player.vy - state.tuning.flightVerticalSpeed * 1.5) < 0.0001,
            "sustained Down reaches governed Flight descent speed");

        state.tuning.flightIdleHorizontalSpeedFactor = 0.6666667;
        state.player.vy = 0.0;
        state.player.vx = 0.0;
        state.player.facing = 1;
        const double flightHorizontalMax = state.tuning.maxRunSpeed * 1.5;
        const double idleFlightHorizontalSpeed = flightHorizontalMax * state.tuning.flightIdleHorizontalSpeedFactor;
        stepSimulation(state, createInputFrame(), MAX_SIM_DT);
        check(std::abs(state.player.vx - state.tuning.groundAcceleration * MAX_SIM_DT) < 0.0001,
            "neutral Flight accelerates in facing direction with running acceleration");
        for (std::int32_t tick = 0; tick < 30; ++tick)
        {
            stepSimulation(state, createInputFrame(), MAX_SIM_DT);
        }
        check(std::abs(state.player.vx - idleFlightHorizontalSpeed) < 0.0001,
            "neutral Flight settles at configured fraction of maximum Flight speed");
        FInputFrame right = createInputFrame();
        right.moveRight = true;
        stepSimulation(state, right, MAX_SIM_DT);
        check(state.player.vx > idleFlightHorizontalSpeed,
            "holding facing direction accelerates beyond idle Flight cruise");
        state.player.vx = flightHorizontalMax;
        stepSimulation(state, right, MAX_SIM_DT);
        check(std::abs(state.player.vx - flightHorizontalMax) < 0.0001,
            "Flight steering permits fifty percent above the normal horizontal speed cap");

        state.player.vx = idleFlightHorizontalSpeed;
        FInputFrame left = createInputFrame();
        left.moveLeft = true;
        stepSimulation(state, left, MAX_SIM_DT);
        check(state.player.facing == -1 && state.player.vx > 0.0 && state.player.vx < idleFlightHorizontalSpeed,
            "opposite Flight input turns immediately while first overcoming existing inertia");
        const double reversedVelocity = state.player.vx;
        stepSimulation(state, createInputFrame(), MAX_SIM_DT);
        check(state.player.vx < reversedVelocity,
            "neutral Flight after a reversal tap continues accelerating toward new facing direction");

        state.tuning.flightIdleHorizontalSpeedFactor = 0.0;
        state.player.vx = state.tuning.groundAcceleration * MAX_SIM_DT;
        stepSimulation(state, createInputFrame(), MAX_SIM_DT);
        const double expectedLegacyCoast = std::max(
            0.0,
            (state.tuning.groundAcceleration - state.tuning.groundFriction) * MAX_SIM_DT);
        check(std::abs(state.player.vx - expectedLegacyCoast) < 0.0001,
            "zero idle Flight factor preserves legacy neutral-input friction-to-rest behavior");
        state.tuning.flightIdleHorizontalSpeedFactor = 0.6666667;
        state.player.vx = 0.0;

        FWorldSegment flightGround;
        flightGround.id = "flight_ground_test";
        flightGround.kind = "blockable";
        flightGround.x1 = -1000.0;
        flightGround.y1 = 600.0;
        flightGround.x2 = 1000.0;
        flightGround.y2 = 600.0;
        state.world.segments.push_back(flightGround);
        state.player.x = 300.0;
        state.player.y = 600.0;
        state.player.vx = 0.0;
        state.player.vy = 0.0;
        state.player.onGround = true;
        state.player.wasOnGround = true;
        state.player.supportId = "flight_ground_test";
        state.tuning.attachedBoostSmokePuffDownSpeed = 0.0;
        state.tuning.attachedBoostSmokePuffSideSpeed = 0.0;
        state.tuning.attachedBoostSmokePuffSpeedJitter = 0.0;
        state.effects.smokePuffs.clear();
        state.equipment.rocket.attachedSmokeTimer = 0.0;
        stepSimulation(state, createInputFrame(), MAX_SIM_DT);
        check(std::abs(state.player.vx) < 0.0001,
            "grounded Flight does not apply neutral-input forward cruise");
        check(state.player.onGround,
            "grounded Flight remains supported while neutral horizontal input leaves it at rest");
        const auto groundedFlightSmoke = std::find_if(
            state.effects.smokePuffs.begin(),
            state.effects.smokePuffs.end(),
            [](const FSmokePuffState& puff) { return puff.kind == "attachedRocketSmokePuff"; });
        check(groundedFlightSmoke != state.effects.smokePuffs.end(),
            "grounded Flight retains the attached smoke-and-spark idle exhaust");
        if (groundedFlightSmoke != state.effects.smokePuffs.end())
        {
            check(std::abs(groundedFlightSmoke->lifetime - 0.14) < 0.000001,
                "grounded Flight smoke uses fifty percent of the normal attached-smoke lifetime");
        }
        FInputFrame groundedRight = createInputFrame();
        groundedRight.moveRight = true;
        stepSimulation(state, groundedRight, MAX_SIM_DT);
        check(state.player.vx > 0.0,
            "grounded Flight still accepts ordinary horizontal walking input");
        check(state.player.onGround,
            "grounded Flight walking remains attached to its support");

        state.effects.smokePuffs.clear();
        state.equipment.rocket.attachedSmokeTimer = 0.0;
        state.player.y = 500.0;
        state.player.vx = 0.0;
        state.player.vy = 0.0;
        state.player.onGround = false;
        state.player.wasOnGround = false;
        state.player.supportId.clear();
        stepSimulation(state, createInputFrame(), MAX_SIM_DT);
        const auto airborneFlightSmoke = std::find_if(
            state.effects.smokePuffs.begin(),
            state.effects.smokePuffs.end(),
            [](const FSmokePuffState& puff) { return puff.kind == "attachedRocketSmokePuff"; });
        check(airborneFlightSmoke != state.effects.smokePuffs.end(),
            "airborne Flight continues emitting attached rocket smoke");
        if (airborneFlightSmoke != state.effects.smokePuffs.end())
        {
            check(std::abs(airborneFlightSmoke->lifetime - 0.28) < 0.000001,
                "airborne Flight retains the normal attached-smoke lifetime");
        }

        state.player.vy = 0.0;
        state.fuel.amount = 100.0;
        state.fuel.rechargeDelayTimer = 10.0;
        FInputFrame fire = createInputFrame();
        fire.weaponPressed = true;
        stepSimulation(state, fire, MAX_SIM_DT);
        const double expectedFuel = 100.0 - state.tuning.rocketLaunchCost + passiveRecoveryRate * MAX_SIM_DT;
        check(std::abs(state.fuel.amount - expectedFuel) < 0.0001,
            "Flight keeps full shooting cost while passive recovery permits frequent but finite fire");
        check(state.projectiles.size() == 1, "Flight launches one standard rocket without a wrench");
        if (!state.projectiles.empty())
        {
            check(std::abs(state.projectiles.front().projectileSpeed - 750.0) < 0.0001, "Flight scales standard rocket speed from 500 to 750 px/s");
            check(std::abs(state.projectiles.front().lifetime - state.tuning.rocketProjectileUnwrenchedMaxTravelDistance / state.projectiles.front().projectileSpeed) < 0.0001, "unwrenched rocket lifetime derives from its 400 px default travel distance");
            check(std::abs(state.projectiles.front().projectileSpeed * state.projectiles.front().lifetime - 400.0) < 0.0001, "unwrenched rocket nominal travel distance is 400 px by default");
        }

        FGameState standardRangeTalentState = createInitialGameState();
        standardRangeTalentState.playerProgression.standardRocketRangeUnlocked = true;
        applyPlayerProgression(standardRangeTalentState, standardRangeTalentState.playerProgression);
        FInputFrame standardRangeTalentFire = createInputFrame();
        standardRangeTalentFire.weaponPressed = true;
        stepSimulation(standardRangeTalentState, standardRangeTalentFire, MAX_SIM_DT);
        check(standardRangeTalentState.projectiles.size() == 1,
            "Standard rocket range talent still launches one unwrenched rocket");
        if (!standardRangeTalentState.projectiles.empty())
        {
            const FProjectileState& projectile = standardRangeTalentState.projectiles.front();
            check(std::abs(projectile.projectileSpeed * projectile.lifetime
                    - standardRangeTalentState.tuning.rocketProjectileUnwrenchedMaxTravelDistance * 1.25) < 0.0001,
                "Standard rocket range talent extends the unwrenched rocket from 400 px to 500 px");
        }

        FGameState durationScaledRocketState = createInitialGameState();
        durationScaledRocketState.tuning.rocketDurationPercent = 150.0;
        FInputFrame durationScaledFire = createInputFrame();
        durationScaledFire.weaponPressed = true;
        stepSimulation(durationScaledRocketState, durationScaledFire, MAX_SIM_DT);
        check(durationScaledRocketState.projectiles.size() == 1,
            "rocket duration tuning still launches one standard rocket");
        if (!durationScaledRocketState.projectiles.empty())
        {
            const FProjectileState& projectile = durationScaledRocketState.projectiles.front();
            check(std::abs(projectile.projectileSpeed - durationScaledRocketState.tuning.rocketProjectileSpeed) < 0.0001,
                "rocket duration tuning does not change projectile speed");
            check(std::abs(projectile.projectileSpeed * projectile.lifetime
                    - durationScaledRocketState.tuning.rocketProjectileUnwrenchedMaxTravelDistance * 1.5) < 0.0001,
                "150 percent rocket duration extends standard rocket reach by fifty percent");
        }

        const std::optional<FPowerUpEffectDefinition> durationBoomerangDefinition = powerUpEffectDefinition(POWER_UP_EFFECT_IDS::WRENCH_BOOMERANG);
        check(durationBoomerangDefinition.has_value(), "magenta Boomerang definition exists for rocket-duration scaling coverage");
        if (durationBoomerangDefinition.has_value())
        {
            FGameState durationBoomerangState = createInitialGameState();
            durationBoomerangState.tuning.rocketDurationPercent = 200.0;
            FActivePowerUpEffectState activeBoomerang;
            activeBoomerang.id = durationBoomerangDefinition->id;
            activeBoomerang.definition = *durationBoomerangDefinition;
            activeBoomerang.remainingSeconds = durationBoomerangDefinition->durationSeconds;
            activeBoomerang.sourceId = "duration_scaled_boomerang_test";
            durationBoomerangState.statusEffects.active[activeBoomerang.id] = activeBoomerang;
            stepSimulation(durationBoomerangState, durationScaledFire, MAX_SIM_DT);
            check(durationBoomerangState.projectiles.size() == 1,
                "rocket duration tuning still launches one magenta Boomerang rocket");
            if (!durationBoomerangState.projectiles.empty())
            {
                check(std::abs(durationBoomerangState.projectiles.front().boomerangOutboundTimer
                        - durationBoomerangState.tuning.rocketProjectileUpLaunchSeconds * 2.0) <= MAX_SIM_DT + 0.0001,
                    "rocket duration tuning scales the no-target Boomerang outbound reach as well as total lifetime");
            }
        }
        if (!state.projectiles.empty())
        {
            check(std::abs(
                    state.projectiles.front().damage
                    - state.tuning.rocketProjectileDamage * (state.tuning.rocketDamagePercent / 100.0)) < 0.0001,
                "Flight preserves the direct damage of a standard rocket");
            check(std::abs(
                    state.projectiles.front().secondaryEnemySplashDamage
                    - state.tuning.standardRocketSecondarySplashDamage) < 0.0001,
                "Flight preserves the secondary splash damage of a standard rocket");
        }

        state.playerProgression.standardRocketRangeUnlocked = true;
        applyPlayerProgression(state, state.playerProgression);
        for (const std::string& wrenchEffectId : WRENCH_POWER_UP_EFFECT_IDS)
        {
            const std::optional<FPowerUpEffectDefinition> flightWrench = powerUpEffectDefinition(wrenchEffectId);
            check(flightWrench.has_value(), wrenchEffectId + " definition exists");
            if (flightWrench.has_value() && wrenchEffectId == POWER_UP_EFFECT_IDS::WRENCH_BIGBOMB)
            {
                check(std::abs(flightWrench->rocket.launchFuelCostMultiplier - 2.0) < 0.0001,
                    "red Bigbomb definition costs two standard rocket launches (60 fuel at current tuning)");
                check(std::abs(flightWrench->rocket.areaDamageRadiusWizardHeights - 2.0) < 0.0001,
                    "red Bigbomb definition uses a two-wizard-height blast radius");
            }
            if (!flightWrench.has_value())
            {
                continue;
            }

            state.projectiles.clear();
            state.fuel.amount = 100.0;
            FActivePowerUpEffectState activeWrench;
            activeWrench.id = flightWrench->id;
            activeWrench.definition = *flightWrench;
            activeWrench.remainingSeconds = flightWrench->durationSeconds;
            activeWrench.sourceId = "flight_wrench_test";
            state.statusEffects.active[activeWrench.id] = activeWrench;
            stepSimulation(state, fire, MAX_SIM_DT);
            check(
                state.projectiles.size() == static_cast<std::size_t>(flightWrench->rocket.projectileCount),
                "Flight with " + wrenchEffectId + " launches the authored projectile count");
            const double expectedWrenchSpeed = state.tuning.rocketProjectileSpeed * std::max(0.05, flightWrench->rocket.speedMultiplier) * 1.5;
            const double expectedWrenchDistance = state.tuning.rocketProjectileMaxTravelDistance * std::max(0.01, flightWrench->rocket.travelDistanceMultiplier);
            const double expectedWrenchLifetime = expectedWrenchDistance / expectedWrenchSpeed;
            for (const FProjectileState& projectile : state.projectiles)
            {
                check(std::abs(projectile.lifetime - expectedWrenchLifetime) < 0.0001,
                    wrenchEffectId + " rocket lifetime derives from its authored wrench travel distance");
                check(std::abs(projectile.projectileSpeed * projectile.lifetime - expectedWrenchDistance) < 0.0001,
                    wrenchEffectId + " rocket nominal travel distance matches its profile");
            }
            for (const FProjectileState& projectile : state.projectiles)
            {
                check(std::abs(
                        projectile.damage
                        - state.tuning.rocketProjectileDamage * (state.tuning.rocketDamagePercent / 100.0) * flightWrench->rocket.damageMultiplier) < 0.0001,
                    "Flight does not reduce " + wrenchEffectId + " rocket damage");
                check(std::abs(projectile.secondaryEnemySplashDamage) < 0.0001,
                    wrenchEffectId + " rockets still omit standard splash while flying");
                if (wrenchEffectId == POWER_UP_EFFECT_IDS::WRENCH_ROCKETPUNCH)
                {
                    check(std::abs(projectile.areaDamageRadius - std::max(1.0, state.player.height)) < 0.0001,
                        "Rocketpunch applies a one-wizard-height area-damage radius");
                    check(projectile.frameId == "rocket_projectile_rocketpunch",
                        "Rocketpunch uses the dedicated boxing-glove projectile frame");
                }
            }
            state.statusEffects.active.erase(activeWrench.id);
        }

        FGameState rocketpunchState = createInitialGameState();
        const std::optional<FPowerUpEffectDefinition> rocketpunchDefinition = powerUpEffectDefinition(POWER_UP_EFFECT_IDS::WRENCH_ROCKETPUNCH);
        check(rocketpunchDefinition.has_value(), "Rocketpunch definition exists for clean launch coverage");
        if (rocketpunchDefinition.has_value())
        {
            rocketpunchState.fuel.amount = 100.0;
            rocketpunchState.player.facing = 1;
            FActivePowerUpEffectState activeRocketpunch;
            activeRocketpunch.id = rocketpunchDefinition->id;
            activeRocketpunch.definition = *rocketpunchDefinition;
            activeRocketpunch.remainingSeconds = rocketpunchDefinition->durationSeconds;
            activeRocketpunch.sourceId = "rocketpunch_clean_launch_test";
            rocketpunchState.statusEffects.active[activeRocketpunch.id] = activeRocketpunch;
            const double fuelBeforeRocketpunch = rocketpunchState.fuel.amount;
            FInputFrame rocketpunchFire = createInputFrame();
            rocketpunchFire.weaponPressed = true;
            stepSimulation(rocketpunchState, rocketpunchFire, MAX_SIM_DT);
            check(rocketpunchState.projectiles.size() == 1,
                "Rocketpunch clean launch creates exactly one projectile");
            check(std::abs((fuelBeforeRocketpunch - rocketpunchState.fuel.amount) - 5.0) < 0.0001,
                "Rocketpunch clean launch costs exactly five fuel at default tuning");
            if (!rocketpunchState.projectiles.empty())
            {
                const FProjectileState& projectile = rocketpunchState.projectiles.front();
                check(std::abs(projectile.projectileSpeed - rocketpunchState.tuning.maxRunSpeed * 2.5) < 0.0001,
                    "Rocketpunch clean launch travels at 250 percent of Ignatius's normal running speed");
                check(projectile.vx > 0.0 && std::abs(projectile.vy) < 0.0001,
                    "Rocketpunch clean launch travels horizontally in wizard facing");
                check(std::abs(projectile.projectileSpeed * projectile.lifetime - 200.0) < 0.0001,
                    "Rocketpunch clean launch has 200 px nominal maximum range");
                check(std::abs(projectile.damage - 20.0) < 0.0001,
                    "Rocketpunch clean launch uses standard twenty-damage AoE");
                const double wizardHeight = std::max(1.0, rocketpunchState.tuning.wizardHeight > 0.0
                    ? rocketpunchState.tuning.wizardHeight
                    : rocketpunchState.player.height);
                check(std::abs(projectile.areaDamageRadius - wizardHeight) < 0.0001,
                    "Rocketpunch clean launch AoE radius equals one wizard height");
                check(std::abs(projectile.secondaryEnemySplashDamage) < 0.0001,
                    "Rocketpunch clean launch has no standard secondary splash");
                check(!projectile.homing,
                    "Rocketpunch clean launch remains a blind forward shot");
                check(projectile.frameId == "rocket_projectile_rocketpunch",
                    "Rocketpunch clean launch uses dedicated boxing-glove projectile art");
                check(projectile.wrenchGlowFrameId.empty(),
                    "Rocketpunch clean launch does not receive a colored rocket-outline sprite");
            }
        }

        FGameState speedScaledRocketState = createInitialGameState();
        speedScaledRocketState.playerProgression.speedLevel = 3;
        applyPlayerProgression(speedScaledRocketState, speedScaledRocketState.playerProgression, false, false);
        FInputFrame speedScaledFire = createInputFrame();
        speedScaledFire.weaponPressed = true;
        stepSimulation(speedScaledRocketState, speedScaledFire, MAX_SIM_DT);
        const double expectedSpeedScale = PLAYER_UPGRADE_MAX_SCALE
            - (PLAYER_UPGRADE_MAX_SCALE - 1.0) * std::pow(1.0 - PLAYER_UPGRADE_GAIN_FRACTION, 3.0);
        check(speedScaledRocketState.projectiles.size() == 1,
            "three permanent Speed Upgrades still launch one standard rocket");
        if (!speedScaledRocketState.projectiles.empty())
        {
            const FProjectileState& projectile = speedScaledRocketState.projectiles.front();
            check(std::abs(projectile.projectileSpeed - speedScaledRocketState.tuning.rocketProjectileSpeed * expectedSpeedScale) < 0.0001,
                "three permanent Speed Upgrades use the same diminishing scale for standard rocket velocity");
            check(std::abs(projectile.projectileSpeed * projectile.lifetime - speedScaledRocketState.tuning.rocketProjectileUnwrenchedMaxTravelDistance) < 0.0001,
                "speed-scaled standard rockets retain the authored 400 px default travel distance");
        }

        FGameState speedScaledWrenchState = createInitialGameState();
        speedScaledWrenchState.playerProgression.speedLevel = 3;
        applyPlayerProgression(speedScaledWrenchState, speedScaledWrenchState.playerProgression, false, false);
        const std::optional<FPowerUpEffectDefinition> dartDefinition = powerUpEffectDefinition(POWER_UP_EFFECT_IDS::WRENCH_DART);
        check(dartDefinition.has_value(), "cyan Dart definition exists for permanent speed scaling coverage");
        if (dartDefinition.has_value())
        {
            FActivePowerUpEffectState activeDart;
            activeDart.id = dartDefinition->id;
            activeDart.definition = *dartDefinition;
            activeDart.remainingSeconds = dartDefinition->durationSeconds;
            activeDart.sourceId = "speed_scaled_wrench_test";
            speedScaledWrenchState.statusEffects.active[activeDart.id] = activeDart;
            stepSimulation(speedScaledWrenchState, speedScaledFire, MAX_SIM_DT);
            check(speedScaledWrenchState.projectiles.size() == 1,
                "three permanent Speed Upgrades still launch one cyan Dart rocket");
            if (!speedScaledWrenchState.projectiles.empty())
            {
                const FProjectileState& projectile = speedScaledWrenchState.projectiles.front();
                const double expectedProjectileSpeed = speedScaledWrenchState.tuning.rocketProjectileSpeed
                    * std::max(0.05, dartDefinition->rocket.speedMultiplier)
                    * expectedSpeedScale;
                check(std::abs(projectile.projectileSpeed - expectedProjectileSpeed) < 0.0001,
                    "three permanent Speed Upgrades use the same diminishing scale for wrench rocket velocity");
                check(std::abs(projectile.projectileSpeed * projectile.lifetime - speedScaledWrenchState.tuning.rocketProjectileMaxTravelDistance * dartDefinition->rocket.travelDistanceMultiplier) < 0.0001,
                    "speed-scaled Dart rockets retain the authored 1800 px travel distance");
            }
        }

        FGameState combinedSpeedFlightState = createInitialGameState();
        combinedSpeedFlightState.playerProgression.speedLevel = 3;
        applyPlayerProgression(combinedSpeedFlightState, combinedSpeedFlightState.playerProgression, false, false);
        const std::optional<FPowerUpEffectDefinition> combinedFlightDefinition = powerUpEffectDefinition(POWER_UP_EFFECT_IDS::FLIGHT);
        check(combinedFlightDefinition.has_value(), "Flight definition exists for combined rocket-speed scaling coverage");
        if (combinedFlightDefinition.has_value())
        {
            FActivePowerUpEffectState combinedFlight;
            combinedFlight.id = combinedFlightDefinition->id;
            combinedFlight.definition = *combinedFlightDefinition;
            combinedFlight.remainingSeconds = combinedFlightDefinition->durationSeconds;
            combinedFlight.sourceId = "combined_speed_flight_rocket_test";
            combinedSpeedFlightState.statusEffects.active[combinedFlight.id] = combinedFlight;
            stepSimulation(combinedSpeedFlightState, speedScaledFire, MAX_SIM_DT);
            check(combinedSpeedFlightState.projectiles.size() == 1,
                "Flight plus permanent Speed Upgrades still launch one standard rocket");
            if (!combinedSpeedFlightState.projectiles.empty())
            {
                const FProjectileState& projectile = combinedSpeedFlightState.projectiles.front();
                const double expectedProjectileSpeed = combinedSpeedFlightState.tuning.rocketProjectileSpeed
                    * expectedSpeedScale
                    * 1.5;
                check(std::abs(projectile.projectileSpeed - expectedProjectileSpeed) < 0.0001,
                    "Flight 1.5x and permanent Speed Upgrade multipliers combine for player rocket velocity");
                check(std::abs(projectile.projectileSpeed * projectile.lifetime - combinedSpeedFlightState.tuning.rocketProjectileUnwrenchedMaxTravelDistance) < 0.0001,
                    "combined Flight and permanent speed scaling preserves the authored 400 px default standard rocket range");
            }
        }

        state.statusEffects.active[POWER_UP_EFFECT_IDS::FLIGHT].remainingSeconds = MAX_SIM_DT * 0.5;
        stepSimulation(state, createInputFrame(), MAX_SIM_DT);
        check(!activePowerUpEffect(state.statusEffects.active, POWER_UP_EFFECT_IDS::FLIGHT).has_value(),
            "Flight expires after its thirty-second timer");
        check(state.equipment.rocket.state == "mountedReady",
            "mounted rocket leaves Flight presentation state when the effect expires");

        FGameState deathRespawnState = createInitialGameState();
        deathRespawnState.pickups.clear();

        FPickupState deathFlightPickup;
        deathFlightPickup.id = "death_flight_pickup";
        deathFlightPickup.entityId = deathFlightPickup.id;
        deathFlightPickup.kind = "powerUp";
        deathFlightPickup.pickupKind = POWER_UP_EFFECT_IDS::FLIGHT;
        deathFlightPickup.powerUp = normalizePowerUpPickup(Json{ { "effectId", POWER_UP_EFFECT_IDS::FLIGHT } });
        deathFlightPickup.collected = true;
        deathFlightPickup.respawnSeconds = 60.0;
        deathFlightPickup.respawnTimer = 47.0;
        deathRespawnState.pickups.push_back(deathFlightPickup);

        FPickupState deathPermanentUpgrade;
        deathPermanentUpgrade.id = "death_permanent_health_upgrade";
        deathPermanentUpgrade.entityId = deathPermanentUpgrade.id;
        deathPermanentUpgrade.kind = "upgrade";
        deathPermanentUpgrade.pickupKind = HEALTH_UPGRADE_KIND;
        deathPermanentUpgrade.upgradeKind = HEALTH_UPGRADE_KIND;
        deathPermanentUpgrade.collected = true;
        // Deliberately malformed positive value: permanent upgrades must still never respawn.
        deathPermanentUpgrade.respawnSeconds = 60.0;
        deathPermanentUpgrade.respawnTimer = 47.0;
        deathRespawnState.pickups.push_back(deathPermanentUpgrade);

        FActivePowerUpEffectState deathFlightEffect;
        deathFlightEffect.id = flight->id;
        deathFlightEffect.definition = *flight;
        deathFlightEffect.remainingSeconds = flight->durationSeconds;
        deathFlightEffect.sourceId = deathFlightPickup.id;
        deathRespawnState.statusEffects.active[deathFlightEffect.id] = deathFlightEffect;

        const double lethalPickupDamage = damagePlayer(deathRespawnState, 1000.0, "death_pickup_respawn_test", true);
        check(lethalPickupDamage > 0.0 && deathRespawnState.player.combatState == "dead",
            "native pickup death-respawn regression enters the death lifecycle");
        check(!deathRespawnState.pickups[0].collected,
            "native collected pickup with positive respawn time reappears immediately when the player dies");
        check(std::abs(deathRespawnState.pickups[0].respawnTimer) < 0.000001,
            "native death-triggered pickup respawn clears the remaining wait timer");
        check(deathRespawnState.pickups[1].collected,
            "native permanent upgrades stay consumed even if malformed data gives them a positive respawn time");
        check(std::any_of(deathRespawnState.debug.lastEvents.begin(), deathRespawnState.debug.lastEvents.end(), [](const FDebugEvent& event)
        {
            return event.type == "POWER_UP_PICKUP_RESPAWNED"
                && event.sourceId == "death_flight_pickup"
                && event.reason == "playerDeath";
        }), "native death-triggered pickup respawn is visible in deterministic diagnostics");
        resetPlayer(deathRespawnState, "deathPickupRespawnTest");
        check(!activePowerUpEffect(deathRespawnState.statusEffects.active, POWER_UP_EFFECT_IDS::FLIGHT).has_value(),
            "native temporary Flight clears on respawn so the immediately restored pickup can be collected again");
    }
}
