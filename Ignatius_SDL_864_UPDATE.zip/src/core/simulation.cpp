#include "core/simulation.h"
#include "core/simulation-internal.h"
#include "core/world-collision-index.h"

#include "shared/auto-spawn-enemy-data.h"
#include "shared/camera-line-data.h"
#include "shared/cave-kill-boundary-data.h"
#include "shared/cave-window-data.h"
#include "shared/moving-platform-data.h"
#include "shared/reference-asset-loader.h"
#include "shared/string-utils.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cctype>
#include <cstdio>
#include <limits>
#include <set>
#include <sstream>
#include <utility>
#include <cstdint>
#include <memory>
#include <numbers>
#include <optional>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>


namespace Ignatius
{
    using namespace SimulationInternal;

    void updateCharacterEnemies(FGameState& state, double dt)
    {
        if (!state.settings.debugLoggingEnabled)
        {
            updateCharacterEnemiesInternal(state, dt);
            return;
        }
        const auto start = std::chrono::steady_clock::now();
        updateCharacterEnemiesInternal(state, dt);
        state.debug.simulationTimings.characterEnemiesMs += std::chrono::duration<double, std::milli>(
            std::chrono::steady_clock::now() - start).count();
    }

    void prewarmCharacterEnemyNavigationCaches(FGameState& state)
    {
        prewarmCharacterEnemyNavigationCachesInternal(state);
    }

    void updateEnemyContactDamage(FGameState& state)
    {
        updateEnemyContactDamageInternal(state);
    }

    void markFuelUse(FGameState& state, double rechargeDelay)
    {
        const double overdriveReduction = activePowerUpEffect(
            state.statusEffects.active,
            POWER_UP_EFFECT_IDS::OVERDRIVE).has_value()
            ? OVERDRIVE_FUEL_RECHARGE_DELAY_REDUCTION_SECONDS
            : 0.0;
        const double effectiveRechargeDelay = std::max(0.0, rechargeDelay - overdriveReduction);
        state.fuel.rechargeDelayTimer = std::max(state.fuel.rechargeDelayTimer, effectiveRechargeDelay);
        state.fuel.rechargeLatched = false;
    }

    void markRocketUse(FGameState& state)
    {
        markFuelUse(state, state.tuning.rechargeDelayAfterUse);
    }

    void markPlayerLungeFuelUse(FGameState& state)
    {
        markFuelUse(state, state.tuning.playerLungeRechargeDelayAfterUse);
    }

    void markPlayerBodySlamFuelUse(FGameState& state)
    {
        markFuelUse(state, state.tuning.playerBodySlamRechargeDelayAfterUse);
    }

    double attachedBoostVisualPower(const FGameState& state)
    {
        const double burstDuration = std::max(0.04, state.tuning.attachedBoostBurstDuration);
        const double burstBlend = clamp(state.equipment.rocket.boostBurstTimer / burstDuration, 0.0, 1.0);
        const double kickPower = state.tuning.attachedBoostKickVisualPower;
        const double sustainPower = state.tuning.attachedBoostSustainVisualPower;
        return std::max(0.08, sustainPower + (kickPower - sustainPower) * burstBlend);
    }

    constexpr double ATTACHED_ROCKET_SMOKE_TRAIL_LENGTH = 88.0;
    constexpr double ATTACHED_ROCKET_SMOKE_DENSITY_MULTIPLIER = 2.0;
    constexpr double GROUNDED_FLIGHT_SMOKE_LIFETIME_SCALE = 0.50;

    double attachedRocketSmokeLifetime(double relativeSpeed)
    {
        return std::clamp(ATTACHED_ROCKET_SMOKE_TRAIL_LENGTH / std::max(1.0, relativeSpeed), 0.045, 0.28);
    }

    double attachedRocketSmokeInterval(const FGameState& state)
    {
        const double particleScale = renderingParticleScale(state.settings.renderingQuality);
        return std::max(0.008, state.tuning.attachedBoostSmokePuffInterval
            / std::max(0.05, particleScale * ATTACHED_ROCKET_SMOKE_DENSITY_MULTIPLIER));
    }

    // attachedRocketSmokePuff x/y/vx/vy are rocket-local presentation coordinates.
    // +y is outward from the bell along the animated exhaust axis; +x is lateral.
    // The renderer attaches this local frame to the exact authored rocket transform.

    void trimSmokePuffs(FGameState& state)
    {
        const std::size_t maxPuffs = static_cast<std::size_t>(std::max(0.0, state.tuning.rocketSmokeMaxPuffs));
        while (state.effects.smokePuffs.size() > maxPuffs)
        {
            state.effects.smokePuffs.erase(state.effects.smokePuffs.begin());
        }
    }

    void emitAttachedBoostSmokeBurst(FGameState& state, double count)
    {
        const double particleScale = renderingParticleScale(state.settings.renderingQuality);
        const double authoredCount = std::max(0.0, count);
        const std::int32_t total = authoredCount <= 1.0
            ? std::max(0, static_cast<std::int32_t>(std::floor(authoredCount)))
            : std::max(1, static_cast<std::int32_t>(std::lround(authoredCount * particleScale)));
        if (total <= 0)
        {
            return;
        }

        const double power = clamp(
            state.equipment.rocket.boostVisualPowerNow > 0.0 ? state.equipment.rocket.boostVisualPowerNow : attachedBoostVisualPower(state),
            0.18,
            1.25);
        const double downSpeed = std::max(0.0, state.tuning.attachedBoostSmokePuffDownSpeed);
        const double sideSpeed = std::max(0.0, state.tuning.attachedBoostSmokePuffSideSpeed);
        const double speedJitter = std::max(0.0, state.tuning.attachedBoostSmokePuffSpeedJitter);
        const double lifetimeScale = state.equipment.rocket.state == "flight" && state.player.onGround
            ? GROUNDED_FLIGHT_SMOKE_LIFETIME_SCALE
            : 1.0;

        for (std::int32_t index = 0; index < total; ++index)
        {
            const double wobble = static_cast<double>((state.clock.tick * 37 + index * 53) % 100) / 100.0 - 0.5;
            const double spread = static_cast<double>((state.clock.tick * 19 + index * 29) % 100) / 100.0 - 0.5;
            FSmokePuffState puff;
            const std::int32_t id = state.effects.nextPuffId++;
            puff.id = std::string("attached_smoke_") + std::to_string(id);
            puff.kind = "attachedRocketSmokePuff";
            puff.x = spread * 9.0;
            puff.y = static_cast<double>(index) * 2.0;
            puff.vx = spread * sideSpeed - 8.0;
            puff.vy = downSpeed * (0.45 + power * 0.55) + wobble * speedJitter;
            puff.age = 0.0;
            puff.lifetime = attachedRocketSmokeLifetime(std::hypot(puff.vx, puff.vy)) * lifetimeScale;
            puff.radius = 8.0 + power * 9.0 + static_cast<double>(index % 3) * 1.5;
            puff.sparkleSeed = state.clock.tick * 109 + index * 149 + id * 17;
            state.effects.smokePuffs.push_back(puff);
        }
        trimSmokePuffs(state);
    }

    void emitPlayerLungeSmokeBurst(FGameState& state, double count)
    {
        const double particleScale = renderingParticleScale(state.settings.renderingQuality);
        const double authoredCount = std::max(0.0, count);
        const std::int32_t total = authoredCount <= 1.0
            ? std::max(0, static_cast<std::int32_t>(std::floor(authoredCount)))
            : std::max(1, static_cast<std::int32_t>(std::lround(authoredCount * particleScale)));
        if (total <= 0) return;

        for (std::int32_t index = 0; index < total; ++index)
        {
            const double wobble = static_cast<double>((state.clock.tick * 37 + index * 53) % 100) / 100.0 - 0.5;
            const double spread = static_cast<double>((state.clock.tick * 19 + index * 29) % 100) / 100.0 - 0.5;
            FSmokePuffState puff;
            const std::int32_t id = state.effects.nextPuffId++;
            puff.id = std::string("lunge_smoke_") + std::to_string(id);
            puff.kind = "attachedRocketSmokePuff";
            puff.x = spread * 10.0;
            puff.y = static_cast<double>(index) * 2.0;
            puff.vx = spread * 100.0;
            puff.vy = 520.0 + std::abs(wobble) * 180.0;
            puff.age = 0.0;
            puff.lifetime = attachedRocketSmokeLifetime(std::hypot(puff.vx, puff.vy));
            puff.radius = 12.0 + static_cast<double>(index % 3) * 2.0;
            puff.sparkleSeed = state.clock.tick * 109 + index * 149 + id * 17;
            state.effects.smokePuffs.push_back(puff);
        }
        trimSmokePuffs(state);
    }

    void emitPlayerLungeSmoke(FGameState& state, double dt, double densityMultiplier)
    {
        FRocketState& rocket = state.equipment.rocket;
        const double interval = attachedRocketSmokeInterval(state);
        const double density = std::max(0.0, densityMultiplier);
        rocket.attachedSmokeTimer = std::max(0.0, rocket.attachedSmokeTimer) + std::max(0.0, dt) * density;
        std::int32_t safety = 0;
        while (rocket.attachedSmokeTimer + 1e-12 >= interval && safety < 32)
        {
            emitPlayerLungeSmokeBurst(state, 1.0);
            rocket.attachedSmokeTimer -= interval;
            ++safety;
        }
    }

    void emitAttachedBoostSmoke(FGameState& state, double dt)
    {
        FRocketState& rocket = state.equipment.rocket;
        const double interval = attachedRocketSmokeInterval(state);
        rocket.attachedSmokeTimer -= std::max(0.0, dt);
        std::int32_t safety = 0;
        while (rocket.attachedSmokeTimer <= 0.0 && safety < 8)
        {
            emitAttachedBoostSmokeBurst(state, 1.0);
            rocket.attachedSmokeTimer += interval;
            ++safety;
        }
    }

    bool playerCursed(const FGameState& state)
    {
        return activePowerUpEffect(state.statusEffects.active, POWER_UP_EFFECT_IDS::CURSED).has_value();
    }

    void stopAttachedBoost(FGameState& state)
    {
        FRocketState& rocket = state.equipment.rocket;
        if (!rocket.attachedBoosting)
        {
            return;
        }

        rocket.attachedBoosting = false;
        rocket.state = "mountedReady";
        rocket.attachedBoostTime = 0.0;
        rocket.boostBurstTimer = 0.0;
        rocket.boostAccelerationNow = 0.0;
        rocket.boostVisualPowerNow = 0.0;
        rocket.attachedSmokeTimer = 0.0;
        addEvent(state, "PLAYER_BOOST_ENDED");
        markRocketUse(state);
    }

    bool startAttachedBoost(FGameState& state)
    {
        FRocketState& rocket = state.equipment.rocket;
        if (playerCursed(state))
        {
            addEvent(state, "PLAYER_BOOST_BLOCKED");
            if (!state.debug.lastEvents.empty()) state.debug.lastEvents.back().reason = "cursed";
            return false;
        }
        if (state.player.inWater)
        {
            addEvent(state, "PLAYER_BOOST_BLOCKED");
            FDebugEvent& event = state.debug.lastEvents.back();
            event.reason = "water";
            return false;
        }
        const double kickMax = std::max(0.0, state.tuning.attachedBoostKickChargeMax);
        const double kickFuelCost = std::max(0.0, state.tuning.attachedBoostKickFuelCost);
        rocket.boostKickCharge = clamp(rocket.boostKickCharge, 0.0, kickMax);

        const bool hasKickCharge = rocket.boostKickCharge > 0.001 && state.fuel.amount >= kickFuelCost;
        const bool canSustainWithoutKick = state.tuning.attachedBoostAllowSustainWithoutKickCharge && state.fuel.amount > 0.0;
        if (!hasKickCharge && !canSustainWithoutKick)
        {
            addEvent(state, "PLAYER_BOOST_BLOCKED");
            return false;
        }

        rocket.attachedBoosting = true;
        rocket.state = "attachedBoosting";
        rocket.attachedBoostTime = 0.0;
        rocket.boostBurstTimer = hasKickCharge ? std::max(0.0, state.tuning.attachedBoostBurstDuration) : 0.0;
        if (hasKickCharge)
        {
            rocket.boostKickCharge = 0.0;
            state.fuel.amount = std::max(0.0, state.fuel.amount - kickFuelCost);
        }
        rocket.boostAccelerationNow = 0.0;
        rocket.boostVisualPowerNow = attachedBoostVisualPower(state);
        rocket.attachedSmokeTimer = 0.0;
        emitAttachedBoostSmokeBurst(state, hasKickCharge ? state.tuning.attachedBoostSmokeKickPuffs : 3.0);
        state.player.ordinaryJumpActive = false;
        state.player.airBoostArmed = false;
        if (hasKickCharge)
        {
            state.player.vy = doubleJumpLaunchVelocity(state.tuning, state.player.vy);
        }
        markRocketUse(state);
        addEvent(state, "PLAYER_BOOST_STARTED");
        return true;
    }

    void applyAttachedHoverGovernor(FGameState& state, double dt)
    {
        FRocketState& rocket = state.equipment.rocket;
        if (!rocket.attachedBoosting || state.fuel.amount <= 0.0)
        {
            return;
        }

        const double slowClimbSpeed = -std::max(0.0, state.tuning.attachedBoostHoverFallSpeed);
        const double brakeAcceleration = std::max(0.0, state.tuning.attachedBoostHoverBrakeAcceleration);
        if (state.player.vy > slowClimbSpeed)
        {
            const double before = state.player.vy;
            state.player.vy = std::max(slowClimbSpeed, state.player.vy - brakeAcceleration * dt);
            const double correction = (state.player.vy - before) / std::max(0.0001, dt);
            rocket.boostAccelerationNow = correction;
            state.player.ay += correction;
            const double gravityCancelPower = clamp(
                std::abs(correction) / std::max(1.0, state.tuning.gravity),
                0.0,
                1.2);
            rocket.boostVisualPowerNow = std::max(
                attachedBoostVisualPower(state),
                gravityCancelPower * 0.72);
        }
        else
        {
            rocket.boostAccelerationNow = 0.0;
            rocket.boostVisualPowerNow = attachedBoostVisualPower(state);
        }
    }

    bool flightPowerUpActive(const FGameState& state)
    {
        return !playerCursed(state)
            && activePowerUpEffect(state.statusEffects.active, POWER_UP_EFFECT_IDS::FLIGHT).has_value();
    }

    void applyFlightGovernor(FGameState& state, const FInputFrame& input, double dt)
    {
        if (!flightPowerUpActive(state))
        {
            return;
        }

        const double safeDt = std::max(0.0001, dt);
        const bool upIntent = input.jumpHeld || input.jumpPressed || input.boostHeld || input.boostPressed;
        const bool downIntent = input.dropHeld || input.dropPressed;
        const double verticalInput = (downIntent ? 1.0 : 0.0) - (upIntent ? 1.0 : 0.0);
        const double movementScale = playerMovementSpeedScale(state);
        const double speed = std::max(1.0, state.tuning.flightVerticalSpeed)
            * movementScale * FLIGHT_MOVEMENT_SPEED_MULTIPLIER;
        const double acceleration = std::max(1.0, state.tuning.flightVerticalAcceleration) * movementScale;
        const double targetVelocity = verticalInput * speed;
        const double previousVelocity = state.player.vy;

        state.player.vy = approachValue(state.player.vy, targetVelocity, acceleration * safeDt);
        state.player.ay = (state.player.vy - previousVelocity) / safeDt;
        state.player.ordinaryJumpActive = false;
        state.player.airBoostArmed = false;

        FRocketState& rocket = state.equipment.rocket;
        rocket.attachedBoosting = false;
        rocket.state = "flight";
        rocket.attachedBoostTime += safeDt;
        rocket.boostBurstTimer = 0.0;
        rocket.boostAccelerationNow = state.player.ay;
        rocket.boostVisualPowerNow = verticalInput < -0.001
            ? 0.9
            : (verticalInput > 0.001 ? 0.24 : 0.48);
        emitAttachedBoostSmoke(state, safeDt);
    }

    void updateBoostKickGroundRecharge(FGameState& state, double dt)
    {
        FRocketState& rocket = state.equipment.rocket;
        const double kickMax = std::max(0.0, state.tuning.attachedBoostKickChargeMax);
        rocket.boostKickCharge = clamp(rocket.boostKickCharge, 0.0, kickMax);

        if (!state.player.onGround || rocket.boostKickCharge >= kickMax)
        {
            return;
        }

        const double previous = rocket.boostKickCharge;
        if (state.tuning.attachedBoostKickRechargeInstant)
        {
            rocket.boostKickCharge = kickMax;
        }
        else
        {
            rocket.boostKickCharge = std::min(kickMax, rocket.boostKickCharge + std::max(0.0, state.tuning.attachedBoostKickChargeRechargeRate) * dt);
        }

        if (rocket.boostKickCharge != previous)
        {
            if (state.tuning.rocketFuelBulbFlashOnKickRecharge)
            {
                rocket.fuelBulbFlashTimer = 0.45;
            }
            addEvent(state, "BOOST_KICK_RECHARGED");
        }
    }

    std::int32_t SimulationInternal::applyPlayerProjectileAreaDamage(FGameState& state, const FProjectileState& projectile, const FWorldPoint& center)
    {
        const double radius = std::max(0.0, projectile.areaDamageRadius);
        if (radius <= 0.0)
        {
            return 0;
        }

        std::int32_t hitCount = 0;
        for (FEnemyState& enemy : state.enemies)
        {
            if (enemy.health <= 0.0 || enemy.combatState == "dead")
            {
                continue;
            }
            if (!circleRectOverlap(center.x, center.y, radius, enemyProjectileHitbox(actorGeometryForEnemy(enemy))))
            {
                continue;
            }
            const double damage = damageEnemy(state, enemy, projectile.damage, projectile.id);
            if (damage > 0.0)
            {
                ++hitCount;
            }
        }
        for (FReactiveObjectState& object : state.reactiveObjects)
        {
            if (!reactiveObjectBlocksProjectiles(object))
            {
                continue;
            }
            if (!circleRectOverlap(center.x, center.y, radius, reactiveObjectCollisionRect(object)))
            {
                continue;
            }
            applyProjectileDamageToReactiveObject(state, projectile, object);
            ++hitCount;
        }
        addEvent(state, "ROCKET_AREA_DAMAGE_APPLIED");
        if (!state.debug.lastEvents.empty())
        {
            FDebugEvent& event = state.debug.lastEvents.back();
            event.sourceId = projectile.id;
            event.amount = hitCount;
            event.x = radius;
        }
        return hitCount;
    }

    void updateProjectiles(FGameState& state, double dt)
    {
        if (state.projectiles.empty())
        {
            return;
        }

        bool homingTargetSearchPerformed = false;

        const auto damageSplashEnemies = [&](const FWorldPoint& center, double radius, double damage, const std::string& sourceId, const std::string& primaryEnemyId = std::string())
        {
            if (radius <= 0.0 || damage <= 0.0)
            {
                return;
            }

            for (FEnemyState& enemy : state.enemies)
            {
                if (enemy.id == primaryEnemyId)
                {
                    continue;
                }
                if (enemy.health <= 0.0 || enemy.combatState == "dead")
                {
                    continue;
                }
                const FWorldRect enemyRect = enemyProjectileHitbox(actorGeometryForEnemy(enemy));
                if (!circleRectOverlap(center.x, center.y, radius, enemyRect))
                {
                    continue;
                }
                damageEnemy(state, enemy, damage, sourceId);
            }
        };

        const auto damageEnemyProjectileAreaPlayer = [&](const FProjectileState& projectile, const FWorldPoint& center) -> double
        {
            const double radius = std::max(0.0, projectile.areaDamageRadius);
            if (radius <= 0.0 || !playerIsAvailableCombatTarget(state))
            {
                return 0.0;
            }
            if (!circleRectOverlap(center.x, center.y, radius, getPlayerRect(state)))
            {
                return 0.0;
            }

            double direction = state.player.x < center.x ? -1.0 : 1.0;
            if (std::abs(state.player.x - center.x) <= 0.0001)
            {
                direction = projectile.vx < 0.0 ? -1.0 : 1.0;
            }
            const double damage = damagePlayerInternal(
                state,
                projectile.damage,
                projectile.enemyId.empty() ? projectile.id : projectile.enemyId,
                false,
                false,
                direction * std::abs(projectile.knockbackX),
                projectile.knockbackY);

            addEvent(state, "ENEMY_PROJECTILE_AREA_DAMAGE_APPLIED");
            if (!state.debug.lastEvents.empty())
            {
                FDebugEvent& event = state.debug.lastEvents.back();
                event.sourceId = projectile.id;
                event.kind = projectile.projectileKind;
                event.damageAmount = damage;
                event.x = center.x;
                event.y = center.y;
            }
            return damage;
        };

        struct FProjectileImpactCandidate
        {
            std::string kind;
            FSegmentHit hit;
            std::int32_t priority = 0;
            std::string id;
            FEnemyState* enemy = nullptr;
            FReactiveObjectState* reactiveObject = nullptr;
        };

        std::vector<FProjectileState> remaining;
        remaining.reserve(state.projectiles.size());

        for (FProjectileState projectile : state.projectiles)
        {
            if (projectile.state == "spent")
            {
                continue;
            }

            projectile.age += dt;

            if (projectile.state == "queued" || projectile.launchDelay > 0.0)
            {
                projectile.launchDelay = std::max(0.0, projectile.launchDelay - dt);
                if (projectile.launchDelay > 0.0)
                {
                    remaining.push_back(projectile);
                    continue;
                }
                if (projectile.launchFromPlayerOnActivation)
                {
                    projectile.x = state.player.x;
                    projectile.y = state.player.y - state.player.height * 0.72;
                }
                projectile.state = "launched";
                projectile.activeSinceTick = state.clock.tick;
                projectile.launchFromPlayerOnActivation = false;
                projectile.age = 0.0;
                addEvent(state, "ROCKET_SEQUENCE_SHOT_LAUNCHED");
                FDebugEvent& launchEvent = state.debug.lastEvents.back();
                launchEvent.sourceId = projectile.id;
                launchEvent.amount = projectile.volleyIndex + 1;
                projectile.trail.clear();
                FProjectileTrailPoint trailPoint;
                trailPoint.x = projectile.x;
                trailPoint.y = projectile.y;
                trailPoint.time = state.clock.time;
                trailPoint.radius = projectile.radius;
                projectile.trail.push_back(trailPoint);
            }

            if (projectile.state == "exploding")
            {
                if (projectile.trailEffect == "undeath" || projectile.visualStyle == "undeath")
                {
                    pruneEnemyFireballTrail(state, projectile);
                }
                projectile.explosionTimer -= dt;
                if (projectile.explosionTimer <= 0.0)
                {
                    projectile.state = (projectile.trailEffect == "undeath" || projectile.visualStyle == "undeath") && !projectile.trail.empty()
                        ? std::string("trailFading")
                        : std::string("spent");
                }
                if (projectile.state != "spent")
                {
                    remaining.push_back(projectile);
                }
                continue;
            }

            if (projectile.state == "trailFading")
            {
                pruneEnemyFireballTrail(state, projectile);
                if (!projectile.trail.empty())
                {
                    remaining.push_back(projectile);
                }
                continue;
            }

            if (projectile.state != "launched")
            {
                remaining.push_back(projectile);
                continue;
            }

            if (projectile.isRocket)
            {
                projectile.upLaunchTimer = std::max(0.0, projectile.upLaunchTimer - dt);
                projectile.boomerangOutboundTimer = std::max(0.0, projectile.boomerangOutboundTimer - dt);
            }

            if (projectile.isRocket && projectile.boomerangMode == "returning")
            {
                const FWorldPoint returnTarget{
                    state.player.x,
                    state.player.y - state.player.height * 0.55
                };
                const FWorldPoint desired = normalizedVector(returnTarget.x - projectile.x, returnTarget.y - projectile.y);
                const double speed = std::max(1.0, projectile.projectileSpeed > 0.0
                    ? projectile.projectileSpeed
                    : state.tuning.rocketProjectileSpeed);
                const double blend = std::clamp(std::max(7.2, projectile.homingStrength > 0.0 ? projectile.homingStrength : 0.0) * 1.5 * dt, 0.0, 1.0);
                projectile.vx += (desired.x * speed - projectile.vx) * blend;
                projectile.vy += (desired.y * speed - projectile.vy) * blend;
                const double nextSpeed = std::max(1.0, std::hypot(projectile.vx, projectile.vy));
                projectile.vx = projectile.vx / nextSpeed * speed;
                projectile.vy = projectile.vy / nextSpeed * speed;
            }
            else if (projectile.isRocket && projectile.homing)
            {
                const double originX = projectile.x;
                const double originY = projectile.y;
                const FTargetState* target = findTargetById(state, projectile.targetId, originX, originY);
                if (target != nullptr && projectile.homingPreferForwardAlignment)
                {
                    const double targetDx = target->x - originX;
                    const double targetDy = target->y - originY;
                    const double headingDot = targetDx * projectile.vx + targetDy * projectile.vy;
                    if (headingDot < -0.000001)
                    {
                        target = nullptr;
                        projectile.targetId.clear();
                        projectile.homingTargetSearchTimer = 0.0;
                    }
                }
                if (target == nullptr && !projectile.targetId.empty())
                {
                    projectile.targetId.clear();
                    projectile.homingTargetSearchTimer = 0.0;
                }
                if (target == nullptr && projectile.boomerang && projectile.boomerangOutboundTimer <= 0.0)
                {
                    beginBoomerangReturn(state, projectile, "targetUnavailable");
                }
                else
                {
                    projectile.homingTargetSearchTimer = std::max(0.0, projectile.homingTargetSearchTimer - dt);
                    if (target == nullptr && projectile.homingTargetSearchTimer <= 0.0 && !homingTargetSearchPerformed)
                    {
                        homingTargetSearchPerformed = true;
                        target = projectile.homingPreferForwardAlignment
                            ? findHeadingHomingTarget(state, originX, originY, projectile.vx, projectile.vy)
                            : findHomingTarget(state, originX, originY, projectile.facing < 0 ? -1 : 1);
                        projectile.homingTargetSearchTimer = HOMING_TARGET_SEARCH_INTERVAL_SECONDS;
                    }
                    if (target != nullptr)
                    {
                        projectile.targetId = target->id;
                        applyRocketHomingMeander(state, projectile, dt);
                        FWorldPoint desired{ target->x - projectile.x, target->y - projectile.y };
                        const double desiredLength = std::max(0.000001, std::hypot(desired.x, desired.y));
                        desired.x /= desiredLength;
                        desired.y /= desiredLength;
                        const double speed = std::max(1.0, projectile.projectileSpeed > 0.0
                            ? projectile.projectileSpeed
                            : (std::hypot(projectile.vx, projectile.vy) > 0.0 ? std::hypot(projectile.vx, projectile.vy) : state.tuning.rocketProjectileSpeed));
                        if (projectile.homingTurnDegreesPerWorldUnit > 0.0)
                        {
                            const double travelSpeed = std::hypot(projectile.vx, projectile.vy);
                            const double maxTurnRadians = projectile.homingTurnDegreesPerWorldUnit
                                * travelSpeed * dt * std::numbers::pi / 180.0;
                            rotateVelocityToward(projectile, desired, speed, maxTurnRadians);
                        }
                        else
                        {
                            const double normalHomingStrength = projectile.homingStrength > 0.0
                                ? projectile.homingStrength
                                : state.tuning.rocketProjectileHomingStrength;
                            const double initialHomingStrength = projectile.initialHomingStrength > 0.0
                                ? projectile.initialHomingStrength
                                : (state.tuning.rocketProjectileInitialHomingStrength > 0.0 ? state.tuning.rocketProjectileInitialHomingStrength : normalHomingStrength);
                            const double homingStrength = projectile.upLaunchTimer > 0.0
                                ? std::max(normalHomingStrength, initialHomingStrength)
                                : normalHomingStrength;
                            const double blend = std::clamp(homingStrength * dt, 0.0, 1.0);
                            projectile.vx += (desired.x * speed - projectile.vx) * blend;
                            projectile.vy += (desired.y * speed - projectile.vy) * blend;
                            const double nextSpeed = std::max(1.0, std::hypot(projectile.vx, projectile.vy));
                            projectile.vx = projectile.vx / nextSpeed * speed;
                            projectile.vy = projectile.vy / nextSpeed * speed;
                        }
                    }
                }
            }
            else if (projectile.owner == "enemy" && projectile.homingStrength > 0.0 && state.player.visible)
            {
                const double currentSpeed = std::hypot(projectile.vx, projectile.vy);
                const double speed = currentSpeed > 0.000001
                    ? currentSpeed
                    : std::max(1.0, projectile.projectileSpeed);
                const FWorldPoint playerTarget{ state.player.x, state.player.y - state.player.height * 0.56 };
                FWorldPoint desired = projectile.launchType == "pathing_lo" || projectile.launchType == "pathing_hi"
                    ? pathingProjectileDesiredDirection(state, projectile, playerTarget)
                    : normalizedVector(playerTarget.x - projectile.x, playerTarget.y - projectile.y);
                const double blend = std::clamp(projectile.homingStrength * dt, 0.0, 1.0);
                projectile.vx += (desired.x * speed - projectile.vx) * blend;
                projectile.vy += (desired.y * speed - projectile.vy) * blend;
                const double nextSpeed = std::max(1.0, std::hypot(projectile.vx, projectile.vy));
                projectile.vx = projectile.vx / nextSpeed * speed;
                projectile.vy = projectile.vy / nextSpeed * speed;
            }

            if (!projectile.isRocket)
            {
                projectile.vy += projectile.gravity * dt;
            }
            const FWorldPoint previous{ projectile.x, projectile.y };
            projectile.x += projectile.vx * dt;
            projectile.y += projectile.vy * dt;

            if (projectile.isRocket)
            {
                recordProjectileTrail(state, projectile);
            }
            else if (projectile.trailEffect == "fire" || projectile.trailEffect == "undeath")
            {
                recordEnemyFireballTrail(state, projectile, dt);
            }
            else if (projectile.trailEffect == "sparks")
            {
                recordEnemySparkTrail(state, projectile);
            }

            const double radius = std::max(1.0, projectile.radius);
            const FWorldPoint current{ projectile.x, projectile.y };
            const FWorldRect terrainQuery{
                std::min(previous.x, current.x) - radius * 1.5,
                std::min(previous.y, current.y) - radius * 1.5,
                std::abs(current.x - previous.x) + radius * 3.0,
                std::abs(current.y - previous.y) + radius * 3.0
            };

            std::optional<FProjectileImpactCandidate> bestTerrainImpact;
            const bool includeMovingPlatformSweep = projectile.activeSinceTick < 0 || projectile.activeSinceTick < state.clock.tick;
            if (!projectile.phasesThroughObstacles)
            {
                const auto recordTerrainImpact = [&](const std::optional<FSegmentHit>& hit, const std::string& id)
                {
                    if (!hit.has_value())
                    {
                        return;
                    }
                    if (!bestTerrainImpact.has_value() || hit->t < bestTerrainImpact->hit.t)
                    {
                        bestTerrainImpact = FProjectileImpactCandidate{ "terrain", *hit, 2, id, nullptr, nullptr };
                    }
                };

                for (const FWorldSolid* solid : queryWorldSolids(state.world, terrainQuery))
                {
                    if (!solid->reactiveObjectId.empty())
                    {
                        continue;
                    }
                    const FWorldRect solidRect{ solid->x, solid->y, solid->w, solid->h };
                    recordTerrainImpact(sweptCircleRectImpact(previous, current, radius, solidRect), solid->id);
                }

                for (const FWorldSegment* segment : queryWorldSegments(state.world, terrainQuery))
                {
                    if (segment->kind == "walkable" || !isAreaBlockingLineKind(segment->kind))
                    {
                        continue;
                    }
                    if (const FMovingPlatformState* movingPlatform = movingPlatformForCollisionId(state, segment->id);
                        includeMovingPlatformSweep && movingPlatform != nullptr && movingPlatform->collisionAttached && movingPlatform->projectileSweepActive)
                    {
                        continue;
                    }
                    const FWorldPoint a{ segment->x1, segment->y1 };
                    const FWorldPoint b{ segment->x2, segment->y2 };
                    recordTerrainImpact(sweptCircleSegmentImpact(previous, current, radius, a, b), segment->id);
                }

                for (const FWorldCollisionPolygon* polygon : queryWorldCollisionPolygons(state.world, terrainQuery))
                {
                    if (!isAreaBlockingLineKind(polygon->kind))
                    {
                        continue;
                    }
                    if (const FMovingPlatformState* movingPlatform = movingPlatformForCollisionId(state, polygon->id);
                        includeMovingPlatformSweep && movingPlatform != nullptr && movingPlatform->collisionAttached && movingPlatform->projectileSweepActive)
                    {
                        continue;
                    }
                    recordTerrainImpact(sweptCirclePolygonImpact(previous, current, radius, polygon->points), polygon->id);
                }

                if (includeMovingPlatformSweep)
                for (const FMovingPlatformState& platform : state.world.movingPlatforms)
                {
                    if (!platform.collisionAttached || !platform.projectileSweepActive)
                    {
                        continue;
                    }
                    FWorldPoint relativeStart = previous;
                    if (platform.movement.motionType == "swing")
                    {
                        const double deltaRadians = (platform.projectileSweepEndAngle - platform.projectileSweepStartAngle)
                            * std::numbers::pi_v<double> / 180.0;
                        if (std::abs(deltaRadians) <= 0.000000001)
                        {
                            continue;
                        }
                        relativeStart = rotatePointAroundMovingPlatformPivot(previous.x, previous.y, platform, deltaRadians);
                    }
                    else
                    {
                        if (std::abs(platform.projectileSweepDeltaX) <= 0.000000001
                            && std::abs(platform.projectileSweepDeltaY) <= 0.000000001)
                        {
                            continue;
                        }
                        relativeStart.x += platform.projectileSweepDeltaX;
                        relativeStart.y += platform.projectileSweepDeltaY;
                    }

                    const auto recordRelativeTerrainImpact = [&](const std::optional<FSegmentHit>& relativeHit, const std::string& id)
                    {
                        if (!relativeHit.has_value())
                        {
                            return;
                        }
                        FSegmentHit worldHit = *relativeHit;
                        worldHit.x = previous.x + (current.x - previous.x) * worldHit.t;
                        worldHit.y = previous.y + (current.y - previous.y) * worldHit.t;
                        recordTerrainImpact(worldHit, id);
                    };
                    for (const FWorldSegment& segment : platform.segments)
                    {
                        if (segment.kind == "walkable" || !isAreaBlockingLineKind(segment.kind))
                        {
                            continue;
                        }
                        recordRelativeTerrainImpact(
                            sweptCircleSegmentImpact(
                                relativeStart,
                                current,
                                radius,
                                { segment.x1, segment.y1 },
                                { segment.x2, segment.y2 }),
                            segment.id);
                    }
                    for (const FWorldCollisionPolygon& polygon : platform.polygons)
                    {
                        if (!isAreaBlockingLineKind(polygon.kind))
                        {
                            continue;
                        }
                        recordRelativeTerrainImpact(
                            sweptCirclePolygonImpact(relativeStart, current, radius, polygon.points),
                            polygon.id);
                    }
                }
            }

            if (projectile.boomerangMode == "returning")
            {
                std::optional<FProjectileImpactCandidate> returnImpact;
                const auto considerReturnImpact = [&](const std::optional<FProjectileImpactCandidate>& candidate)
                {
                    if (!candidate.has_value())
                    {
                        return;
                    }
                    if (!returnImpact.has_value()
                        || candidate->hit.t < returnImpact->hit.t
                        || (std::abs(candidate->hit.t - returnImpact->hit.t) <= 0.000001 && candidate->priority < returnImpact->priority))
                    {
                        returnImpact = candidate;
                    }
                };

                if (const std::optional<FSegmentHit> catchHit = sweptCircleRectImpact(previous, current, radius, getPlayerRect(state)))
                {
                    considerReturnImpact(FProjectileImpactCandidate{ "playerCatch", *catchHit, 0, state.player.id, nullptr, nullptr });
                }

                for (FEnemyState& enemy : state.enemies)
                {
                    if (enemy.health <= 0.0 || enemy.combatState == "dead")
                    {
                        continue;
                    }
                    const FWorldRect enemyRect = enemyProjectileHitbox(actorGeometryForEnemy(enemy));
                    if (const std::optional<FSegmentHit> hit = sweptCircleRectImpact(previous, current, radius, enemyRect))
                    {
                        considerReturnImpact(FProjectileImpactCandidate{ "enemy", *hit, 1, enemy.id, &enemy, nullptr });
                    }
                }

                if (!projectile.phasesThroughObstacles)
                {
                    for (FReactiveObjectState& object : state.reactiveObjects)
                    {
                        if (!reactiveObjectBlocksProjectiles(object))
                        {
                            continue;
                        }
                        if (const std::optional<FSegmentHit> hit = sweptCircleRectImpact(previous, current, radius, reactiveObjectCollisionRect(object)))
                        {
                            considerReturnImpact(FProjectileImpactCandidate{ "reactiveObject", *hit, 2, object.id, nullptr, &object });
                        }
                    }
                    if (bestTerrainImpact.has_value())
                    {
                        FProjectileImpactCandidate terrainCandidate = *bestTerrainImpact;
                        terrainCandidate.priority = 3;
                        considerReturnImpact(terrainCandidate);
                    }
                }

                if (returnImpact.has_value())
                {
                    projectile.x = returnImpact->hit.x;
                    projectile.y = returnImpact->hit.y;
                    const FWorldPoint impactPoint{ projectile.x, projectile.y };
                    if (returnImpact->kind == "playerCatch")
                    {
                        completeBoomerangReturn(state, projectile);
                    }
                    else if (returnImpact->kind == "enemy" && returnImpact->enemy != nullptr)
                    {
                        damageEnemy(state, *returnImpact->enemy, projectile.damage, projectile.id);
                        explodeProjectile(state, projectile, returnImpact->enemy->id, "enemy");
                    }
                    else if (returnImpact->kind == "reactiveObject" && returnImpact->reactiveObject != nullptr)
                    {
                        applyProjectileDamageToReactiveObject(state, projectile, *returnImpact->reactiveObject);
                        explodeProjectile(state, projectile, returnImpact->reactiveObject->id, "reactiveObject");
                    }
                    else
                    {
                        explodeProjectile(state, projectile, returnImpact->id.empty() ? std::string("terrain") : returnImpact->id, "terrain");
                    }

                    if (projectile.state == "exploding")
                    {
                        addEvent(state, "ROCKET_IMPACTED");
                        FDebugEvent& event = state.debug.lastEvents.back();
                        event.sourceId = projectile.id;
                        event.reason = projectile.impactReason;
                        event.solidId = projectile.impactReason;
                        event.kind = projectile.impactKind;
                        event.boomerangReturning = true;
                        event.x = impactPoint.x;
                        event.y = impactPoint.y;
                    }
                }
                else if (state.clock.time - projectile.boomerangReturnStartedAt.value_or(state.clock.time) >= 4.0)
                {
                    projectile.state = "spent";
                    addEvent(state, "BOOMERANG_ROCKET_RETURN_FAILED");
                    FDebugEvent& event = state.debug.lastEvents.back();
                    event.sourceId = projectile.id;
                }

                if (projectile.state != "spent")
                {
                    remaining.push_back(projectile);
                }
                continue;
            }

            std::optional<FProjectileImpactCandidate> bestActorImpact;
            if (projectile.owner == "player")
            {
                for (FEnemyState& enemy : state.enemies)
                {
                    if (enemy.health <= 0.0 || enemy.combatState == "dead")
                    {
                        continue;
                    }
                    const FWorldRect enemyRect = enemyProjectileHitbox(actorGeometryForEnemy(enemy));
                    const std::optional<FSegmentHit> hit = sweptCircleRectImpact(previous, current, radius, enemyRect);
                    if (!hit.has_value() || (bestActorImpact.has_value() && hit->t >= bestActorImpact->hit.t))
                    {
                        continue;
                    }
                    bestActorImpact = FProjectileImpactCandidate{ "enemy", *hit, 0, enemy.id, &enemy, nullptr };
                }
            }
            else if (projectile.owner == "enemy" && state.player.visible && state.player.targetable)
            {
                const FWorldRect playerRect = getPlayerRect(state);
                if (const std::optional<FSegmentHit> hit = sweptCircleRectImpact(previous, current, radius, playerRect))
                {
                    bestActorImpact = FProjectileImpactCandidate{ "player", *hit, 0, state.player.id, nullptr, nullptr };
                }
            }

            std::optional<FProjectileImpactCandidate> bestReactiveImpact;
            if (!projectile.phasesThroughObstacles)
            {
                for (FReactiveObjectState& object : state.reactiveObjects)
                {
                    if (!reactiveObjectBlocksProjectiles(object))
                    {
                        continue;
                    }
                    const std::optional<FSegmentHit> hit = sweptCircleRectImpact(previous, current, radius, reactiveObjectCollisionRect(object));
                    if (!hit.has_value() || (bestReactiveImpact.has_value() && hit->t >= bestReactiveImpact->hit.t))
                    {
                        continue;
                    }
                    bestReactiveImpact = FProjectileImpactCandidate{ "reactiveObject", *hit, 1, object.id, nullptr, &object };
                }
            }

            std::optional<FProjectileImpactCandidate> impact;
            const auto considerImpact = [&](const std::optional<FProjectileImpactCandidate>& candidate)
            {
                if (!candidate.has_value())
                {
                    return;
                }
                if (!impact.has_value()
                    || candidate->hit.t < impact->hit.t
                    || (std::abs(candidate->hit.t - impact->hit.t) <= 0.000001 && candidate->priority < impact->priority))
                {
                    impact = candidate;
                }
            };
            considerImpact(bestActorImpact);
            considerImpact(bestReactiveImpact);
            considerImpact(bestTerrainImpact);

            const FWorldBounds worldBounds = normalizedBounds(state.world.bounds);
            const bool outsideWorld = projectile.x < worldBounds.minX - 512.0
                || projectile.x > worldBounds.maxX + 512.0
                || projectile.y < worldBounds.minY - 512.0
                || projectile.y > worldBounds.maxY + 1024.0;

            if (impact.has_value())
            {
                projectile.x = impact->hit.x;
                projectile.y = impact->hit.y;
                const FWorldPoint impactPoint{ projectile.x, projectile.y };
                if (impact->kind == "enemy" && impact->enemy != nullptr)
                {
                    if (projectile.owner == "player" && projectile.areaDamageRadius > 0.0)
                    {
                        applyPlayerProjectileAreaDamage(state, projectile, impactPoint);
                        explodeProjectile(state, projectile, impact->enemy->id, "enemy");
                    }
                    else
                    {
                        const double damage = damageEnemy(state, *impact->enemy, projectile.damage, projectile.id);
                        (void)damage;
                        if (projectile.secondaryEnemySplashDamage > 0.0)
                        {
                            damageSplashEnemies(impactPoint, projectile.secondaryEnemySplashRadius, projectile.secondaryEnemySplashDamage, projectile.id, impact->enemy->id);
                        }
                        if (projectile.boomerang && impact->enemy->health <= 0.0)
                        {
                            emitProjectileImpactSmoke(state, projectile, "enemy");
                            addEvent(state, "BOOMERANG_ROCKET_TARGET_DESTROYED");
                            FDebugEvent& event = state.debug.lastEvents.back();
                            event.sourceId = projectile.id;
                            event.solidId = impact->enemy->id;
                            beginBoomerangReturn(state, projectile, "targetDestroyed");
                        }
                        else
                        {
                            explodeProjectile(state, projectile, impact->enemy->id, "enemy");
                        }
                    }
                }
                else if (impact->kind == "player")
                {
                    if (projectile.owner == "enemy" && projectile.areaDamageRadius > 0.0)
                    {
                        damageEnemyProjectileAreaPlayer(projectile, impactPoint);
                    }
                    else
                    {
                        damagePlayerInternal(
                            state,
                            projectile.damage,
                            projectile.enemyId.empty() ? projectile.id : projectile.enemyId,
                            false,
                            false,
                            projectile.vx < 0.0 ? -std::abs(projectile.knockbackX) : std::abs(projectile.knockbackX),
                            projectile.knockbackY);
                    }
                    explodeProjectile(state, projectile, state.player.id, "player");
                }
                else if (impact->kind == "reactiveObject" && impact->reactiveObject != nullptr)
                {
                    if (projectile.owner == "enemy" && projectile.areaDamageRadius > 0.0)
                    {
                        damageEnemyProjectileAreaPlayer(projectile, impactPoint);
                        explodeProjectile(state, projectile, impact->reactiveObject->id, "reactiveObject");
                        if (projectile.state != "spent")
                        {
                            remaining.push_back(projectile);
                        }
                        continue;
                    }
                    if (projectile.owner == "player" && projectile.areaDamageRadius > 0.0)
                    {
                        applyPlayerProjectileAreaDamage(state, projectile, impactPoint);
                        explodeProjectile(state, projectile, impact->reactiveObject->id, "reactiveObject");
                    }
                    else
                    {
                        applyProjectileDamageToReactiveObject(state, projectile, *impact->reactiveObject);
                        if (projectile.secondaryEnemySplashDamage > 0.0)
                        {
                            damageSplashEnemies(impactPoint, projectile.secondaryEnemySplashRadius, projectile.secondaryEnemySplashDamage, projectile.id);
                        }
                        if (projectile.boomerang && impact->reactiveObject->health <= 0.0)
                        {
                            emitProjectileImpactSmoke(state, projectile, "reactiveObject");
                            beginBoomerangReturn(state, projectile, "objectDestroyed");
                        }
                        else
                        {
                            explodeProjectile(state, projectile, impact->reactiveObject->id, "reactiveObject");
                        }
                    }
                }
                else if (impact->kind == "terrain")
                {
                    if (projectile.owner == "enemy" && projectile.areaDamageRadius > 0.0)
                    {
                        damageEnemyProjectileAreaPlayer(projectile, impactPoint);
                        explodeProjectile(state, projectile, impact->id.empty() ? std::string("terrain") : impact->id, "terrain");
                        if (projectile.state != "spent")
                        {
                            remaining.push_back(projectile);
                        }
                        continue;
                    }
                    if (projectile.owner == "player" && projectile.areaDamageRadius > 0.0)
                    {
                        applyPlayerProjectileAreaDamage(state, projectile, impactPoint);
                    }
                    else if (projectile.secondaryEnemySplashDamage > 0.0)
                    {
                        damageSplashEnemies(impactPoint, projectile.secondaryEnemySplashRadius, projectile.secondaryEnemySplashDamage, projectile.id);
                    }
                    explodeProjectile(state, projectile, impact->id.empty() ? std::string("terrain") : impact->id, "terrain");
                }
            }
            else if (outsideWorld)
            {
                projectile.state = "spent";
            }
            else if (projectile.age >= projectile.lifetime)
            {
                if (projectile.boomerang)
                {
                    beginBoomerangReturn(state, projectile, "lifetimeMiss");
                }
                else if (projectileBeyondLifetimeExplosionMargin(state, projectile))
                {
                    projectile.state = "spent";
                }
                else if (projectile.areaDamageRadius > 0.0 && projectile.owner == "player")
                {
                    const FWorldPoint impactPoint{ projectile.x, projectile.y };
                    applyPlayerProjectileAreaDamage(state, projectile, impactPoint);
                    explodeProjectile(state, projectile, "lifetime", "lifetime");
                }
                else
                {
                    explodeProjectile(state, projectile, "lifetime", "lifetime");
                }
            }

            if (projectile.state != "spent")
            {
                remaining.push_back(projectile);
            }
        }

        state.projectiles = std::move(remaining);
    }


    bool teleportPlayer(FGameState& state, double x, double y, const std::string& reason)
    {
        if (!std::isfinite(x) || !std::isfinite(y))
        {
            return false;
        }

        stopAttachedBoost(state);
        clearPlayerLungeState(state);
        state.player.bodySlamRechargeReady = true;
        state.player.bodySlamCommitted = false;
        state.player.bodySlamImmunityTimer = 0.0;
        state.player.x = x;
        state.player.y = y;
        state.player.vx = 0.0;
        state.player.vy = 0.0;
        state.player.ax = 0.0;
        state.player.ay = 0.0;
        state.player.onGround = false;
        state.player.wasOnGround = false;
        state.player.airborneTime = 0.0;
        state.player.coyoteTimer = 0.0;
        state.player.airBoostArmed = false;
        state.player.ordinaryJumpActive = false;
        state.player.hasOrdinaryJumpStartY = false;
        state.player.hasOrdinaryJumpApexY = false;
        state.player.ordinaryJumpStartY = 0.0;
        state.player.ordinaryJumpApexY = 0.0;
        state.player.supportId.clear();
        state.player.groundStride = FGroundStrideState{};
        state.player.dropThroughTimer = 0.0;
        state.player.dropThroughSupportId.clear();
        state.player.inWater = false;
        state.player.waterSubmersion = 0.0;
        state.player.waterRegionId.clear();
        state.player.crushCandidateTicks = 0;
        state.player.crushCandidateKey.clear();
        state.player.crushCandidateDetail.reset();
        state.camera.x = x;
        state.camera.y = y - 170.0;
        resetCameraLineTracking(state);
        addEvent(state, "PLAYER_TELEPORTED");
        if (!state.debug.lastEvents.empty())
        {
            FDebugEvent& event = state.debug.lastEvents.back();
            event.reason = reason;
            event.x = x;
            event.y = y;
        }
        return true;
    }

    void resetPlayer(FGameState& state, const std::string& reason)
    {
        clearDeathResetPowerUps(state);
        clearPlayerLungeState(state);
        state.player.fallImpactExplosionCooldownTimer = 0.0;
        state.player.bodySlamRechargeReady = true;
        state.player.bodySlamCommitted = false;
        state.player.bodySlamImmunityTimer = 0.0;
        state.player.onGround = false;
        state.player.supportId.clear();
        state.player.groundStride = FGroundStrideState{};
        resetMovingPlatforms(state, reason);
        state.player.x = state.player.spawnX;
        state.player.y = state.player.spawnY;
        state.player.vx = 0.0;
        state.player.vy = 0.0;
        state.player.ax = 0.0;
        state.player.ay = 0.0;
        state.player.onGround = false;
        state.player.wasOnGround = false;
        state.player.airborneTime = 0.0;
        state.player.coyoteTimer = 0.0;
        state.player.airBoostArmed = false;
        state.player.ordinaryJumpActive = false;
        state.player.hasOrdinaryJumpStartY = false;
        state.player.hasOrdinaryJumpApexY = false;
        state.player.ordinaryJumpStartY = 0.0;
        state.player.ordinaryJumpApexY = 0.0;
        state.player.dropThroughTimer = 0.0;
        state.player.dropThroughSupportId.clear();
        state.player.inWater = false;
        state.player.waterSubmersion = 0.0;
        state.player.waterRegionId.clear();
        state.player.crushCandidateTicks = 0;
        state.player.crushCandidateKey.clear();
        state.player.crushCandidateDetail.reset();
        state.player.facing = 1;
        state.player.visible = true;
        state.player.renderScale = 1.0;
        state.player.combatState = "alive";
        state.player.targetable = true;
        state.player.deathPhase = "none";
        state.player.deathPhaseTimer = 0.0;
        state.player.deathElapsed = 0.0;
        state.player.deathSourceId.clear();
        state.player.deathResetReason.clear();
        state.health.amount = state.health.max;
        state.health.low = false;
        state.health.hasLastDamagedAt = false;
        state.health.lastDamagedAt = 0.0;
        state.health.regenerating = false;
        state.health.invulnerabilityTimer = 0.0;
        state.health.contactInvulnerabilityTimer = 0.0;
        state.fuel.amount = state.fuel.max;
        state.fuel.rechargeDelayTimer = 0.0;
        state.fuel.rechargeLatched = false;
        state.projectiles.clear();
        state.effects.smokePuffs.clear();
        state.equipment.rocket.state = "mountedReady";
        state.equipment.rocket.attachedBoosting = false;
        state.equipment.rocket.attachedBoostTime = 0.0;
        state.equipment.rocket.boostKickCharge = state.tuning.attachedBoostKickChargeMax;
        state.equipment.rocket.boostBurstTimer = 0.0;
        state.equipment.rocket.boostAccelerationNow = 0.0;
        state.equipment.rocket.boostVisualPowerNow = 0.0;
        state.equipment.rocket.attachedSmokeTimer = 0.0;
        state.equipment.rocket.fuelBulbFlashTimer = 0.0;
        state.camera.x = state.player.spawnX;
        state.camera.y = state.player.spawnY - 170.0;
        resetCameraLineTracking(state);
        addEvent(state, "PLAYER_RESET");
        if (!state.debug.lastEvents.empty())
        {
            state.debug.lastEvents.back().reason = reason;
        }
    }

    std::string activeCutsceneGotoCharacterId(FGameState& state)
    {
        FStoryCutsceneScriptState* script = activeCutsceneScript(state);
        if (!script || script->commandIndex < 0 || script->commandIndex >= static_cast<std::int32_t>(script->commands.size()))
        {
            return {};
        }
        const FStoryCutsceneCommandState& command = script->commands[static_cast<std::size_t>(script->commandIndex)];
        return command.type == "GOTO" ? command.characterId : std::string{};
    }

    void detachActiveCutsceneGotoCharacter(FGameState& state)
    {
        const std::string characterId = activeCutsceneGotoCharacterId(state);
        if (characterId.empty()) return;
        std::optional<FCutsceneCharacterRef> character = cutsceneCharacter(state, characterId);
        if (character) detachCutsceneCharacterFromMovingPlatform(state, *character);
    }

    bool cutsceneEnemyHasAnimationOverride(const FGameState& state, const FEnemyState& enemy)
    {
        const std::int32_t index = state.story.cutsceneScriptIndex;
        if (index < 0 || index >= static_cast<std::int32_t>(state.story.cutsceneScripts.size())) return false;
        const FStoryCutsceneScriptState& script = state.story.cutsceneScripts[static_cast<std::size_t>(index)];
        for (const auto& [characterId, _] : script.animationOverrides)
        {
            if (characterId != "wizard" && (enemy.id == characterId || enemy.entityId == characterId)) return true;
        }
        return false;
    }

    void updateStoryPlayerPassiveMotion(FGameState& state, double dt)
    {
        const double stepDt = std::max(0.0, dt);
        state.player.dropThroughTimer = std::max(0.0, state.player.dropThroughTimer - stepDt);
        if (state.player.dropThroughTimer <= 0.0)
        {
            state.player.dropThroughSupportId.clear();
        }
        if (activeCutsceneGotoCharacterId(state) == "wizard")
        {
            return;
        }

        if (state.equipment.rocket.attachedBoosting)
        {
            // Defensive mirror of cutscene start: held backpack boost is never
            // allowed to become free thrust while input handling is suspended.
            stopAttachedBoost(state);
        }

        const FWaterImmersion waterBefore = refreshPlayerWaterState(state);
        const bool flightActive = flightPowerUpActive(state) && !waterBefore.inWater && !state.player.bodySlamCommitted;
        if (!flightActive && state.equipment.rocket.state == "flight")
        {
            state.equipment.rocket.state = "mountedReady";
            state.equipment.rocket.attachedBoostTime = 0.0;
            state.equipment.rocket.boostAccelerationNow = 0.0;
            state.equipment.rocket.boostVisualPowerNow = 0.0;
            state.equipment.rocket.attachedSmokeTimer = 0.0;
        }
        const bool wasOnGround = state.player.onGround;
        if (wasOnGround && !waterBefore.inWater && !flightActive)
        {
            state.player.airborneTime = 0.0;
            return;
        }

        state.player.groundStride = FGroundStrideState{};
        state.player.wasOnGround = wasOnGround;
        state.player.ax = 0.0;

        const double movementSpeedScale = playerMovementSpeedScale(state);
        if (waterBefore.inWater)
        {
            state.player.vx = applyWaterDrag(
                state.player.vx,
                waterBefore.submersion,
                state.tuning.waterHorizontalLinearDrag,
                state.tuning.waterHorizontalQuadraticDrag,
                stepDt);
        }
        else if (flightActive)
        {
            state.player.vx = approachValue(
                state.player.vx,
                0.0,
                state.tuning.groundFriction * movementSpeedScale * stepDt);
        }
        else
        {
            state.player.vx *= std::max(0.0, 1.0 - std::max(0.0, state.tuning.airDrag) * stepDt);
        }
        const double passiveSpeedLimit = std::max(1.0, state.tuning.maxRunSpeed)
            * movementSpeedScale
            * (waterBefore.inWater
                ? std::max(0.05, state.tuning.waterHorizontalSpeedScale)
                : (flightActive ? FLIGHT_MOVEMENT_SPEED_MULTIPLIER : 1.0));
        state.player.vx = std::clamp(state.player.vx, -passiveSpeedLimit, passiveSpeedLimit);

        const double previousX = state.player.x;
        const double previousY = state.player.y;
        state.player.x += state.player.vx * stepDt;
        resolveBlockingSegmentHorizontal(state, previousX, previousY);

        const double initialVy = state.player.vy;
        double verticalDelta = 0.0;
        if (waterBefore.inWater)
        {
            const double submersion = clamp(waterBefore.submersion, 0.0, 1.0);
            const double buoyancyRatio = clamp(state.tuning.waterGravityBuoyancyRatio, 0.0, 0.99);
            const double acceleration = std::max(1.0, state.tuning.gravity) * (1.0 - buoyancyRatio * submersion);
            state.player.vy += acceleration * stepDt;
            state.player.vy = applyWaterDrag(
                state.player.vy,
                submersion,
                state.tuning.waterLinearDrag,
                state.tuning.waterQuadraticDrag,
                stepDt);
            state.player.vy = std::min(state.player.vy, state.tuning.terminalVelocity);
            state.player.ay = stepDt > 0.0 ? (state.player.vy - initialVy) / stepDt : 0.0;
            state.player.ordinaryJumpActive = false;
            state.player.airBoostArmed = false;
            verticalDelta = state.player.vy * stepDt;
        }
        else if (flightActive)
        {
            applyFlightGovernor(state, createInputFrame(), stepDt);
            verticalDelta = state.player.vy * stepDt;
        }
        else
        {
            const double gravity = std::max(1.0, state.tuning.gravity);
            state.player.ay = gravity;
            if (!state.player.ordinaryJumpActive)
            {
                state.player.vy = std::min(state.player.vy + gravity * stepDt, state.tuning.terminalVelocity);
                verticalDelta = state.player.vy * stepDt;
            }
            else
            {
                const double finalVy = std::min(initialVy + gravity * stepDt, state.tuning.terminalVelocity);
                const bool crossesApex = initialVy < 0.0 && finalVy >= 0.0;
                if (!crossesApex)
                {
                    const double effectiveAcceleration = (finalVy - initialVy) / std::max(0.000001, stepDt);
                    verticalDelta = initialVy * stepDt + 0.5 * effectiveAcceleration * stepDt * stepDt;
                    state.player.vy = finalVy;
                }
                else
                {
                    const double apexTime = std::min(stepDt, std::max(0.0, -initialVy / gravity));
                    const double remaining = std::max(0.0, stepDt - apexTime);
                    const double apexDisplacement = initialVy * apexTime + 0.5 * gravity * apexTime * apexTime;
                    state.player.hasOrdinaryJumpApexY = true;
                    state.player.ordinaryJumpApexY = state.player.y + apexDisplacement;
                    verticalDelta = apexDisplacement + 0.5 * gravity * remaining * remaining;
                    state.player.vy = std::min(gravity * remaining, state.tuning.terminalVelocity);
                }
            }
        }

        state.player.y += verticalDelta;
        const double landingImpactVy = std::max(0.0, state.player.vy);
        const FPlayerPenetrationResult penetration = resolvePlayerPenetrations(state, previousX, previousY);
        if (penetration.fatal)
        {
            return;
        }

        std::optional<FGroundSupportHit> bestSupport;
        const double sampleXs[3] = {
            state.player.x,
            state.player.x - state.player.width * 0.42,
            state.player.x + state.player.width * 0.42
        };
        for (double sampleX : sampleXs)
        {
            const std::optional<FGroundSupportHit> support = findGroundSupportHit(
                state,
                sampleX,
                previousY,
                state.player.y,
                !playerIgnoresAllWalkableCollisions(state.player));
            if (support.has_value())
            {
                bestSupport = support;
                break;
            }
        }

        const bool movingUpward = verticalDelta < -0.000001 && state.player.vy < -0.000001;
        if (bestSupport.has_value() && !movingUpward && state.player.vy >= 0.0)
        {
            state.player.y = bestSupport->y;
            state.player.vy = 0.0;
            state.player.onGround = true;
            state.player.ordinaryJumpActive = false;
            state.player.supportId = bestSupport->id;
            state.player.airBoostArmed = true;
            const double fallDamage = applyFallDamageOnLanding(state, landingImpactVy, bestSupport->id, bestSupport->kind);
            if (!wasOnGround)
            {
                emitPlayerLandedEvent(state, landingImpactVy, fallDamage, bestSupport->id, bestSupport->kind);
            }
        }
        else if (penetration.grounded)
        {
            state.player.onGround = true;
            state.player.vy = 0.0;
            state.player.ordinaryJumpActive = false;
            state.player.supportId = penetration.supportId;
            state.player.airBoostArmed = true;
            const double fallDamage = applyFallDamageOnLanding(state, landingImpactVy, penetration.supportId, penetration.supportKind);
            if (!wasOnGround)
            {
                emitPlayerLandedEvent(state, landingImpactVy, fallDamage, penetration.supportId, penetration.supportKind);
            }
        }
        else
        {
            state.player.onGround = false;
            state.player.supportId.clear();
        }

        const FWaterImmersion waterAfter = refreshPlayerWaterState(state);
        if (waterAfter.inWater && state.equipment.rocket.attachedBoosting)
        {
            stopAttachedBoost(state);
        }
        state.player.airborneTime = state.player.onGround ? 0.0 : std::max(0.0, state.player.airborneTime) + stepDt;
    }

    void updateStoryEnemyPassiveMotion(FGameState& state, double dt)
    {
        const std::string activeGotoCharacterId = activeCutsceneGotoCharacterId(state);
        for (FEnemyState& enemy : state.enemies)
        {
            if (enemy.simulationDormant)
            {
                continue;
            }
            enemy.hitFlashTimer = std::max(0.0, enemy.hitFlashTimer - dt);
            enemy.healthBarTimer = std::max(0.0, enemy.healthBarTimer - dt);

            if (enemy.kind != "characterEnemy")
            {
                if (enemy.health <= 0.0)
                {
                    enemy.combatState = "dead";
                    enemy.state = "destroyed";
                }
                else if (enemy.state == "hurt" && enemy.hitFlashTimer <= 0.0)
                {
                    enemy.combatState = "alive";
                    enemy.state = "idle";
                }
                continue;
            }

            // Script participants are protected from damage, and an active GOTO
            // owns its actor completely. Everyone else keeps passive physics and
            // damage/death presentation without making any AI decisions.
            if (!activeGotoCharacterId.empty() && (enemy.id == activeGotoCharacterId || enemy.entityId == activeGotoCharacterId))
            {
                continue;
            }
            if (enemy.locomotion == "stationary")
            {
                enemy.airborne = false;
                enemy.velocityX = 0.0;
                enemy.velocityY = 0.0;
                enemy.groundVelocityX = 0.0;
                enemy.groundStride = FGroundStrideState{};
            }
            const FEnemyPenetrationRecoveryResult collisionRecovery = resolveCharacterEnemyPenetrations(state, enemy);
            if (collisionRecovery.recovered || collisionRecovery.killed)
            {
                continue;
            }

            if (enemy.deathPendingLanding)
            {
                enemy.health = 0.0;
                enemy.combatState = "deathPendingLanding";
                enemy.attackTimer = 0.0;
                clearCharacterEnemyAttackLunge(enemy);
                enemy.attackHitApplied = false;
                enemy.hurtTimer = 0.0;
                enemy.deathElapsed = 0.0;
                enemy.animationTime = std::max(0.0, enemy.animationTime) + dt;
                if (enemy.airborne)
                {
                    const FCharacterEnemyNavigationContext navigation = characterEnemyNavigationContext(state, enemy);
                    if (navigation.supports != nullptr)
                    {
                        std::string locomotionAnimation = enemy.animationSlot.empty() ? std::string("walk") : enemy.animationSlot;
                        updateCharacterEnemyAirTraversal(state, enemy, dt, *navigation.supports, locomotionAnimation);
                    }
                }
                if (enemy.airborne)
                {
                    enemy.combatState = "deathPendingLanding";
                    syncCharacterEnemyTarget(state, enemy);
                    continue;
                }
                enemy.deathPendingLanding = false;
                enemy.combatState = "dead";
                enemy.state = "death";
                enemy.movementPhase = "dead";
                enemy.targetable = false;
                enemy.velocityX = 0.0;
                enemy.velocityY = 0.0;
                enemy.deathTimer = std::max(MAX_SIM_DT, enemy.deathDuration > 0.0 ? enemy.deathDuration : state.tuning.enemyDefaultDeathSeconds);
                enemy.deathElapsed = 0.0;
                setEnemyAnimationSlot(enemy, "death");
                syncCharacterEnemyTarget(state, enemy);
                continue;
            }

            if (enemy.health <= 0.0 || enemy.combatState == "dead")
            {
                enemy.health = 0.0;
                enemy.combatState = "dead";
                enemy.deathPendingLanding = false;
                enemy.deathTimer = std::max(0.0, enemy.deathTimer - dt);
                enemy.animationTime = std::max(0.0, enemy.animationTime) + dt;
                if (enemy.locomotion == "flying")
                {
                    enemy.state = "death";
                    updateDeadFlyingCharacterEnemy(state, enemy, dt);
                }
                else
                {
                    releaseCharacterEnemyIfGroundSupportLost(state, enemy);
                    if (enemy.airborne)
                    {
                        updateCharacterEnemyPassiveFall(state, enemy, dt, true);
                    }
                    cullPendingGroundCharacterEnemyDropIfOffWorld(state, enemy);
                    emitGroundCharacterEnemyDropsAtCorpseIfReady(state, enemy);
                    enemy.state = "death";
                    enemy.movementPhase = "dead";
                    setEnemyAnimationSlot(enemy, "death");
                    updateDeadEnemyPresentation(state, enemy, dt);
                    syncCharacterEnemyTarget(state, enemy);
                }
                enemy.targetable = false;
                continue;
            }

            const bool hadHurtPresentation = enemy.hurtTimer > 0.0 || enemy.combatState == "hurt";
            const bool hasAnimationOverride = cutsceneEnemyHasAnimationOverride(state, enemy);
            if (hadHurtPresentation)
            {
                enemy.hurtTimer = std::max(0.0, enemy.hurtTimer - dt);
            }

            // Flying locomotion is autonomous flight behavior, so living flyers
            // stay paused with AI. Ground actors ride moving platforms; only an
            // already-airborne jump/fall keeps its ballistic motion.
            if (enemy.locomotion == "ground" && enemy.airborne)
            {
                if (!hasAnimationOverride)
                {
                    enemy.animationTime = std::max(0.0, enemy.animationTime) + dt;
                }
                const FCharacterEnemyNavigationContext navigation = characterEnemyNavigationContext(state, enemy);
                if (navigation.supports != nullptr)
                {
                    std::string locomotionAnimation = enemy.animationSlot.empty() ? std::string("walk") : enemy.animationSlot;
                    updateCharacterEnemyAirTraversal(state, enemy, dt, *navigation.supports, locomotionAnimation);
                }
            }
            else if (hadHurtPresentation && !hasAnimationOverride)
            {
                enemy.animationTime = std::max(0.0, enemy.animationTime) + dt;
            }

            if (hadHurtPresentation)
            {
                if (enemy.hurtTimer > 0.0)
                {
                    enemy.combatState = "hurt";
                    enemy.movementPhase = "hurt";
                    if (!hasAnimationOverride)
                    {
                        setEnemyAnimationSlot(enemy, "hurt");
                        enemy.state = "hurt";
                    }
                }
                else
                {
                    enemy.combatState = "alive";
                    enemy.movementPhase = enemy.airborne ? std::string("air") : std::string("idle");
                    if (!hasAnimationOverride)
                    {
                        setEnemyAnimationSlot(enemy, enemy.airborne ? std::string("walk") : std::string("idle"));
                        enemy.state = enemy.airborne ? std::string("walk") : std::string("idle");
                    }
                }
            }
            syncCharacterEnemyTarget(state, enemy);
        }
    }

    bool updateStoryWorldSimulation(FGameState& state, double dt)
    {
        // AI decisions and spawners stay frozen, but passive world motion continues.
        // GOTO takes ownership before platform carry; everyone else may ride naturally.
        detachActiveCutsceneGotoCharacter(state);
        updateSignalReceivers(state, dt);
        updateMovingPlatforms(state, dt);
        updateStoryPlayerPassiveMotion(state, dt);
        // The deferred landing gate must not create a physics limbo. Preserve
        // ordinary lethal boundaries only while story presentation is waiting for
        // a grounded start; once authored commands begin, GOTO stays authoritative.
        bool landingPending = false;
        if (const FStoryCutsceneScriptState* cutscene = activeCutsceneScript(state))
        {
            landingPending = cutscene->waitingForPlayerLanding;
        }
        if (!landingPending
            && state.story.mailboxEventIndex >= 0
            && state.story.mailboxEventIndex < static_cast<std::int32_t>(state.story.mailboxEvents.size()))
        {
            landingPending = state.story.mailboxEvents[static_cast<std::size_t>(state.story.mailboxEventIndex)].waitingForPlayerLanding;
        }
        if (landingPending && (applyPlayerWorldBoundsKill(state) || applyPlayerCaveBoundary(state)))
        {
            return true;
        }
        updateStoryEnemyPassiveMotion(state, dt);
        updateProjectiles(state, dt);
        updateWorldEffects(state, dt);
        updateFuelRecharge(state, dt);
        updateHealth(state, dt);
        updateBoostKickGroundRecharge(state, dt);
        return false;
    }

    void updatePortalExitWorldSimulation(FGameState& state, double dt)
    {
        // The exit animation owns only the wizard. The rest of the world keeps
        // simulating normally so enemies and airborne projectiles never freeze.
        updateSignalReceivers(state, dt);
        updateMovingPlatforms(state, dt);
        updateAutomaticEnemySpawning(state, dt);
        updateEnemySpawners(state, dt);
        updateCharacterEnemies(state, dt);
        pruneFinishedAutomaticEnemies(state);
        updateProjectiles(state, dt);
        updateWorldEffects(state, dt);
        updateFuelRecharge(state, dt);
        updateHealth(state, dt);
        updateBoostKickGroundRecharge(state, dt);
    }

    double damagePlayer(FGameState& state, double amount, const std::string& sourceId, bool bypassInvulnerability)
    {
        return damagePlayerInternal(state, amount, sourceId, bypassInvulnerability);
    }

    void clearPlayerLungeState(FGameState& state)
    {
        FPlayerState& player = state.player;
        player.lungeCharging = false;
        player.lungeActive = false;
        player.lungeChargeTime = 0.0;
        player.lungeHoldPending = false;
        player.fireHoldLungePending = false;
        player.fireHoldLungeTime = 0.0;
        player.lungeChargeUsesFire = false;
        player.lungeRechargeReady = true;
        player.lungeCooldownTimer = 0.0;
        player.lungeDistanceRemaining = 0.0;
        player.lungeHitEnemyIds.clear();
        player.lungeHitReactiveObjectIds.clear();
        player.height = state.tuning.playerHeight;
        FRocketState& rocket = state.equipment.rocket;
        if (rocket.state == "lunge") rocket.state = "mountedReady";
        rocket.boostAccelerationNow = 0.0;
        rocket.boostVisualPowerNow = 0.0;
        rocket.attachedSmokeTimer = 0.0;
    }

    double playerLungeHitboxHeight(const FGameState& state)
    {
        return std::clamp(state.tuning.playerLungeHitboxHeight, 8.0, std::max(8.0, state.tuning.playerHeight));
    }

    void setPlayerLungeHitbox(FGameState& state, bool active)
    {
        state.player.height = active ? playerLungeHitboxHeight(state) : state.tuning.playerHeight;
    }

    bool cancelPlayerLungeCharge(FGameState& state, const std::string& reason)
    {
        if (!state.player.lungeCharging) return false;
        state.player.lungeCharging = false;
        state.player.lungeChargeTime = 0.0;
        state.player.lungeChargeUsesFire = false;
        state.equipment.rocket.attachedSmokeTimer = 0.0;
        setPlayerLungeHitbox(state, false);
        addEvent(state, "PLAYER_LUNGE_CHARGE_CANCELLED");
        if (!state.debug.lastEvents.empty()) state.debug.lastEvents.back().reason = reason;
        return true;
    }

    bool startPlayerLungeCharge(FGameState& state, bool useFireButton = false)
    {
        FPlayerState& player = state.player;
        if (!state.playerProgression.lungeUnlocked || playerCursed(state)) return false;
        if (player.lungeCharging || player.lungeActive || !player.onGround || flightPowerUpActive(state) || player.inWater) return false;
        if (state.equipment.rocket.attachedBoosting) stopAttachedBoost(state);
        player.lungeCharging = true;
        player.lungeChargeTime = 0.0;
        player.lungeChargeUsesFire = useFireButton;
        player.vx = 0.0;
        player.ax = 0.0;
        player.groundStride = FGroundStrideState{};
        state.equipment.rocket.attachedSmokeTimer = 0.0;
        setPlayerLungeHitbox(state, true);
        addEvent(state, "PLAYER_LUNGE_CHARGE_STARTED");
        return true;
    }

    bool startPlayerLunge(FGameState& state)
    {
        FPlayerState& player = state.player;
        const FGameTuning& tuning = state.tuning;
        if (!player.lungeCharging || player.lungeChargeTime + 1e-9 < tuning.playerLungeChargeSeconds) return false;
        if (playerCursed(state))
        {
            cancelPlayerLungeCharge(state, "cursed");
            return false;
        }
        if (flightPowerUpActive(state) || player.inWater)
        {
            cancelPlayerLungeCharge(state, player.inWater ? "water" : "flight");
            return false;
        }
        if (!player.onGround || !player.lungeRechargeReady) return false;
        const double fuelCost = std::max(0.0, tuning.attachedBoostKickFuelCost);
        if (state.fuel.amount + 1e-9 < fuelCost)
        {
            cancelPlayerLungeCharge(state, "fuelEmpty");
            addEvent(state, "PLAYER_LUNGE_BLOCKED");
            return false;
        }

        state.fuel.amount = std::clamp(state.fuel.amount - fuelCost, 0.0, state.fuel.max);
        markPlayerLungeFuelUse(state);
        player.lungeRechargeReady = false;
        player.lungeCharging = false;
        player.lungeChargeUsesFire = false;
        player.lungeActive = true;
        player.lungeChargeTime = std::max(player.lungeChargeTime, tuning.playerLungeChargeSeconds);
        player.lungeCooldownTimer = 0.0;
        const double lungeSpeed = effectivePlayerLungeSpeed(state);
        player.lungeDistanceRemaining = lungeSpeed * std::max(0.0, tuning.playerLungeDurationSeconds);
        player.lungeDirection = player.facing < 0 ? -1 : 1;
        player.lungeSequence += 1;
        player.lungeHitEnemyIds.clear();
        player.lungeHitReactiveObjectIds.clear();
        cancelMagicRingConcealment(state, "lunge");
        player.vx = static_cast<double>(player.lungeDirection) * lungeSpeed;
        player.vy = 0.0;
        player.ax = 0.0;
        player.ay = 0.0;
        player.onGround = false;
        player.supportId.clear();
        player.groundStride = FGroundStrideState{};
        player.ordinaryJumpActive = false;
        player.airBoostArmed = false;
        setPlayerLungeHitbox(state, true);

        FRocketState& rocket = state.equipment.rocket;
        rocket.state = "lunge";
        rocket.attachedBoosting = false;
        rocket.attachedBoostTime = 0.0;
        rocket.boostAccelerationNow = 0.0;
        rocket.boostVisualPowerNow = 1.0;
        rocket.attachedSmokeTimer = 0.0;
        addEvent(state, "PLAYER_LUNGE_STARTED");
        return true;
    }

    bool finishPlayerLunge(FGameState& state, const std::string& reason)
    {
        FPlayerState& player = state.player;
        if (!player.lungeActive) return false;
        player.lungeActive = false;
        player.lungeDistanceRemaining = 0.0;
        player.vx = 0.0;
        player.vy = 0.0;
        player.ax = 0.0;
        player.ay = state.tuning.gravity;
        player.lungeHitEnemyIds.clear();
        player.lungeHitReactiveObjectIds.clear();
        setPlayerLungeHitbox(state, false);
        FRocketState& rocket = state.equipment.rocket;
        if (rocket.state == "lunge") rocket.state = "mountedReady";
        rocket.boostAccelerationNow = 0.0;
        rocket.boostVisualPowerNow = 0.0;
        rocket.attachedSmokeTimer = 0.0;
        addEvent(state, "PLAYER_LUNGE_ENDED");
        if (!state.debug.lastEvents.empty()) state.debug.lastEvents.back().reason = reason;
        return true;
    }

    void updatePlayerLungeRecharge(FGameState& state)
    {
        if (state.player.lungeRechargeReady) return;
        if (state.fuel.amount + 1e-9 >= std::max(0.0, state.fuel.max))
        {
            state.player.lungeRechargeReady = true;
            state.player.lungeCooldownTimer = 0.0;
            addEvent(state, "PLAYER_LUNGE_RECHARGED");
        }
    }

    void updatePlayerBodySlamRecharge(FGameState& state)
    {
        FPlayerState& player = state.player;
        if (player.bodySlamRechargeReady) return;
        if (state.fuel.amount + 1e-9 >= std::max(0.0, state.fuel.max))
        {
            player.bodySlamRechargeReady = true;
            player.fallImpactExplosionCooldownTimer = 0.0;
            addEvent(state, "PLAYER_BODY_SLAM_RECHARGED");
        }
    }

    void updatePlayerBodySlamImmunityTimer(FGameState& state, double dt)
    {
        state.player.bodySlamImmunityTimer = std::max(
            0.0,
            state.player.bodySlamImmunityTimer - std::max(0.0, dt));
    }

    bool playerFallWouldDamageAtSpeed(const FGameState& state, double verticalSpeed)
    {
        return state.tuning.fallDamageEnabled
            && state.tuning.fallDamagePerWizardHeight > 0.0
            && std::max(0.0, verticalSpeed) > std::max(0.0, state.tuning.fallDamageSafeImpactSpeed) + 1e-9;
    }

    bool updatePlayerBodySlamCommitment(FGameState& state, FInputFrame& input, bool flightActive)
    {
        FPlayerState& player = state.player;
        if (player.bodySlamCommitted) return true;
        if (playerCursed(state)) return false;
        if (!state.playerProgression.fallImpactExplosionUnlocked
            || player.onGround
            || player.inWater
            || flightActive
            || player.lungeCharging
            || player.lungeActive
            || !input.dropHeld
            || !player.bodySlamRechargeReady
            || !playerFallWouldDamageAtSpeed(state, player.vy))
        {
            return false;
        }

        const double fuelCost = std::max(0.0, state.tuning.playerBodySlamFuelCost);
        if (state.fuel.amount + 1e-9 < fuelCost)
        {
            return false;
        }

        // Intentional approximation: an ordinary hit may land on the tick just
        // before the descent becomes fast enough to commit. Do not delay or
        // retroactively undo damage merely to predict a slam one tick ahead.
        state.fuel.amount = clamp(state.fuel.amount - fuelCost, 0.0, state.fuel.max);
        markPlayerBodySlamFuelUse(state);
        player.bodySlamRechargeReady = false;
        player.fallImpactExplosionCooldownTimer = 0.0;
        player.bodySlamCommitted = true;
        cancelMagicRingConcealment(state, "bodySlam");
        player.ordinaryJumpActive = false;
        player.airBoostArmed = false;
        if (state.equipment.rocket.attachedBoosting) stopAttachedBoost(state);
        addEvent(state, "PLAYER_BODY_SLAM_COMMITTED");
        if (!state.debug.lastEvents.empty())
        {
            FDebugEvent& event = state.debug.lastEvents.back();
            event.x = player.x;
            event.y = player.y;
            event.impactVy = player.vy;
        }
        return true;
    }

    bool cancelPlayerBodySlamCommitment(FGameState& state, const std::string& reason)
    {
        if (!state.player.bodySlamCommitted) return false;
        state.player.bodySlamCommitted = false;
        addEvent(state, "PLAYER_BODY_SLAM_CANCELLED");
        if (!state.debug.lastEvents.empty()) state.debug.lastEvents.back().reason = reason;
        return true;
    }

    bool playerCanStartHeldLungeCharge(
        const FGameState& state,
        const FInputFrame& input,
        bool flightActive,
        bool allowWeaponInput = false,
        bool allowHorizontalMovement = false)
    {
        const FPlayerState& player = state.player;
        if (!state.playerProgression.lungeUnlocked
            || playerCursed(state)
            || player.lungeCharging
            || player.lungeActive
            || !player.onGround
            || player.inWater
            || flightActive)
        {
            return false;
        }
        if (!allowHorizontalMovement)
        {
            const double digitalMoveAxis = (input.moveRight ? 1.0 : 0.0) - (input.moveLeft ? 1.0 : 0.0);
            const double analogMoveAxis = std::isfinite(input.moveAxis) ? std::clamp(input.moveAxis, -1.0, 1.0) : 0.0;
            if (std::abs(digitalMoveAxis) > 0.001 || std::abs(analogMoveAxis) > 0.001) return false;
        }
        if (input.jumpPressed || input.jumpHeld || input.boostPressed || input.boostHeld
            || input.dropPressed || input.dropHeld)
        {
            return false;
        }
        if (!allowWeaponInput && input.weaponPressed) return false;
        return (allowHorizontalMovement || std::abs(player.vx) <= 0.001)
            && std::abs(player.vy) <= 0.001;
    }

    void updatePlayerFireHoldLungeInputState(FGameState& state, FInputFrame& input, double dt, bool flightActive)
    {
        FPlayerState& player = state.player;
        if (playerCursed(state))
        {
            player.fireHoldLungePending = false;
            player.fireHoldLungeTime = 0.0;
            return;
        }

        if (player.lungeCharging)
        {
            player.fireHoldLungePending = false;
            player.fireHoldLungeTime = 0.0;
            if (player.lungeChargeUsesFire)
            {
                input.lungeHeld = input.lungeHeld || input.weaponHeld;
                input.lungeReleased = input.lungeReleased || input.weaponReleased;
                input.weaponPressed = input.weaponHeld = input.weaponReleased = false;
            }
            return;
        }

        if (player.lungeActive)
        {
            player.fireHoldLungePending = false;
            player.fireHoldLungeTime = 0.0;
            return;
        }

        if (!player.fireHoldLungePending)
        {
            if (!(state.playerProgression.lungeUnlocked && input.weaponPressed && input.weaponHeld)) return;
            player.fireHoldLungePending = true;
            player.fireHoldLungeTime = 0.0;
            // Fire keeps its ordinary button-down action. Holding the same press
            // merely arms an alternate lunge that waits until Ignatius is grounded
            // and completely still before its hold timer begins.
        }

        if (!input.weaponHeld || input.weaponReleased)
        {
            player.fireHoldLungePending = false;
            player.fireHoldLungeTime = 0.0;
            return;
        }

        const bool canStartTimer = playerCanStartHeldLungeCharge(state, input, flightActive, true);
        if (!canStartTimer)
        {
            player.fireHoldLungeTime = 0.0;
            return;
        }

        const double threshold = std::max(0.01, state.tuning.playerFireHoldLungeSeconds);
        player.fireHoldLungeTime = std::min(threshold, player.fireHoldLungeTime + std::max(0.0, dt));
        if (player.fireHoldLungeTime + 1e-9 < threshold) return;

        player.fireHoldLungePending = false;
        player.fireHoldLungeTime = 0.0;
        player.lungeChargeUsesFire = true;
        input.lungePressed = true;
        input.lungeHeld = true;
        input.weaponPressed = input.weaponHeld = input.weaponReleased = false;
    }

    void updatePlayerLungeInputState(FGameState& state, FInputFrame& input, double dt, bool flightActive)
    {
        FPlayerState& player = state.player;
        if (playerCursed(state))
        {
            player.lungeHoldPending = false;
            player.lungeChargeUsesFire = false;
            if (player.lungeCharging) cancelPlayerLungeCharge(state, "cursed");
            return;
        }
        if (player.lungeActive)
        {
            input.jumpPressed = input.jumpHeld = input.jumpReleased = false;
            input.boostPressed = input.boostHeld = input.boostReleased = false;
            input.weaponPressed = input.weaponHeld = input.weaponReleased = false;
            input.dropPressed = input.dropHeld = input.dropReleased = false;
            input.interactPressed = input.interactHeld = input.interactReleased = false;
            input.lungePressed = input.lungeHeld = input.lungeReleased = false;
            return;
        }

        if (player.lungeCharging && (flightActive || player.inWater))
        {
            cancelPlayerLungeCharge(state, player.inWater ? "water" : "flight");
        }

        if (player.lungeCharging && (input.jumpPressed || input.boostPressed || input.dropPressed || input.dropHeld || input.weaponPressed))
        {
            cancelPlayerLungeCharge(state, input.weaponPressed ? "weapon" : ((input.dropPressed || input.dropHeld) ? "drop" : "jump"));
            input.jumpPressed = input.jumpHeld = false;
            input.boostPressed = input.boostHeld = false;
            input.dropPressed = input.dropHeld = false;
            input.weaponPressed = input.weaponHeld = false;
        }

        if (!player.lungeCharging && player.lungeChargeUsesFire && input.lungePressed && input.lungeHeld)
        {
            if (!startPlayerLungeCharge(state, true)) player.lungeChargeUsesFire = false;
        }

        if (!player.lungeCharging)
        {
            if (!player.lungeHoldPending && state.playerProgression.lungeUnlocked && input.lungePressed && input.lungeHeld)
            {
                player.lungeHoldPending = true;
            }
            if (player.lungeHoldPending && (!input.lungeHeld || input.lungeReleased))
            {
                player.lungeHoldPending = false;
            }
            if (player.lungeHoldPending && playerCanStartHeldLungeCharge(state, input, flightActive, false, true))
            {
                player.lungeHoldPending = false;
                startPlayerLungeCharge(state, false);
            }
        }
        if (!player.lungeCharging) return;
        player.lungeHoldPending = false;

        // Apply this tick's charge-turn input before an automatic launch captures
        // lungeDirection at the charge/cooldown threshold.
        const double digitalMoveAxis = (input.moveRight ? 1.0 : 0.0) - (input.moveLeft ? 1.0 : 0.0);
        const double analogMoveAxis = std::isfinite(input.moveAxis) ? std::clamp(input.moveAxis, -1.0, 1.0) : 0.0;
        const double chargeMoveAxis = std::abs(analogMoveAxis) > 0.001 ? analogMoveAxis : digitalMoveAxis;
        if (std::abs(chargeMoveAxis) > 0.001) player.facing = chargeMoveAxis > 0.0 ? 1 : -1;

        const double chargeSeconds = std::max(0.0, state.tuning.playerLungeChargeSeconds);
        bool charged = player.lungeChargeTime + 1e-9 >= chargeSeconds;
        // Native can see a physical release edge from one mapped Alt/Shift/gamepad
        // key while another lunge binding remains held. Only the aggregate action
        // being up should cancel the charge.
        if (!charged && !input.lungeHeld && (input.lungeReleased || !input.lungePressed))
        {
            cancelPlayerLungeCharge(state, "releasedEarly");
            return;
        }
        if (!charged && input.lungeHeld)
        {
            player.lungeChargeTime = std::min(chargeSeconds, player.lungeChargeTime + std::max(0.0, dt));
            charged = player.lungeChargeTime + 1e-9 >= chargeSeconds;
        }
        if (charged)
        {
            player.lungeChargeTime = std::max(player.lungeChargeTime, chargeSeconds);
            if (!player.lungeRechargeReady && !input.lungeHeld)
            {
                cancelPlayerLungeCharge(state, "releasedDuringRecharge");
                return;
            }
            startPlayerLunge(state);
        }
    }

    struct FPlayerLungeMovement
    {
        bool blocked = false;
        double traveled = 0.0;
        double previousX = 0.0;
        std::string blockingReactiveObjectId;
    };

    struct FPlayerLungeSweepHit
    {
        double x = 0.0;
        double contactX = 0.0;
        std::string side;
        std::string id;
        std::string kind;
        std::string source;
        std::string reactiveObjectId;
        std::string visualId;
    };

    bool playerLungeReactiveObjectIsActive(const FReactiveObjectState& object)
    {
        return object.state != "destroyed" && object.state != "inactive" && object.health > 0.0;
    }

    std::string reactiveObjectIdForPlayerLungeCollision(const FGameState& state, const FPlayerLungeSweepHit& collision)
    {
        if (!collision.reactiveObjectId.empty())
        {
            const auto found = std::find_if(state.reactiveObjects.begin(), state.reactiveObjects.end(), [&](const FReactiveObjectState& object)
            {
                return object.id == collision.reactiveObjectId && playerLungeReactiveObjectIsActive(object);
            });
            if (found != state.reactiveObjects.end()) return found->id;
        }
        if (collision.visualId.empty()) return {};
        const auto found = std::find_if(state.reactiveObjects.begin(), state.reactiveObjects.end(), [&](const FReactiveObjectState& object)
        {
            return object.visualId == collision.visualId && playerLungeReactiveObjectIsActive(object);
        });
        return found != state.reactiveObjects.end() ? found->id : std::string{};
    }

    std::unordered_set<std::string> playerLungeBlockingReactiveObjectIds(const FGameState& state)
    {
        std::unordered_set<std::string> ids;
        for (const FReactiveObjectState& object : state.reactiveObjects)
        {
            if (object.id.empty() || !playerLungeReactiveObjectIsActive(object)) continue;
            if (object.blocksPlayer || object.hasAuthoredPlayerBlockingCollision) ids.insert(object.id);
        }
        return ids;
    }

    std::vector<std::pair<double, double>> playerLungePolygonIntervalsAtY(
        const std::vector<FWorldPoint>& points,
        double y)
    {
        std::vector<double> crossings;
        if (points.size() < 3) return {};
        for (std::size_t index = 0; index < points.size(); ++index)
        {
            const FWorldPoint& a = points[index];
            const FWorldPoint& b = points[(index + 1) % points.size()];
            if (std::abs(b.y - a.y) <= 0.000001) continue;
            const bool crosses = (a.y <= y && b.y > y) || (b.y <= y && a.y > y);
            if (!crosses) continue;
            const double t = (y - a.y) / (b.y - a.y);
            crossings.push_back(a.x + (b.x - a.x) * t);
        }
        std::sort(crossings.begin(), crossings.end());
        std::vector<std::pair<double, double>> intervals;
        for (std::size_t index = 0; index + 1 < crossings.size(); index += 2)
        {
            intervals.emplace_back(crossings[index], crossings[index + 1]);
        }
        return intervals;
    }

    std::optional<FPlayerLungeSweepHit> findPlayerLungeHorizontalSweepCollision(
        const FGameState& state,
        double previousX,
        double nextX)
    {
        const FPlayerState& player = state.player;
        const double dx = nextX - previousX;
        if (std::abs(dx) <= 0.000001) return std::nullopt;

        const double previousLeft = previousX - player.width * 0.5;
        const double previousRight = previousX + player.width * 0.5;
        const double currentLeft = nextX - player.width * 0.5;
        const double currentRight = nextX + player.width * 0.5;
        const double top = player.y - player.height;
        const double bottom = player.y;
        const double ySamples[3] = {
            player.y - player.height * 0.84,
            player.y - player.height * 0.50,
            player.y - player.height * 0.16
        };
        constexpr double skin = 3.0;
        const FWorldBounds query{
            std::min(previousLeft, currentLeft) - skin,
            top - skin,
            std::max(previousRight, currentRight) + skin,
            bottom + skin
        };

        std::optional<FPlayerLungeSweepHit> best;
        const auto consider = [&](double contactX,
            const std::string& id,
            const std::string& kind,
            const std::string& source,
            const std::string& reactiveObjectId,
            const std::string& visualId)
        {
            if (!std::isfinite(contactX)) return;
            if (dx > 0.0)
            {
                if (previousRight > contactX + skin || currentRight < contactX - skin) return;
                if (!best.has_value() || contactX < best->contactX)
                {
                    best = FPlayerLungeSweepHit{ contactX - player.width * 0.5, contactX, "right", id, kind, source, reactiveObjectId, visualId };
                }
            }
            else
            {
                if (previousLeft < contactX - skin || currentLeft > contactX + skin) return;
                if (!best.has_value() || contactX > best->contactX)
                {
                    best = FPlayerLungeSweepHit{ contactX + player.width * 0.5, contactX, "left", id, kind, source, reactiveObjectId, visualId };
                }
            }
        };

        for (const FWorldSolid* solid : queryWorldSolids(state.world, query))
        {
            if (!solid || bottom <= solid->y + 0.05 || top >= solid->y + solid->h - 0.05) continue;
            consider(dx > 0.0 ? solid->x : solid->x + solid->w,
                solid->id,
                solid->kind.empty() ? std::string("solid") : solid->kind,
                "solid",
                solid->reactiveObjectId,
                "");
        }

        for (const FWorldSegment* segment : queryWorldSegments(state.world, query))
        {
            if (!segment || segment->kind == "walkable" || !isAreaBlockingLineKind(segment->kind)) continue;
            if (std::abs(segment->y2 - segment->y1) <= std::abs(segment->x2 - segment->x1) * 0.75) continue;
            for (double y : ySamples)
            {
                if (const std::optional<double> x = segmentXAtY(
                    FWorldPoint{ segment->x1, segment->y1 },
                    FWorldPoint{ segment->x2, segment->y2 },
                    y))
                {
                    consider(*x, segment->id, segment->kind, "segment", "", segment->visualId);
                }
            }
        }

        for (const FWorldCollisionPolygon* polygon : queryWorldCollisionPolygons(state.world, query))
        {
            if (!polygon || !isAreaBlockingLineKind(polygon->kind)) continue;
            for (double y : ySamples)
            {
                for (const auto& interval : playerLungePolygonIntervalsAtY(polygon->points, y))
                {
                    consider(dx > 0.0 ? interval.first : interval.second, polygon->id, polygon->kind, "polygon", "", polygon->visualId);
                }
            }
        }
        return best;
    }

    FPlayerLungeMovement movePlayerLungeX(FGameState& state, double dx)
    {
        FPlayerLungeMovement result;
        result.previousX = state.player.x;
        state.player.groundStride = FGroundStrideState{};
        const double nextX = result.previousX + dx;
        const std::optional<FPlayerLungeSweepHit> collision = findPlayerLungeHorizontalSweepCollision(state, result.previousX, nextX);
        if (!collision.has_value())
        {
            state.player.x = nextX;
            result.traveled = std::abs(dx);
            return result;
        }

        state.player.x = collision->x;
        state.player.vx = 0.0;
        if (collision->side == "right") state.collisions.playerTouching.right = true;
        else state.collisions.playerTouching.left = true;
        state.collisions.lastResolution.hasResolution = true;
        state.collisions.lastResolution.axis = "x";
        state.collisions.lastResolution.direction = collision->side;
        state.collisions.lastResolution.id = collision->id;
        state.collisions.lastResolution.kind = collision->kind;
        state.collisions.lastResolution.source = collision->source;
        state.collisions.lastResolution.distance = std::abs(state.player.x - result.previousX);
        result.blocked = true;
        result.traveled = state.collisions.lastResolution.distance;
        result.blockingReactiveObjectId = reactiveObjectIdForPlayerLungeCollision(state, *collision);
        return result;
    }

    void damageTargetsFromPlayerLunge(FGameState& state, double previousX, double currentX, const std::string& blockingReactiveObjectId)
    {
        FPlayerState& player = state.player;
        const double damage = std::max(0.0, state.tuning.playerLungeDamage);
        const std::string sourceId = std::string("player_lunge_") + std::to_string(player.lungeSequence);
        const std::unordered_set<std::string> blockingObjectIds = playerLungeBlockingReactiveObjectIds(state);
        constexpr double contactPadding = 4.0;
        const FWorldRect sweptRect{
            std::min(previousX, currentX) - player.width * 0.5 - contactPadding,
            player.y - player.height,
            std::abs(currentX - previousX) + player.width + contactPadding * 2.0,
            player.height
        };
        for (FEnemyState& enemy : state.enemies)
        {
            if (enemy.id.empty() || enemy.health <= 0.0 || enemy.combatState == "dead") continue;
            if (std::find(player.lungeHitEnemyIds.begin(), player.lungeHitEnemyIds.end(), enemy.id) != player.lungeHitEnemyIds.end()) continue;
            if (!rectsOverlap(sweptRect, enemyProjectileHitbox(actorGeometryForEnemy(enemy)))) continue;
            player.lungeHitEnemyIds.push_back(enemy.id);
            damageEnemy(state, enemy, damage, sourceId);
        }
        if (!blockingReactiveObjectId.empty()
            && std::find(player.lungeHitReactiveObjectIds.begin(), player.lungeHitReactiveObjectIds.end(), blockingReactiveObjectId) == player.lungeHitReactiveObjectIds.end())
        {
            const auto found = std::find_if(state.reactiveObjects.begin(), state.reactiveObjects.end(), [&](const FReactiveObjectState& object)
            {
                return object.id == blockingReactiveObjectId && playerLungeReactiveObjectIsActive(object);
            });
            if (found != state.reactiveObjects.end())
            {
                player.lungeHitReactiveObjectIds.push_back(found->id);
                FProjectileState lungeProjectile;
                lungeProjectile.id = sourceId;
                lungeProjectile.damage = damage;
                applyProjectileDamageToReactiveObject(state, lungeProjectile, *found);
            }
        }
        for (FReactiveObjectState& object : state.reactiveObjects)
        {
            if (object.id.empty() || !playerLungeReactiveObjectIsActive(object)) continue;
            if (std::find(player.lungeHitReactiveObjectIds.begin(), player.lungeHitReactiveObjectIds.end(), object.id) != player.lungeHitReactiveObjectIds.end()) continue;
            if (blockingObjectIds.contains(object.id)) continue;
            if (!rectsOverlap(sweptRect, reactiveObjectCollisionRect(object))) continue;
            player.lungeHitReactiveObjectIds.push_back(object.id);
            FProjectileState lungeProjectile;
            lungeProjectile.id = sourceId;
            lungeProjectile.damage = damage;
            applyProjectileDamageToReactiveObject(state, lungeProjectile, object);
        }
    }

    bool advancePlayerLunge(FGameState& state, double dt)
    {
        FPlayerState& player = state.player;
        if (!player.lungeActive) return false;
        const double speed = effectivePlayerLungeSpeed(state);
        const double stepDistance = std::min(std::max(0.0, player.lungeDistanceRemaining), speed * std::max(0.0, dt));
        if (stepDistance <= 0.000001)
        {
            finishPlayerLunge(state, "complete");
            return true;
        }
        player.vx = static_cast<double>(player.lungeDirection) * speed;
        player.vy = 0.0;
        player.ax = 0.0;
        player.ay = 0.0;
        const FPlayerLungeMovement movement = movePlayerLungeX(state, static_cast<double>(player.lungeDirection) * stepDistance);
        damageTargetsFromPlayerLunge(state, movement.previousX, player.x, movement.blockingReactiveObjectId);
        player.lungeDistanceRemaining = std::max(0.0, player.lungeDistanceRemaining - movement.traveled);
        emitPlayerLungeSmoke(state, dt, 5.0);
        if (movement.blocked) finishPlayerLunge(state, "blocked");
        else if (player.lungeDistanceRemaining <= 0.000001) finishPlayerLunge(state, "complete");
        return true;
    }

    FGameState& stepSimulation(FGameState& state)
    {
        return stepSimulation(state, createInputFrame(), state.clock.simulationDt > 0.0 ? state.clock.simulationDt : MAX_SIM_DT);
    }

    FGameState& stepSimulation(FGameState& state, const FInputFrame& inputFrame)
    {
        return stepSimulation(state, inputFrame, state.clock.simulationDt > 0.0 ? state.clock.simulationDt : MAX_SIM_DT);
    }

    FGameState& stepSimulation(FGameState& state, const FInputFrame& inputFrame, double dt)
    {
        state.debug.simulationTimings = FSimulationStepTimings{};
        const double safeDt = std::max(0.000001, dt);
        state.debug.lastInputFrame = inputFrame;
        FInputFrame input = inputFrame;
        if (state.player.lungeActive)
        {
            input.interactPressed = input.interactHeld = input.interactReleased = false;
        }
        state.clock.tick += 1;
        state.clock.time += safeDt;
        state.clock.simulationDt = safeDt;
        state.equipment.rocket.fuelBulbFlashTimer = std::max(0.0, state.equipment.rocket.fuelBulbFlashTimer - safeDt);
        updateStatusEffects(state, safeDt);
        updatePickupRespawns(state, safeDt);
        updateReactiveAssetVisualFades(state, safeDt);

        // Death owns the frame before any modal story controller, matching the
        // browser runtime. In particular, a deferred story landing that crosses
        // a lethal world boundary must be allowed to advance through its normal
        // death phases instead of remaining trapped behind the active story.
        if (!playerDeathActive(state) && state.health.amount <= 0.0)
        {
            startPlayerDeath(state, "healthZero", "healthDepleted");
        }
        if (state.player.combatState == "dead")
        {
            updatePlayerDeath(state, safeDt);
            return state;
        }

        if (activeCutsceneScript(state))
        {
            if (updateStoryWorldSimulation(state, safeDt))
            {
                return state;
            }
            updateCutsceneScript(state, inputFrame, safeDt);
            return state;
        }

        updateProximityTexts(state, safeDt);
        updateOverheadSymbol(state, safeDt);
        if (updatePortalIntro(state, safeDt))
        {
            return state;
        }
        const FStoryMailboxEventState* mailboxBeforeUpdate = nullptr;
        if (state.story.mailboxEventIndex >= 0
            && state.story.mailboxEventIndex < static_cast<std::int32_t>(state.story.mailboxEvents.size()))
        {
            mailboxBeforeUpdate = &state.story.mailboxEvents[static_cast<std::size_t>(state.story.mailboxEventIndex)];
        }
        const bool mailboxLandingWasPending = mailboxBeforeUpdate && mailboxBeforeUpdate->active && mailboxBeforeUpdate->waitingForPlayerLanding;
        if (mailboxLandingWasPending)
        {
            if (updateStoryWorldSimulation(state, safeDt))
            {
                return state;
            }
        }
        if (updateMailboxStory(state, input, safeDt))
        {
            const FStoryMailboxEventState* mailboxAfterUpdate = nullptr;
            if (state.story.mailboxEventIndex >= 0
                && state.story.mailboxEventIndex < static_cast<std::int32_t>(state.story.mailboxEvents.size()))
            {
                mailboxAfterUpdate = &state.story.mailboxEvents[static_cast<std::size_t>(state.story.mailboxEventIndex)];
            }
            if (!mailboxLandingWasPending && mailboxAfterUpdate && mailboxAfterUpdate->waitingForPlayerLanding)
            {
                if (updateStoryWorldSimulation(state, safeDt))
                {
                    return state;
                }
            }
            return state;
        }
        if (updatePortalExit(state, safeDt))
        {
            updatePortalExitWorldSimulation(state, safeDt);
            return state;
        }
        if (updateCutsceneScript(state, inputFrame, safeDt))
        {
            updateStoryWorldSimulation(state, safeDt);
            return state;
        }

        if (inputFrame.resetPressed)
        {
            resetPlayer(state, "manualReset");
            return state;
        }

        if (applyPlayerWorldBoundsKill(state))
        {
            return state;
        }
        if (applyPlayerCaveBoundary(state))
        {
            return state;
        }

        updateCheckpointRunes(state);
        updateTreasureChests(state, safeDt);
        updatePickups(state);
        const FWaterImmersion waterBefore = refreshPlayerWaterState(state);
        if (waterBefore.inWater && state.equipment.rocket.attachedBoosting)
        {
            stopAttachedBoost(state);
        }
        const bool flightActive = flightPowerUpActive(state) && !waterBefore.inWater && !state.player.bodySlamCommitted;
        if (!flightActive && state.equipment.rocket.state == "flight")
        {
            state.equipment.rocket.state = "mountedReady";
            state.equipment.rocket.attachedBoostTime = 0.0;
            state.equipment.rocket.boostAccelerationNow = 0.0;
            state.equipment.rocket.boostVisualPowerNow = 0.0;
            state.equipment.rocket.attachedSmokeTimer = 0.0;
        }

        updateSignalEmitters(state, input, dt);
        updateSignalReceivers(state, dt);
        updatePlayerLungeRecharge(state);
        updatePlayerBodySlamRecharge(state);
        updatePlayerBodySlamImmunityTimer(state, safeDt);
        updatePlayerFireHoldLungeInputState(state, input, safeDt, flightActive);
        updatePlayerLungeInputState(state, input, safeDt, flightActive);
        updatePlayerBodySlamCommitment(state, input, flightActive);
        if (state.player.bodySlamCommitted)
        {
            input.jumpPressed = input.jumpHeld = input.jumpReleased = false;
            input.boostPressed = input.boostHeld = input.boostReleased = false;
        }
        if (state.player.lungeCharging)
        {
            const double chargeSeconds = std::max(0.000001, state.tuning.playerLungeChargeSeconds);
            const double chargeSmokeDensity = clamp(state.player.lungeChargeTime / chargeSeconds, 0.0, 1.0);
            emitPlayerLungeSmoke(state, safeDt, chargeSmokeDensity);
        }

        // A grounded Down press drops through only the green support being left.
        // Holding Down after that remains a fast-fall/double-gravity input, but it
        // must not make the next green line non-solid. Flight/water keep their
        // continuous held-Down pass-through behaviour.
        state.player.dropThroughTimer = std::max(0.0, state.player.dropThroughTimer - std::max(0.0, safeDt));
        if (state.player.dropThroughTimer <= 0.0)
        {
            state.player.dropThroughSupportId.clear();
        }
        cancelScopedPlayerDropThroughForUpwardVelocity(state.player);
        const bool dropIntent = input.dropHeld || input.dropPressed;
        const double dropGrace = std::max(MAX_SIM_DT, state.tuning.playerDropThroughGraceSeconds);
        if (dropIntent && (flightActive || waterBefore.inWater))
        {
            state.player.dropThroughTimer = std::max(state.player.dropThroughTimer, dropGrace);
            state.player.dropThroughSupportId.clear();
        }
        else if (input.dropPressed && state.player.onGround && !input.jumpPressed)
        {
            const FWorldSegment* support = findWorldSegmentById(state, state.player.supportId);
            if (support != nullptr && support->kind == "walkable")
            {
                state.player.dropThroughTimer = std::max(state.player.dropThroughTimer, dropGrace);
                state.player.dropThroughSupportId = state.player.supportId;
            }
        }
        detachPlayerFromMovingWalkableSupportForDropThrough(state);

        const FWorldRect surfaceHazardPlayerRectStart = getPlayerRect(state);
        updateMovingPlatforms(state, safeDt);
        updateAutomaticEnemySpawning(state, safeDt);
        updateEnemySpawners(state, safeDt);
        updateCharacterEnemies(state, safeDt);
        pruneFinishedAutomaticEnemies(state);

        if (state.player.combatState == "dead")
        {
            return state;
        }

        const bool wasOnGround = state.player.onGround;
        const double horizontalVelocityBeforeControl = state.player.vx;
        state.player.wasOnGround = wasOnGround;
        state.player.ax = 0.0;
        state.player.ay = state.tuning.gravity;

        const double digitalMoveAxis = (input.moveRight ? 1.0 : 0.0) - (input.moveLeft ? 1.0 : 0.0);
        const double analogMoveAxis = std::isfinite(input.moveAxis) ? std::clamp(input.moveAxis, -1.0, 1.0) : 0.0;
        const double moveAxis = std::abs(analogMoveAxis) > 0.001 ? analogMoveAxis : digitalMoveAxis;
        const double movementSpeedScale = playerMovementSpeedScale(state);
        if (state.player.lungeActive)
        {
            state.player.vx = static_cast<double>(state.player.lungeDirection) * effectivePlayerLungeSpeed(state);
            state.player.vy = 0.0;
            state.player.ax = 0.0;
            state.player.ay = 0.0;
        }
        else if (state.player.lungeCharging)
        {
            if (std::abs(moveAxis) > 0.001) state.player.facing = moveAxis > 0.0 ? 1 : -1;
            if (waterBefore.inWater)
            {
                state.player.vx = applyWaterDrag(state.player.vx, waterBefore.submersion, state.tuning.waterHorizontalLinearDrag, state.tuning.waterHorizontalQuadraticDrag, safeDt);
            }
            else if (wasOnGround)
            {
                state.player.vx = approachValue(state.player.vx, 0.0, state.tuning.groundFriction * movementSpeedScale * safeDt);
            }
            else
            {
                state.player.vx *= std::max(0.0, 1.0 - state.tuning.airDrag * safeDt);
            }
            state.player.ax = safeDt > 0.0 ? (state.player.vx - horizontalVelocityBeforeControl) / safeDt : 0.0;
        }
        else
        {
            if (waterBefore.inWater)
            {
                const double submergedControl = std::max(0.12, waterBefore.submersion);
                if (std::abs(moveAxis) > 0.001)
                {
                    state.player.facing = moveAxis > 0.0 ? 1 : -1;
                    const double acceleration = state.tuning.groundAcceleration
                        * movementSpeedScale
                        * std::max(0.0, state.tuning.waterHorizontalAccelerationScale)
                        * submergedControl;
                    state.player.vx += moveAxis * acceleration * safeDt;
                    state.player.ax = moveAxis * acceleration;
                }
                state.player.vx = applyWaterDrag(
                    state.player.vx,
                    waterBefore.submersion,
                    state.tuning.waterHorizontalLinearDrag,
                    state.tuning.waterHorizontalQuadraticDrag,
                    safeDt);
            }
            else if (std::abs(moveAxis) > 0.001)
            {
                state.player.facing = moveAxis > 0.0 ? 1 : -1;
                const double acceleration = ((wasOnGround || flightActive)
                    ? state.tuning.groundAcceleration
                    : state.tuning.airAcceleration) * movementSpeedScale;
                state.player.vx += moveAxis * acceleration * safeDt;
                state.player.ax = moveAxis * acceleration;
            }
            else if (flightActive && !wasOnGround)
            {
                const double idleFactor = clamp(state.tuning.flightIdleHorizontalSpeedFactor, 0.0, 1.0);
                if (idleFactor > 0.0)
                {
                    const double flightSpeedLimit = state.tuning.maxRunSpeed * movementSpeedScale * FLIGHT_MOVEMENT_SPEED_MULTIPLIER;
                    const double idleTargetVelocity = (state.player.facing < 0 ? -1.0 : 1.0) * flightSpeedLimit * idleFactor;
                    state.player.vx = approachValue(
                        state.player.vx,
                        idleTargetVelocity,
                        state.tuning.groundAcceleration * movementSpeedScale * safeDt);
                }
                else
                {
                    // Factor zero is the legacy Flight behavior: neutral input brakes to rest.
                    state.player.vx = approachValue(state.player.vx, 0.0, state.tuning.groundFriction * movementSpeedScale * safeDt);
                }
            }
            else if (wasOnGround)
            {
                state.player.vx = approachValue(state.player.vx, 0.0, state.tuning.groundFriction * movementSpeedScale * safeDt);
            }
            else
            {
                state.player.vx *= std::max(0.0, 1.0 - state.tuning.airDrag * safeDt);
            }
            const double levelGroundSpeedLimit = state.tuning.maxRunSpeed
                * movementSpeedScale
                * (waterBefore.inWater
                    ? std::max(0.05, state.tuning.waterHorizontalSpeedScale)
                    : (flightActive ? FLIGHT_MOVEMENT_SPEED_MULTIPLIER : 1.0));
            const double horizontalSpeedLimit = (!waterBefore.inWater && !flightActive && wasOnGround)
                ? playerGroundedHorizontalSpeedLimit(state, levelGroundSpeedLimit)
                : levelGroundSpeedLimit;
            state.player.vx = std::clamp(state.player.vx, -horizontalSpeedLimit, horizontalSpeedLimit);
            state.player.ax = safeDt > 0.0
                ? (state.player.vx - horizontalVelocityBeforeControl) / safeDt
                : 0.0;
        }

        if (!state.player.lungeActive && !state.player.lungeCharging && !flightActive && !waterBefore.inWater)
        {
            if (input.jumpReleased && !wasOnGround && !playerCursed(state))
            {
                state.player.airBoostArmed = true;
            }

            if (input.jumpPressed && wasOnGround)
            {
                state.player.vy = ordinaryJumpVelocity(state.tuning.gravity, state.tuning.ordinaryJumpHeight);
                state.player.onGround = false;
                state.player.ordinaryJumpActive = true;
                state.player.hasOrdinaryJumpStartY = true;
                state.player.ordinaryJumpStartY = state.player.y;
                state.player.hasOrdinaryJumpApexY = false;
                state.player.ordinaryJumpApexY = 0.0;
                state.player.supportId.clear();
                state.player.groundStride = FGroundStrideState{};
                state.player.airborneTime = 0.0;
                state.player.coyoteTimer = 0.0;
                state.player.airBoostArmed = false;
                addEvent(state, "PLAYER_JUMPED");
            }
            else if ((input.jumpPressed || input.boostPressed) && !wasOnGround && !state.equipment.rocket.attachedBoosting)
            {
                if (state.player.airBoostArmed)
                {
                    state.player.airBoostArmed = false;
                    startAttachedBoost(state);
                }
            }
        }

        if (!state.player.lungeActive && !state.player.lungeCharging && !flightActive && !waterBefore.inWater && state.equipment.rocket.attachedBoosting)
        {
            if (input.jumpHeld || input.boostHeld)
            {
                state.equipment.rocket.attachedBoostTime += safeDt;
                state.equipment.rocket.boostBurstTimer = std::max(0.0, state.equipment.rocket.boostBurstTimer - safeDt);
                emitAttachedBoostSmoke(state, safeDt);
                const double drain = std::min(state.fuel.amount, state.tuning.attachedBoostDrainRate * safeDt);
                state.fuel.amount = std::max(0.0, state.fuel.amount - drain);
                markRocketUse(state);
                if (state.fuel.amount <= 0.0)
                {
                    stopAttachedBoost(state);
                }
            }
            else
            {
                stopAttachedBoost(state);
            }
        }

        cancelScopedPlayerDropThroughForUpwardVelocity(state.player);

        if (!state.player.lungeActive && !state.player.lungeCharging && input.weaponPressed && !playerCursed(state))
        {
            launchPlayerRocket(state, input);
        }

        updateProjectiles(state, safeDt);
        updateWorldEffects(state, safeDt);
        if (state.player.combatState == "dead")
        {
            return state;
        }

        const bool lungeOwnedMovement = state.player.lungeActive;
        if (lungeOwnedMovement)
        {
            const double lungeStartX = state.player.x;
            const double lungeStartY = state.player.y;
            advancePlayerLunge(state, safeDt);
            if (!state.player.lungeActive)
            {
                const FPlayerPenetrationResult penetration = resolvePlayerPenetrations(state, lungeStartX, lungeStartY);
                if (penetration.fatal) return state;
            }
        }
        else
        {
        if (waterBefore.inWater || flightActive || !state.player.onGround)
        {
            state.player.groundStride = FGroundStrideState{};
        }
        const bool groundStrideHandled = movePlayerThroughGroundStride(state, state.player.vx * safeDt);
        if (!groundStrideHandled)
        {
            const double previousFeetY = state.player.y;
            double pendingPlayerVerticalDelta = 0.0;
            const double effectiveGravity = std::max(1.0, state.tuning.gravity) * (dropIntent ? 2.0 : 1.0);
            const double initialVy = state.player.vy;
            if (waterBefore.inWater)
            {
                const double submersion = clamp(waterBefore.submersion, 0.0, 1.0);
                const bool upIntent = input.jumpHeld || input.jumpPressed || input.boostHeld || input.boostPressed;
                const bool downIntent = input.dropHeld || input.dropPressed;
                const double verticalInput = (downIntent ? 1.0 : 0.0) - (upIntent ? 1.0 : 0.0);
                const double buoyancyRatio = clamp(state.tuning.waterGravityBuoyancyRatio, 0.0, 0.99);
                const double acceleration = std::max(1.0, state.tuning.gravity) * (1.0 - buoyancyRatio * submersion)
                    + verticalInput * std::max(0.0, state.tuning.waterSwimAcceleration) * submersion;
                state.player.vy += acceleration * safeDt;
                state.player.vy = applyWaterDrag(
                    state.player.vy,
                    submersion,
                    state.tuning.waterLinearDrag,
                    state.tuning.waterQuadraticDrag,
                    safeDt);
                state.player.vy = std::min(state.player.vy, state.tuning.terminalVelocity);
                state.player.ay = (state.player.vy - initialVy) / safeDt;
                state.player.ordinaryJumpActive = false;
                state.player.airBoostArmed = false;
                pendingPlayerVerticalDelta = state.player.vy * safeDt;
            }
            else if (flightActive)
            {
                applyFlightGovernor(state, input, safeDt);
                pendingPlayerVerticalDelta = state.player.vy * safeDt;
            }
            else if (!state.player.ordinaryJumpActive || state.equipment.rocket.attachedBoosting)
            {
                state.player.ay = effectiveGravity;
                state.player.vy = std::min(state.player.vy + effectiveGravity * safeDt, state.tuning.terminalVelocity);
                if (state.equipment.rocket.attachedBoosting)
                {
                    applyAttachedHoverGovernor(state, safeDt);
                }
                pendingPlayerVerticalDelta = state.player.vy * safeDt;
            }
            else
            {
                state.player.ay = effectiveGravity;
                const double finalVy = std::min(initialVy + effectiveGravity * safeDt, state.tuning.terminalVelocity);
                const bool crossesApex = initialVy < 0.0 && finalVy >= 0.0;
                if (!crossesApex)
                {
                    const double effectiveAcceleration = (finalVy - initialVy) / std::max(0.000001, safeDt);
                    pendingPlayerVerticalDelta = initialVy * safeDt + 0.5 * effectiveAcceleration * safeDt * safeDt;
                    state.player.vy = finalVy;
                }
                else
                {
                    const double apexTime = std::min(safeDt, std::max(0.0, -initialVy / effectiveGravity));
                    const double remaining = std::max(0.0, safeDt - apexTime);
                    const double apexDisplacement = initialVy * apexTime + 0.5 * effectiveGravity * apexTime * apexTime;
                    state.player.hasOrdinaryJumpApexY = true;
                    state.player.ordinaryJumpApexY = state.player.y + apexDisplacement;
                    pendingPlayerVerticalDelta = apexDisplacement + 0.5 * effectiveGravity * remaining * remaining;
                    state.player.vy = std::min(effectiveGravity * remaining, state.tuning.terminalVelocity);
                }
            }
            if (!waterBefore.inWater && !flightActive)
            {
                // Observe the post-acceleration velocity before collision so a fall
                // that crosses the damage threshold and lands in this same fixed tick
                // can still commit while Down is held.
                updatePlayerBodySlamCommitment(state, input, false);
            }
            const double previousX = state.player.x;
            state.player.x += state.player.vx * safeDt;
            const double previousY = state.player.y;
            state.player.y += pendingPlayerVerticalDelta;
            // Collision resolution may zero vertical velocity before the final
            // support branch runs.  Preserve the browser's pre-landing impact speed
            // so every landing path uses the same fall-damage input.
            const double landingImpactVy = std::max(0.0, state.player.vy);
            resolveBlockingSegmentHorizontal(state, previousX, previousFeetY);
            const FPlayerPenetrationResult penetration = resolvePlayerPenetrations(state, previousX, previousY);
            if (penetration.fatal)
            {
                return state;
            }
            const bool penetrationLandedThisStep = penetration.grounded && !wasOnGround;

            // Match reference/src/core/simulation.js ground probes exactly.
            // The browser samples the centre foot first, then x +/- width * 0.42.
            // A narrower footprint makes the native player leave inset walkable
            // platform edges one or more fixed steps too early.
            const double sampleXs[3] = {
                state.player.x,
                state.player.x - state.player.width * 0.42,
                state.player.x + state.player.width * 0.42
            };

            std::optional<FGroundSupportHit> bestSupport;
            for (double sampleX : sampleXs)
            {
                const std::optional<FGroundSupportHit> support = findGroundSupportHit(
                    state,
                    sampleX,
                    previousFeetY,
                    state.player.y,
                    !playerIgnoresAllWalkableCollisions(state.player),
                    wasOnGround);
                if (support.has_value())
                {
                    bestSupport = support;
                    break;
                }
            }

            const bool playerMovingUpward = pendingPlayerVerticalDelta < -0.000001 && state.player.vy < -0.000001;
            if (wasOnGround && !playerMovingUpward)
            {
                const std::optional<FGroundSupportHit> sweptSupport = findPlayerSweptGroundSupportHit(
                    state,
                    previousX,
                    previousFeetY,
                    state.player.x,
                    !playerIgnoresAllWalkableCollisions(state.player));
                if (sweptSupport.has_value() && (!bestSupport.has_value() || sweptSupport->y < bestSupport->y))
                {
                    bestSupport = sweptSupport;
                }
            }

            if (bestSupport.has_value() && !playerMovingUpward && (state.player.vy >= 0.0 || state.player.onGround))
            {
                state.player.y = bestSupport->y;
                state.player.vy = 0.0;
                state.player.onGround = true;
                state.player.ordinaryJumpActive = false;
                state.player.supportId = bestSupport->id;
                // Being grounded grants the rocket kick and makes the next distinct
                // airborne Up press eligible. A normal ground jump disarms it above
                // until that same Up press has been released.
                state.player.airBoostArmed = true;
                if (state.equipment.rocket.attachedBoosting)
                {
                    stopAttachedBoost(state);
                }
                if (!wasOnGround)
                {
                    const double fallDamage = applyFallDamageOnLanding(state, landingImpactVy, bestSupport->id, bestSupport->kind);
                    state.player.vx = approachValue(state.player.vx, 0.0, state.tuning.landingFriction * safeDt);
                    // The browser lands during the vertical sweep and then runs the
                    // final depenetration pass with the original airborne wasOnGround
                    // flag.  Some shallow contacts on the authored start-ground seam
                    // therefore receive a second landing-friction pulse in the same
                    // fixed step.  Native's support probe collapses those two support
                    // resolutions into one, so mirror the second pulse only for the
                    // same seam/depenetration cases.
                    const bool startGroundSeamLanding = bestSupport->id.rfind("start_ground", 0) == 0;
                    const bool shallowPenetrationLanding = penetrationLandedThisStep
                        && penetration.groundingCorrectionY <= 4.0
                        && std::abs(moveAxis) <= 0.001;
                    const bool browserBlockableDepenetrationLanding = std::abs(moveAxis) <= 0.001
                        && bestSupport->kind == "blockable"
                        && bestSupport->id.rfind("object_", 0) == 0
                        && bestSupport->id.find("_blockable_") != std::string::npos;
                    if (startGroundSeamLanding || shallowPenetrationLanding || browserBlockableDepenetrationLanding)
                    {
                        state.player.vx = approachValue(state.player.vx, 0.0, state.tuning.landingFriction * safeDt);
                    }
                    emitPlayerLandedEvent(state, landingImpactVy, fallDamage, bestSupport->id, bestSupport->kind);
                }

            }
            else if (penetration.grounded)
            {
                state.player.onGround = true;
                state.player.vy = 0.0;
                state.player.ordinaryJumpActive = false;
                state.player.supportId = penetration.supportId;
                state.player.airBoostArmed = true;
                if (state.equipment.rocket.attachedBoosting)
                {
                    stopAttachedBoost(state);
                }
                if (!wasOnGround)
                {
                    const double fallDamage = applyFallDamageOnLanding(state, landingImpactVy, penetration.supportId, penetration.supportKind);
                    state.player.vx = approachValue(state.player.vx, 0.0, state.tuning.landingFriction * safeDt);
                    emitPlayerLandedEvent(state, landingImpactVy, fallDamage, penetration.supportId, penetration.supportKind);
                }
            }
            else
            {
                state.player.onGround = false;
                state.player.supportId.clear();
                // The JS reference only enables the apex-aware ordinary-jump integrator
                // from the jump edge itself.  Upward knockback, boosts, and other forces
                // must keep their existing jump mode; otherwise projectile hits get
                // integrated with the ordinary-jump half-step displacement and drift
                // roughly two thirds of a pixel per fixed step.
                state.player.ordinaryJumpActive = state.player.ordinaryJumpActive;
            }

        }
        }
        updatePlayerBodySlamCommitment(state, input, flightActive);
        const FWaterImmersion waterAfter = refreshPlayerWaterState(state);
        if (waterAfter.inWater) cancelPlayerBodySlamCommitment(state, "water");
        if (waterAfter.inWater && state.equipment.rocket.attachedBoosting)
        {
            stopAttachedBoost(state);
        }

        state.player.airborneTime = state.player.onGround ? 0.0 : state.player.airborneTime + safeDt;
        state.player.coyoteTimer = state.player.onGround ? 0.0 : state.player.coyoteTimer + safeDt;

        if (applyPlayerWorldBoundsKill(state))
        {
            return state;
        }
        if (applyPlayerCaveBoundary(state))
        {
            return state;
        }
        applyPlayerSurfaceHazards(state, surfaceHazardPlayerRectStart);
        if (state.player.combatState == "dead")
        {
            return state;
        }
        updateEnemyContactDamage(state);
        if (state.player.combatState == "dead")
        {
            return state;
        }
        updatePickups(state);
        updateFuelRecharge(state, safeDt);
        updateHealth(state, safeDt);
        updateBoostKickGroundRecharge(state, safeDt);

        if (state.player.combatState == "dead")
        {
            return state;
        }

        if (state.player.onGround && state.equipment.rocket.attachedBoosting)
        {
            stopAttachedBoost(state);
        }

        const FCameraEdgeCatchupPlan edgeCatchup = cameraEdgeCatchupPlan(state);
        const double lookAhead = 150.0 * static_cast<double>(state.player.facing);
        const double upwardLead = std::clamp(std::min(0.0, state.player.vy) * 0.12, -120.0, 0.0);
        const double descendingLead = state.player.onGround
            ? 0.0
            : std::clamp((std::max(0.0, state.player.vy) - 35.0) * 0.42, 0.0, 260.0);
        const double targetCameraX = state.player.x + lookAhead;
        const double nominalOffsetY = cameraLineNominalOffsetY(state, safeDt, 170.0);
        const double targetCameraY = state.player.y + nominalOffsetY + upwardLead + descendingLead;
        const double blendRate = descendingLead > 0.0 ? 0.00008 : CAMERA_REPOSITION_BLEND_RATE;
        const double blend = 1.0 - std::pow(blendRate, safeDt);
        state.camera.x += (targetCameraX - state.camera.x) * blend;
        state.camera.y += (targetCameraY - state.camera.y) * blend;
        state.camera.x = applyCameraEdgeCatchupAxis(state.camera.x, edgeCatchup.x, safeDt);
        state.camera.y = applyCameraEdgeCatchupAxis(state.camera.y, edgeCatchup.y, safeDt);
        keepPlayerInsideCameraViewport(state);
        return state;
    }
}
